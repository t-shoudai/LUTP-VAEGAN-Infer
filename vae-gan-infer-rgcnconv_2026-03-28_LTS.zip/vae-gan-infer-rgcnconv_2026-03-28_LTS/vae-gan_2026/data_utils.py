# data_utils.py

import os
import pickle
import random

import torch
import networkx as nx
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader

import make
from graph_utils import (
    my_base_graph,
    my_feature_vector,
    my_feature_vector_child_origin,
    make_edge_type,
    make_full_edge_type,
    NUM_EDGE_LABELS,
)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def save_pattern_and_data(P, edgelists, edge_labels_list=None, path='pattern_and_data.pkl'):
    with open(path, 'wb') as f:
        pickle.dump({
            'P': P,
            'edgelists': edgelists,
            'edge_labels_list': edge_labels_list,
        }, f)


def load_pattern_and_data(path='pattern_and_data.pkl'):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Pattern file not found: {path}")
    with open(path, 'rb') as f:
        data = pickle.load(f)
    return data['P'], data['edgelists'], data.get('edge_labels_list')


def gen_unordered_trees(PatVertexNum, AddVertexNum, NumOfPos):
    """
    パターン P と正例の edgelist・edge_labels を生成する。

    Returns
    -------
    P : nx.DiGraph
        パターン木（ノード name 属性付き）。
    list_of_edgelists : list of list
        各正例の無向辺リスト（双方向）。
    list_of_edge_labels : list of dict
        各正例の辺ラベル辞書 {(u, v): label_str}。
        辺ラベルは子ノードの name 属性（"a"〜"e"）。
    T_list : list of nx.DiGraph
        元の正例木オブジェクト（name 属性付き）。
    """
    root = 0
    P, T_list = make.generating_of_pattern_and_positive_example(
        PatVertexNum, AddVertexNum, NumOfPos
    )

    list_of_edgelists = []
    list_of_edge_labels = []

    for T in T_list:
        edges = nx.bfs_edges(T, root)
        nodes = [root] + [v for u, v in edges]
        mapping = {nodes[i]: i for i in range(len(nodes))}
        T = nx.relabel_nodes(T, mapping)

        edgelist = []
        edge_labels = {}

        for (u, v) in T.edges():
            edgelist.append([u, v])
            edgelist.append([v, u])

            # 辺ラベル = 子ノード (v) の name 属性
            label = T.nodes[v].get('name', 'a')
            edge_labels[(u, v)] = label
            edge_labels[(v, u)] = label

        list_of_edgelists.append(edgelist)
        list_of_edge_labels.append(edge_labels)

    return P, list_of_edgelists, list_of_edge_labels, T_list


def _edgelist_to_rooted_digraph(edgelist, edge_labels=None, root=0):
    """
    BFS 再番号付け済みの双方向 edgelist から、
    親 < 子 を使って rooted DiGraph を復元する。
    子ノードの name は edge_labels から復元する。
    """
    if edge_labels is None:
        edge_labels = {}

    T = nx.DiGraph()
    T.add_node(root, name="#")

    seen = set()
    for u, v in edgelist:
        a, b = (u, v) if u < v else (v, u)
        if a == b or (a, b) in seen:
            continue
        seen.add((a, b))

        if a not in T:
            T.add_node(a, name="#" if a == root else "X")

        label = edge_labels.get((a, b)) or edge_labels.get((b, a)) or "a"
        if b not in T:
            T.add_node(b, name=label)
        else:
            T.nodes[b]["name"] = label

        T.add_edge(a, b)

    return T


def _random_bfs_relabel_from_tree(T, rng, root=0):
    """
    rooted tree T に対し、各親の子の順序をランダムに並べ替えた上で
    BFS 順に再番号付けした新しい木を返す。
    """
    order = [root]
    queue = [root]
    head = 0

    while head < len(queue):
        u = queue[head]
        head += 1

        children = list(T.successors(u))
        rng.shuffle(children)

        for v in children:
            order.append(v)
            queue.append(v)

    mapping = {old: new for new, old in enumerate(order)}
    T_new = nx.relabel_nodes(T, mapping, copy=True)
    return T_new


def _tree_to_bidirectional_edgelist_and_labels(T):
    """
    rooted DiGraph から、現在の data_utils.py と同じ形式の
    双方向 edgelist と edge_labels を作る。
    辺ラベルは子ノードの name 属性を使う。
    """
    edgelist = []
    edge_labels = {}

    for u, v in T.edges():
        edgelist.append([u, v])
        edgelist.append([v, u])

        label = T.nodes[v].get("name", "a")
        edge_labels[(u, v)] = label
        edge_labels[(v, u)] = label

    return edgelist, edge_labels


def _augment_one_example_by_bfs_permutation(edgelist, edge_labels, rng, root=0):
    """
    1 個の正例について、
    sibling order をランダム化した BFS 再番号付け版を 1 個作る。
    """
    T = _edgelist_to_rooted_digraph(edgelist, edge_labels=edge_labels, root=root)
    T_aug = _random_bfs_relabel_from_tree(T, rng=rng, root=root)
    return _tree_to_bidirectional_edgelist_and_labels(T_aug)


def prepare_dataloaders_from_pattern(
    P,
    edgelists,
    AddVertexNum,
    batch_size=16,
    edge_labels_list=None,
    split_seed=1234,
    augment_train=False,
    augment_copies=0,
    augment_seed=None,
):
    """
    正例データローダーを作成する。

    Parameters
    ----------
    edge_labels_list : list of dict or None
        gen_unordered_trees から返される辺ラベル辞書のリスト。
        None の場合はすべて 'a' として扱う。
    """
    train_rate = 0.8
    PatVertexNum = P.number_of_nodes()
    max_node_size = PatVertexNum + AddVertexNum

    if edge_labels_list is None:
        edge_labels_list = [None] * len(edgelists)

    combined = list(zip(edgelists, edge_labels_list))
    rng = random.Random(split_seed)
    rng.shuffle(combined)

    M = len(combined)
    split_idx = int(M * train_rate)

    train_pairs = combined[:split_idx]
    test_pairs = combined[split_idx:]

    # --- augmentation は train のみに適用 ---
    if augment_train and augment_copies > 0:
        aug_rng = random.Random(split_seed if augment_seed is None else augment_seed)
        augmented_train_pairs = list(train_pairs)

        for edgelist, edge_labels in train_pairs:
            for _ in range(augment_copies):
                aug_edgelist, aug_edge_labels = _augment_one_example_by_bfs_permutation(
                    edgelist,
                    edge_labels,
                    rng=aug_rng,
                    root=0,
                )
                augmented_train_pairs.append((aug_edgelist, aug_edge_labels))

        train_pairs = augmented_train_pairs

    def build_dataset(pairs):
        dataset = []

        for edgelist, edge_labels in pairs:
            N = int(len(edgelist) / 2) + 1

            tree_edge_index = torch.tensor(
                edgelist, dtype=torch.long
            ).t().contiguous().to(device)

            full_edge_index = torch.tensor(
                my_base_graph(max_node_size), dtype=torch.long
            ).t().contiguous().to(device)

            x_target = torch.tensor(
                my_feature_vector_child_origin(edgelist, N, max_node_size, edge_labels),
                dtype=torch.float
            ).to(device)

            x = x_target

            tree_edge_type = make_edge_type(
                edgelist, max_node_size, edge_labels
            ).to(device)

            full_edge_type = make_full_edge_type(
                max_node_size
            ).to(device)

            data = Data(
                x=x,
                x_target=x_target,
                edge_index=tree_edge_index,
                full_edge_index=full_edge_index,
                tree_edge_type=tree_edge_type,
                full_edge_type=full_edge_type,
                num_real_nodes=torch.tensor([N], dtype=torch.long),
            ).to(device)

            dataset.append(data)

        return dataset

    train_dataset = build_dataset(train_pairs)
    test_dataset = build_dataset(test_pairs)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False)

    return train_loader, test_loader, max_node_size * NUM_EDGE_LABELS, PatVertexNum
