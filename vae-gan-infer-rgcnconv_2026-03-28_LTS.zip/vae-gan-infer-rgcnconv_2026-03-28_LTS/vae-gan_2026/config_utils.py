import json
import math
import os
from pathlib import Path


def load_config(path=None):
    if path is None:
        env_path = os.environ.get("CONFIG_PATH")
        if env_path:
            path = env_path
        else:
            path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "../config.json"
            )

    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def compute_model_dims(max_node_size, num_edge_labels, encoder_layers):
    fv_len = max_node_size * num_edge_labels
    latent_dim = math.floor(fv_len / 4)
    hidden_dim = fv_len + math.floor(fv_len / 6)
    hidden_dims = [hidden_dim] * encoder_layers
    return fv_len, latent_dim, hidden_dims


def make_discriminator_path(model_path: str) -> str:
    p = Path(model_path)

    stem = p.stem
    if stem.endswith("_model"):
        disc_stem = stem[:-len("_model")] + "_discriminator"
    else:
        disc_stem = stem + "_discriminator"

    suffix = p.suffix if p.suffix else ".pt"
    return str(p.with_name(f"{disc_stem}{suffix}"))