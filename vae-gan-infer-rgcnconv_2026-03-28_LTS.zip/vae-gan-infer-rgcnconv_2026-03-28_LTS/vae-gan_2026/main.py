import argparse
import os

import random
import numpy as np
import torch
import treepatlib as tpl

from config_utils import load_config, compute_model_dims, make_discriminator_path
from data_utils import (
    gen_unordered_trees,
    prepare_dataloaders_from_pattern,
    load_pattern_and_data,
)
from trainer import run_training
from evaluator import (
    evaluate_and_report_model,
    generate_and_save_blind,
    generate_and_save_debug,
    generate_and_save_cluster_center_blind,
    generate_and_save_cluster_center_debug,
)
from models import TreeVAE, Discriminator
from graph_utils import NUM_EDGE_LABELS, my_base_graph


def set_global_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def resolve_sample_counts(args, cfg, vae_cfg):
    pipeline_cfg = cfg.get("pipeline", {})

    default_eval_samples = vae_cfg.get(
        "eval_num_samples",
        vae_cfg.get(
            "n_samples",
            pipeline_cfg.get("n_samples", 100),
        ),
    )
    default_generate_samples = pipeline_cfg.get(
        "n_samples",
        vae_cfg.get(
            "generate_num_samples",
            vae_cfg.get("n_samples", 100),
        ),
    )

    if args.eval_samples is None:
        args.eval_samples = args.n_samples if args.n_samples is not None else default_eval_samples

    if args.generate_samples is None:
        args.generate_samples = args.n_samples if args.n_samples is not None else default_generate_samples

    return args


def main():
    cfg = load_config()
    vae_cfg = cfg["vae_gan"]
    common_cfg = cfg["common"]

    parser = argparse.ArgumentParser(description="TreeVAE+GAN: 無順序木パターン生成モデル")
    parser.add_argument(
        '--mode',
        choices=['train', 'eval', 'generate'],
        required=True
    )
    parser.add_argument(
        '--pat_nodes',
        type=int,
        default=vae_cfg['pat_nodes']
    )
    parser.add_argument(
        '--add_nodes',
        type=int,
        default=common_cfg['add_nodes']
    )
    parser.add_argument(
        '--num_pos',
        type=int,
        default=vae_cfg['num_pos']
    )
    parser.add_argument(
        '--max_beta',
        type=float,
        default=vae_cfg['max_beta']
    )
    parser.add_argument(
        '--K',
        type=int,
        default=vae_cfg['K']
    )
    parser.add_argument(
        '--skip_gen',
        action='store_true'
    )
    parser.add_argument(
        '--output',
        type=str,
        default=vae_cfg.get('output', cfg.get('pipeline', {}).get('generated', 'generated'))
    )
    parser.add_argument(
        '--n_samples',
        type=int,
        default=None,
        help='legacy alias: applies the same sample count to both eval and generate',
    )
    parser.add_argument(
        '--eval_samples',
        type=int,
        default=None,
        help='number of samples for eval mode',
    )
    parser.add_argument(
        '--generate_samples',
        type=int,
        default=None,
        help='number of samples for generate mode',
    )
    parser.add_argument(
        '--model_path',
        type=str,
        default=vae_cfg.get('model_path', 'best_model.pt')
    )
    parser.add_argument(
        '--total_epochs',
        type=int,
        default=vae_cfg.get('total_epochs', 300)
    )
    parser.add_argument(
        '--seed',
        type=int,
        default=vae_cfg.get('seed', 1234)
    )
    parser.add_argument(
        '--gen_strategy',
        choices=['empirical', 'empirical_debug', 'cluster_center', 'cluster_center_debug'],
        default=vae_cfg.get('gen_strategy', 'empirical'),
        help='Generation strategy for --mode generate',
    )
    parser.add_argument(
        '--empirical_bank_size',
        type=int,
        default=vae_cfg.get('empirical_bank_size', None),
    )
    parser.add_argument(
        '--empirical_bank_select_mode',
        type=str,
        default=vae_cfg.get('empirical_bank_select_mode', 'fps'),
    )
    parser.add_argument(
        '--empirical_sigma_scale',
        type=float,
        default=vae_cfg.get('empirical_sigma_scale', 0.15),
    )
    parser.add_argument(
        '--augment_copies',
        type=int,
        default=vae_cfg.get('augment_copies', 0),
    )

    args = parser.parse_args()
    args = resolve_sample_counts(args, cfg, vae_cfg)

    set_global_seed(args.seed)
    print(f'seed: {args.seed}')
    print(f'eval_samples: {args.eval_samples}')
    print(f'generate_samples: {args.generate_samples}')

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'device: {device}')

    if args.mode == 'train':
        T_list_orig = None

        if args.skip_gen:
            print('pattern_and_data.pkl から正例を読み込み中...')
            P, edgelists, edge_labels_list = load_pattern_and_data('pattern_and_data.pkl')
        else:
            print(f'正例生成中... (P={args.pat_nodes}, A={args.add_nodes}, N={args.num_pos})')
            P, edgelists, edge_labels_list, T_list_orig = gen_unordered_trees(
                args.pat_nodes,
                args.add_nodes,
                args.num_pos,
            )

        run_training(
            P,
            edgelists,
            args.add_nodes,
            device,
            max_beta=args.max_beta,
            K=args.K,
            model_save_path=args.model_path,
            edge_labels_list=edge_labels_list,
            total_epochs=args.total_epochs,
            split_seed=args.seed,
            augment_copies=args.augment_copies,
        )

        dfuds_P = tpl.dfuds(P)
        with open('pattern_P.txt', 'w', encoding='utf-8') as f:
            f.write(dfuds_P + '\n')
        print(f'パターン P を pattern_P.txt に保存しました (DFUDS長: {len(dfuds_P)})')

        if T_list_orig is not None:
            with open('original_positive.txt', 'w', encoding='utf-8') as fp:
                for T in T_list_orig:
                    fp.write(tpl.dfuds(T) + '\n')
            print(f'元の正例 {len(T_list_orig)} 件を original_positive.txt に保存しました')

    elif args.mode == 'eval':
        try:
            P, edgelists, edge_labels_list = load_pattern_and_data('pattern_and_data.pkl')
        except FileNotFoundError:
            print('Error: pattern_and_data.pkl が見つかりません。先に train モードで実行してください。')
            return

        max_node_size = P.number_of_nodes() + args.add_nodes
        encoder_layers = vae_cfg.get('encoder_layers', 2)
        fv_len, latent_dim, hidden_dims = compute_model_dims(
            max_node_size=max_node_size,
            num_edge_labels=NUM_EDGE_LABELS,
            encoder_layers=encoder_layers,
        )

        model = TreeVAE(
            fv_len,
            fv_len,
            hidden_dims,
            latent_dim,
            NUM_EDGE_LABELS,
            args.K,
            device=device,
        ).to(device)

        discriminator = Discriminator(
            fv_len,
            hidden_dims,
            NUM_EDGE_LABELS,
            args.K,
        ).to(device)

        model.load_state_dict(torch.load(args.model_path, map_location=device))
        model.eval()

        disc_path = make_discriminator_path(args.model_path)
        if os.path.exists(disc_path):
            discriminator.load_state_dict(torch.load(disc_path, map_location=device))
        else:
            print(f'[warn] discriminator checkpoint not found: {disc_path}')
        discriminator.eval()

        _, test_loader, _, PatVertexNum = prepare_dataloaders_from_pattern(
            P,
            edgelists,
            args.add_nodes,
            edge_labels_list=edge_labels_list,
            batch_size=1,
            split_seed=args.seed,
            augment_train=False,
            augment_copies=0,
        )

        skip_cluster_center = vae_cfg.get("skip_cluster_center_eval", True)
        evaluate_and_report_model(
            model,
            test_loader,
            discriminator,
            P,
            max_node_size,
            PatVertexNum,
            latent_dim,
            num_samples=args.eval_samples,
            skip_cluster_center=skip_cluster_center,
            empirical_bank_size=args.empirical_bank_size,
            empirical_bank_select_mode=args.empirical_bank_select_mode,
            empirical_sigma_scale=args.empirical_sigma_scale,
        )

    elif args.mode == 'generate':
        try:
            P, edgelists, edge_labels_list = load_pattern_and_data('pattern_and_data.pkl')
        except FileNotFoundError:
            print('Error: pattern_and_data.pkl が見つかりません。先に train モードで実行してください。')
            return

        max_node_size = P.number_of_nodes() + args.add_nodes
        encoder_layers = vae_cfg.get('encoder_layers', 2)
        fv_len, latent_dim, hidden_dims = compute_model_dims(
            max_node_size=max_node_size,
            num_edge_labels=NUM_EDGE_LABELS,
            encoder_layers=encoder_layers,
        )

        model = TreeVAE(
            fv_len,
            fv_len,
            hidden_dims,
            latent_dim,
            NUM_EDGE_LABELS,
            args.K,
            device=device,
        ).to(device)

        discriminator = Discriminator(
            fv_len,
            hidden_dims,
            NUM_EDGE_LABELS,
            args.K,
        ).to(device)

        model.load_state_dict(torch.load(args.model_path, map_location=device))
        model.eval()

        disc_path = make_discriminator_path(args.model_path)
        if os.path.exists(disc_path):
            discriminator.load_state_dict(torch.load(disc_path, map_location=device))
        else:
            print(f'[warn] discriminator checkpoint not found: {disc_path}')
        discriminator.eval()

        _, test_loader, fv_len_loader, PatVertexNum = prepare_dataloaders_from_pattern(
            P,
            edgelists,
            args.add_nodes,
            edge_labels_list=edge_labels_list,
            batch_size=1,
            split_seed=args.seed,
            augment_train=False,
            augment_copies=0,
        )
        max_node_size = fv_len_loader // NUM_EDGE_LABELS
        edge_index = torch.tensor(
            my_base_graph(max_node_size),
            dtype=torch.long,
        ).t().contiguous().to(device)

        if args.gen_strategy == 'empirical':
            generate_and_save_blind(
                model=model,
                test_loader=test_loader,
                edge_index=edge_index,
                max_node_size=max_node_size,
                out_file=args.output,
                n_samples=args.generate_samples,
                sigma_scale=args.empirical_sigma_scale,
                bank_size=args.empirical_bank_size,
                bank_select_mode=args.empirical_bank_select_mode,
            )

        elif args.gen_strategy == 'empirical_debug':
            generate_and_save_debug(
                model=model,
                P=P,
                test_loader=test_loader,
                edge_index=edge_index,
                max_node_size=max_node_size,
                out_file=args.output,
                n_samples=args.generate_samples,
                sigma_scale=args.empirical_sigma_scale,
                bank_size=args.empirical_bank_size,
                bank_select_mode=args.empirical_bank_select_mode,
            )

        elif args.gen_strategy == 'cluster_center':
            generate_and_save_cluster_center_blind(
                model=model,
                D=discriminator,
                test_loader=test_loader,
                edge_index=edge_index,
                max_node_size=max_node_size,
                pat_vertex_num=PatVertexNum,
                out_file=args.output,
                n_samples=args.generate_samples,
                num_clusters=10,
                top_k_clusters=5,
                top_sigma=0.1,
                temperature=0.5,
                rank_trials=5,
            )

        elif args.gen_strategy == 'cluster_center_debug':
            generate_and_save_cluster_center_debug(
                model=model,
                D=discriminator,
                P=P,
                test_loader=test_loader,
                edge_index=edge_index,
                max_node_size=max_node_size,
                pat_vertex_num=PatVertexNum,
                out_file=args.output,
                n_samples=args.generate_samples,
                num_clusters=10,
                top_k_clusters=5,
                top_sigma=0.1,
                temperature=0.5,
                rank_trials=5,
            )

    
if __name__ == '__main__':
    main()
