# make.py

import os
import treepatlib as tpl
import networkx as nx
import random
import copy

from config_utils import load_config


def _normalize_edge_labels(raw_edge_labels):
    """
    config の common.edge_labels を内部表現のラベル配列へ正規化する。

    許容する入力:
      1) int
         例: 5 -> ["a", "b", "c", "d", "e"]
      2) list / tuple
         例: ["a", "b", "c", "d", "e"]

    戻り値:
      list[str]
    """
    if isinstance(raw_edge_labels, int):
        if raw_edge_labels <= 0:
            raise ValueError("common.edge_labels must be a positive integer")
        if raw_edge_labels > 26:
            raise ValueError("common.edge_labels > 26 is not supported by default label naming")
        return [chr(ord("a") + i) for i in range(raw_edge_labels)]

    if isinstance(raw_edge_labels, (list, tuple)):
        labels = [str(x) for x in raw_edge_labels]
        if not labels:
            raise ValueError("common.edge_labels list must not be empty")
        return labels

    raise TypeError(
        "common.edge_labels must be either an int or a list/tuple of labels"
    )


ROOT = 0
VARIABLE_NAME = 'X'

_config = load_config()
EDGE_LABELS = _normalize_edge_labels(_config["common"]["edge_labels"])


# 変数に代入する部分木の超点数のリスト（結果をキャッシュ）
_integral_cache = {}

def get_integral_value_combination(num_vertex, num_variable):
    key = (num_vertex, num_variable)
    if key in _integral_cache:
        return _integral_cache[key]
    num_vertex = num_vertex + num_variable
    items = [_ for _ in range(1, num_vertex + 1)]
    def a(idx, l, r, t):
        if t == sum(l): r.append(l)
        elif t < sum(l): return
        for u in range(idx, len(items)):
            a(u, l + [items[u]], r, t)
        return r
    sum_list = a(0, [], [], num_vertex)
    result = [x for x in sum_list if len(x) == num_variable]
    _integral_cache[key] = result
    return result

# テキストからランダムに木を取り出す（ファイルキャッシュ版）
_tree_lines_cache = {}

def _load_tree_lines(num_vertex, max_lines=10000):
    if num_vertex not in _tree_lines_cache:
        text_pass = 'unordered_trees/' + str(num_vertex) + '.txt'
        with open(text_pass) as f:
            lines = f.readlines()
        if len(lines) > max_lines:
            lines = random.sample(lines, max_lines)
        _tree_lines_cache[num_vertex] = lines
    return _tree_lines_cache[num_vertex]

def random_tree_select(num_variable):
    lines = _load_tree_lines(num_variable + 1)
    dfuds = random.choice(lines)
    return tpl.draw.return_to_graph(dfuds)

# 部分木の代入
def tree_assignment(P, assigned_vertex, subtree):
    P_pos = copy.deepcopy(P)
    max_id = max([v for v in P.nodes]) + 1
    new_tree = nx.DiGraph()
    for v in subtree.nodes():
        if v == 0:
            label = str(P.nodes[assigned_vertex]['name'])
            new_tree.add_node(assigned_vertex, name=label)
        else:
            label = str(subtree.nodes[v]['name'])
            new_tree.add_node(v + max_id, name=label)
    for edges in subtree.edges():
        new_edge = dict(before=0, after=0)
        for enu, edge in enumerate(edges):
            if enu == 0:
                if edge == 0:
                    new_edge['before'] = assigned_vertex
                else:
                    new_edge['before'] = edge + max_id
            else:
                new_edge['after'] = edge + max_id
        new_tree.add_edge(new_edge['before'], new_edge['after'])
    P_pos = nx.compose(P_pos, new_tree)
    return P_pos

def generating_of_pattern_and_positive_example(PatVertexNum, AddVertexNum, NumOfPos):
    # テキストからランダムに木を抽出
    path = 'unordered_trees/' + str(PatVertexNum) + '.txt'
    with open(path) as f:
        lines = f.readlines()
        s = random.sample(lines,1)[0]

    # DFUDS表現をNetworkX表現に変換
    P = tpl.draw.return_to_graph(s)
    Original_Tree = copy.deepcopy(P)

    leaf = [v for v in P.nodes if tpl.unordered.is_leaf(P,v) == True]
    # 葉の集合からランダムに変数を選択
    variable_node = random.sample(leaf, random.randint(1,len(leaf)))

    for v in variable_node:
        P.add_node(v, name=VARIABLE_NAME)

    # 変数ノード以外の非根ノードに辺ラベルをランダム付与
    for v in P.nodes():
        if v != ROOT and P.nodes[v]["name"] != VARIABLE_NAME:
            P.nodes[v]["name"] = random.choice(EDGE_LABELS)

    Positive = []
    ldpt_list = []

    try_make_positive = 0
    while len(Positive) < NumOfPos:
        T = copy.deepcopy(P)  # P のランダムラベルを正例に反映するため Original_Tree ではなく P を使う
        subtree_comb = random.choice(get_integral_value_combination(AddVertexNum, len(variable_node)))
        subtree_comb = random.sample(subtree_comb, len(subtree_comb))

        import copy as _copy
        subtree_list = []
        for _st in [random_tree_select(i) for i in subtree_comb]:
            _st = _copy.deepcopy(_st)
            for _v in _st.nodes():
                if _v != 0:
                    _st.nodes[_v]["name"] = random.choice(EDGE_LABELS)
            subtree_list.append(_st)
        j = 0
        for v in P.nodes:
            if P.nodes[v]['name'] == VARIABLE_NAME:
                parent = nx.dfs_predecessors(P, source=ROOT)[v]
                T.remove_node(v)
                T = tree_assignment(T, parent, subtree_list[j])
                j += 1
        T = tpl.draw.clear(T)
        T_temp = copy.deepcopy(T)
        T_temp = tpl.unordered.right_depth_preferred_tree(T_temp)
        dfuds = tpl.draw.dfuds(T_temp)
        if dfuds not in ldpt_list:
            Positive.append(T)
            ldpt_list.append(dfuds)
            if len(Positive) % 100 == 0:
                print(f'make positive: {len(Positive):04d} / {NumOfPos}')

        try_make_positive += 1
        if try_make_positive > NumOfPos * 10: # 正例生成を10倍試したら強制終了
            break

    print(f'Number of positive: {len(Positive):04d}')
    return P, Positive

if __name__ == "__main__":
    # 作成される正例は(PatVertexNum+num_vertex)です
    PatVertexNum = 10
    AddVertexNum = 10
    NumOfPos = 1000

    P, Positive = generating_of_pattern_and_positive_example(PatVertexNum, AddVertexNum, NumOfPos)

    # マッチング確認
    for T in Positive:
        if tpl.unordered.matching(P,T) == False:
            print('正例集合に負例があったため終了します')
            exit()
