# graph_utils.py

import torch
import networkx as nx
import treepatlib as tpl

from config_utils import load_config


def _normalize_edge_labels(raw_edge_labels):
    """
    config の common.edge_labels を内部表現のラベル配列へ正規化する。

    許容する入力:
      1) int
         例: 5 -> ["a", "b", "c", "d", "e"]
      2) list / tuple
         例: ["a", "b", "c", "d", "e"]

    戻り値:
      list[str]
    """
    if isinstance(raw_edge_labels, int):
        if raw_edge_labels <= 0:
            raise ValueError("common.edge_labels must be a positive integer")
        if raw_edge_labels > 26:
            raise ValueError("common.edge_labels > 26 is not supported by default label naming")
        return [chr(ord("a") + i) for i in range(raw_edge_labels)]

    if isinstance(raw_edge_labels, (list, tuple)):
        labels = [str(x) for x in raw_edge_labels]
        if not labels:
            raise ValueError("common.edge_labels list must not be empty")
        return labels

    raise TypeError(
        "common.edge_labels must be either an int or a list/tuple of labels"
    )


_config = load_config()

EDGE_LABELS = _normalize_edge_labels(_config["common"]["edge_labels"])
LABEL_TO_IDX = {lb: i + 1 for i, lb in enumerate(EDGE_LABELS)}  # 0: no-edge, 1..: labels
NUM_EDGE_LABELS = len(EDGE_LABELS) + 1
FV_MULTIPLIER = NUM_EDGE_LABELS


def my_base_graph_lower_to_upper(N):
    """
    self-loop なしの complete graph を単方向 edge list (小->大)で返す。
    例: N=3 -> [0->1, 0->2, 1->2]
    """
    G = nx.complete_graph(N)
    return list(G.edges())


def my_base_graph_upper_to_lower(N):
    """
    self-loop なしの complete graph を単方向 edge list (大->小)で返す。
    例: N=3 -> [1->0, 2->0, 2->1]
    """
    G = nx.complete_graph(N)
    return [(v, u) for (u, v) in G.edges()]


def my_base_graph(N):
    """
    self-loop なしの complete graph を双方向 edge list で返す。
    例: N=3 -> [0->1, 1->0, 0->2, 2->0, 1->2, 2->1]
    """
    G = nx.complete_graph(N)

    bidir_edges = []
    for u, v in G.edges():
        bidir_edges.append([u, v])
        bidir_edges.append([v, u])

    return bidir_edges


def make_edge_type(edgelist, max_node_size, edge_labels=None):
    # Build edge_type tensor for encoder (tree edges).
    # label index: 0=no-edge, 1=a, 2=b, ... (NUM_EDGE_LABELS types)
    if edge_labels is None:
        edge_labels = {}
    types = []
    for u, v in edgelist:
        label = edge_labels.get((u, v), edge_labels.get((v, u), None))
        types.append(LABEL_TO_IDX.get(label, 1) if label else 1)
    return torch.tensor(types, dtype=torch.long)


def make_full_edge_type(max_node_size):
    # Build edge_type tensor for decoder (complete graph).
    # All edges initialized to 0 (no-edge); actual labels recovered via featurevec_to_digraph.
    full_edges = my_base_graph(max_node_size)
    return torch.zeros(len(full_edges), dtype=torch.long)


def edgelist_to_graph(edgelist, N):
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edgelist)
    return G

def my_feature_vector_child_origin(edgelist, N, max_node_size, edge_labels=None):
    """
    各ノード i の行に、
      - 親ノード j
      - 親 j から i へ入る辺ラベル
    だけを one-hot で持たせる。

    class 0: no-edge
    class 1..K-1: edge label

    注意:
    data_utils.py で木は BFS 順に再番号付けされているため、
    親 < 子 が成り立つ前提で parent/child を復元する。
    """
    if edge_labels is None:
        edge_labels = {}

    K = NUM_EDGE_LABELS
    fv_cols = max_node_size * K
    featurevec = [[0.0] * fv_cols for _ in range(max_node_size)]

    # 全ブロックを no-edge(class 0) で初期化
    for i in range(max_node_size):
        for j in range(max_node_size):
            featurevec[i][j * K + 0] = 1.0

    # edgelist は双方向なので、無向辺ごとに 1 回だけ処理
    seen_undirected = set()

    for u, v in edgelist:
        key = (u, v) if u < v else (v, u)
        if key in seen_undirected:
            continue
        seen_undirected.add(key)

        # BFS 再番号付けにより parent < child
        parent, child = key

        label = edge_labels.get((parent, child)) or edge_labels.get((child, parent))
        idx = LABEL_TO_IDX.get(label, 1) if label else 1

        # child 行の parent 列だけを positive にする
        featurevec[child][parent * K + 0] = 0.0
        featurevec[child][parent * K + idx] = 1.0

    return featurevec

def my_feature_vector(edgelist, N, max_node_size, edge_labels=None):
    """各 (i, j) について
    0: no-edge, 1..K-1: edge label
    の one-hot を返す。
    """
    if edge_labels is None:
        edge_labels = {}

    K = NUM_EDGE_LABELS
    fv_cols = max_node_size * K
    featurevec = [[0.0] * fv_cols for _ in range(max_node_size)]

    # まず全てを no-edge(class 0) に初期化
    for i in range(max_node_size):
        for j in range(max_node_size):
            featurevec[i][j * K + 0] = 1.0

    # 実際に存在する辺だけ、no-edge を落としてラベル側を立てる
    seen = set()
    for (i, j) in edgelist:
        if (i, j) in seen:
            continue
        seen.add((i, j))
        seen.add((j, i))

        label = edge_labels.get((i, j)) or edge_labels.get((j, i))
        idx = LABEL_TO_IDX.get(label, 1) if label else 1

        # i -> j
        featurevec[i][j * K + 0] = 0.0
        featurevec[i][j * K + idx] = 1.0

        # j -> i
        featurevec[j][i * K + 0] = 0.0
        featurevec[j][i * K + idx] = 1.0

    return featurevec


def featurevec_to_digraph(fv, N):
    """デコーダ出力の特徴ベクトルから有向木（辺ラベル付き）を復元する。
    第1段階:
      - 各頂点 i (i>=1) の親は j < i の中から1つ選ぶ
      - まだ parent の単調制約は入れない
      - 全域木は使わない
    """
    import torch.nn.functional as F
    import networkx as nx

    fv = fv.clone().detach().cpu()
    K = NUM_EDGE_LABELS  # 0: no-edge, 1..: edge labels

    # [child=i, parent=j, class]
    fv_sm = F.softmax(fv.view(N, N, K), dim=2)

    G = nx.DiGraph()
    G.add_nodes_from(range(N))

    for i in range(N):
        G.nodes[i]["id"] = i
        G.nodes[i]["name"] = "#" if i == 0 else "X"

    # root=0 以外は、必ず 1 つ親を持つ
    for i in range(1, N):
        best_parent = 0
        best_label = EDGE_LABELS[0]
        best_score = -float("inf")

        for j in range(i):  # 親候補は j < i のみ
            block = fv_sm[i, j, 1:]   # no-edge を除くラベル部分
            local_score, local_idx = block.max(dim=0)
            score = local_score.item()

            if score > best_score:
                best_score = score
                best_parent = j
                best_label = EDGE_LABELS[local_idx.item()]

        G.add_edge(best_parent, i, label=best_label)
        G.nodes[i]["name"] = best_label

    return [G]


def count_nonisomorphic_graphs(graphs):
    unique_graphs = []
    for G in graphs:
        is_new = True
        for H in unique_graphs:
            if G.number_of_nodes() != H.number_of_nodes():
                continue
            if tpl.unordered.matching(G, H):
                is_new = False
                break
        if is_new:
            unique_graphs.append(G)
    return len(unique_graphs), unique_graphs


def _find_root(G):
    roots = [v for v in G.nodes if G.in_degree(v) == 0]
    if len(roots) != 1:
        raise ValueError(f"root が一意に定まりません: roots={roots}")
    return roots[0]


def _canonical_subtree_key(G, v):
    node_label = str(G.nodes[v].get("name", ""))

    child_parts = []
    for c in G.successors(v):
        edge_label = str(G.edges[v, c].get("label", ""))
        child_key = _canonical_subtree_key(G, c)
        child_parts.append((edge_label, child_key))

    child_parts.sort(key=lambda x: (x[0], x[1]))

    inside = "".join(f"<{edge_label}>{child_key}" for edge_label, child_key in child_parts)
    return f"({node_label}{inside})"


def graph_to_canonical_dfuds(G):
    root = _find_root(G)
    return _canonical_subtree_key(G, root)