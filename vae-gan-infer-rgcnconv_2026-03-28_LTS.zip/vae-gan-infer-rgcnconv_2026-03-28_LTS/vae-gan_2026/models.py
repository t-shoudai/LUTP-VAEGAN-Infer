# models.py

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import RGCNConv, GraphConv
from torch_geometric.nn import global_mean_pool, global_max_pool


class Encoder(nn.Module):
    def __init__(self, input_dim, hidden_dims, latent_dim, num_relations, K=3, device='cpu'):
        super().__init__()
        dims = [input_dim] + hidden_dims
        self.layers = nn.ModuleList([
            RGCNConv(dims[i], dims[i + 1], num_relations=num_relations)
            for i in range(len(dims) - 1)
        ])
        self.l_mean = RGCNConv(hidden_dims[-1], latent_dim, num_relations=num_relations)
        self.l_log_var = RGCNConv(hidden_dims[-1], latent_dim, num_relations=num_relations)

    def forward(self, x, edge_index, edge_type, batch=None, ptr=None):
        for conv in self.layers:
            x = F.relu(conv(x, edge_index, edge_type))
        return self.l_mean(x, edge_index, edge_type), self.l_log_var(x, edge_index, edge_type)


class Decoder(nn.Module):
    def __init__(self, output_dim, hidden_dims, latent_dim, num_relations, K=3, device='cpu'):
        super().__init__()
        from torch_geometric.nn import TAGConv as _TAGConv
        dims = [latent_dim] + hidden_dims[::-1]
        self.layers = nn.ModuleList([
            _TAGConv(dims[i], dims[i + 1], K=K)
            for i in range(len(dims) - 1)
        ])
        self.final_layer = _TAGConv(dims[-1], output_dim, K=K)

    def forward(self, z, edge_index, N=None, batch=None, edge_type=None):
        x = z

        if N is not None and x.size(0) != N:
            raise ValueError(
                f"Decoder received z with {x.size(0)} nodes, but N={N}. "
                "Expected one latent vector per node."
            )

        for conv in self.layers:
            x = F.relu(conv(x, edge_index))
        return self.final_layer(x, edge_index)


class Discriminator(nn.Module):
    def __init__(self, input_dim, hidden_dims, num_relations, K=3):
        super().__init__()
        dims = [input_dim] + hidden_dims

        self.layers = nn.ModuleList([
            GraphConv(dims[i], dims[i + 1], aggr='add')
            for i in range(len(dims) - 1)
        ])
        self.bns = nn.ModuleList([
            nn.BatchNorm1d(dims[i + 1])
            for i in range(len(dims) - 1)
        ])

        hd = hidden_dims[-1]
        self.mlp = nn.Sequential(
            nn.Linear(hd * 2, hd),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hd, hd // 2),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hd // 2, 1)
        )

    def forward(self, x, edge_index, edge_type=None, batch=None):
        if batch is None:
            batch = torch.zeros(x.size(0), dtype=torch.long, device=x.device)

        for conv, bn in zip(self.layers, self.bns):
            x = bn(F.relu(conv(x, edge_index)))

        h_mean = global_mean_pool(x, batch)
        h_max = global_max_pool(x, batch)
        h = torch.cat([h_mean, h_max], dim=1)
        return self.mlp(h)


class hybrid_Discriminator(nn.Module):
    def __init__(self, input_dim, hidden_dims, num_relations, K=3):
        super().__init__()

        if len(hidden_dims) == 0:
            raise ValueError("hidden_dims must not be empty")

        dims = [input_dim] + hidden_dims

        # 前段: relation-aware
        self.rel_conv = RGCNConv(
            dims[0],
            dims[1],
            num_relations=num_relations
        )
        self.rel_bn = nn.BatchNorm1d(dims[1])

        # 後段: structure aggregation
        graph_dims = dims[1:]
        self.graph_layers = nn.ModuleList([
            GraphConv(graph_dims[i], graph_dims[i + 1], aggr='add')
            for i in range(len(graph_dims) - 1)
        ])
        self.graph_bns = nn.ModuleList([
            nn.BatchNorm1d(graph_dims[i + 1])
            for i in range(len(graph_dims) - 1)
        ])

        # 追加の GraphConv
        self.tail_conv = GraphConv(graph_dims[-1], graph_dims[-1], aggr='add')
        self.tail_bn = nn.BatchNorm1d(graph_dims[-1])

        self.dropout = 0.2
        hd = graph_dims[-1]

        self.mlp = nn.Sequential(
            nn.Linear(hd * 2, hd),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(hd, hd // 2),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(hd // 2, 1)
        )

    def forward(self, x, edge_index, edge_type=None, batch=None):
        if edge_type is None:
            edge_type = torch.zeros(
                edge_index.shape[1],
                dtype=torch.long,
                device=x.device
            )

        if batch is None:
            batch = torch.zeros(
                x.size(0),
                dtype=torch.long,
                device=x.device
            )

        # 1段目: RGCNConv
        h = self.rel_conv(x, edge_index, edge_type)
        h = self.rel_bn(h)
        h = F.relu(h)
        h = F.dropout(h, p=self.dropout, training=self.training)

        # 中段: GraphConv
        for conv, bn in zip(self.graph_layers, self.graph_bns):
            h_new = conv(h, edge_index)
            h_new = bn(h_new)
            h_new = F.relu(h_new)

            if h_new.shape == h.shape:
                h = h + h_new
            else:
                h = h_new

            h = F.dropout(h, p=self.dropout, training=self.training)

        # 終段: 追加 GraphConv
        h_tail = self.tail_conv(h, edge_index)
        h_tail = self.tail_bn(h_tail)
        h_tail = F.relu(h_tail)
        h = h + h_tail
        h = F.dropout(h, p=self.dropout, training=self.training)

        h_mean = global_mean_pool(h, batch)
        h_max = global_max_pool(h, batch)
        h_graph = torch.cat([h_mean, h_max], dim=1)

        return self.mlp(h_graph)


class TreeVAE(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_dims, latent_dim, num_relations, K=3, device='cpu'):
        super().__init__()
        self.device = device
        self.encoder = Encoder(input_dim, hidden_dims, latent_dim, num_relations, K, device)
        self.decoder = Decoder(output_dim, hidden_dims, latent_dim, num_relations, K, device)

    def forward(
        self,
        x,
        edge_index,
        full_edge_index=None,
        tree_edge_type=None,
        full_edge_type=None,
        batch=None,
        N=None,
        ptr=None
    ):
        if N is None:
            N = x.size(0)

        mean, log_var = self.encoder(x, edge_index, tree_edge_type, batch, ptr)
        z = self.reparameterize(mean, log_var)
        dec_edge = full_edge_index if full_edge_index is not None else edge_index
        y = self.decoder(z, dec_edge, N, batch)
        return y, z, mean, log_var

    def reparameterize(self, mean, log_var):
        eps = torch.randn_like(mean)
        std = torch.exp(0.5 * log_var)
        return mean + std * eps