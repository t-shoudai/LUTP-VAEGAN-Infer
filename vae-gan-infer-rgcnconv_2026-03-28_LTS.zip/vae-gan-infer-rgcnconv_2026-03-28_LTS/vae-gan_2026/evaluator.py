# evaluator.py

import os
import pickle
import random

import numpy as np
import torch
import treepatlib as tpl
from io import StringIO
from sklearn.cluster import KMeans

from graph_utils import (
    featurevec_to_digraph,
    my_base_graph,
    count_nonisomorphic_graphs,
    FV_MULTIPLIER,
    graph_to_canonical_dfuds,
)

TEMPERATURE = 0.5

# グローバルキャッシュ（完全グラフ edge_index）
_precomputed_edge_index = None

# グローバルデバイス（evaluate_and_report_model 呼び出し時に設定）
device = torch.device("cpu")


def evaluate_empirical_latent_generation(
    model,
    P,
    test_loader,
    edge_index,
    max_node_size,
    num_samples=100,
    sigma_scale=0.15,
    bank_size=None,
    bank_select_mode="fps",
):
    """
    学習済み正例の encoder mean の経験分布からサンプリングして評価する。
    必要なら latent bank で弱圧縮した上で、その近傍 z = mean + noise から生成する。
    """
    print(f"Evaluating empirical-latent generation (sigma_scale={sigma_scale})...")
    edge_index = edge_index.to(device)
    model.eval()

    all_means = _collect_encoder_means(model, test_loader, device)
    if not all_means:
        print("[warn] no encoder means collected")
        return

    bank_means = _select_empirical_latent_bank(
        all_means,
        bank_size=bank_size,
        select_mode=bank_select_mode,
    )

    print(
        f"[empirical-latent eval] total_means={len(all_means)}, "
        f"bank_size={len(bank_means)}, "
        f"select_mode={bank_select_mode}"
    )

    match_count = 0
    all_generated_graphs = []

    with torch.no_grad():
        for _ in range(num_samples):
            mean = random.choice(bank_means)
            z = mean + sigma_scale * torch.randn_like(mean)

            if not torch.isfinite(z).all():
                continue

            x_gen = model.decoder(z, edge_index, N=max_node_size)
            graphs = featurevec_to_digraph(x_gen.detach().cpu(), max_node_size)
            all_generated_graphs.extend(graphs)

            if any(tpl.unordered.matching(P, G) for G in graphs):
                match_count += 1

    print(f"Empirical-latent match rate: {match_count / num_samples:.6f}")
    num_unique, _ = count_nonisomorphic_graphs(all_generated_graphs)
    print(f"Empirical-latent unique graphs: {num_unique}")


def sweep_empirical_latent_settings(
    model,
    P,
    test_loader,
    edge_index,
    max_node_size,
    total_samples=100,
    sigma_scale=0.15,
    configs=None,
):
    """
    empirical-latent の weak compression を比較する。
    bank_size=None は full empirical。
    """
    if configs is None:
        configs = [
            (None, "fps"),
            (100, "fps"),
            (50, "fps"),
            (20, "fps"),
        ]

    print(f"=== Sweep empirical-latent settings (target total_samples={total_samples}) ===")

    n_available = len(test_loader.dataset) if hasattr(test_loader, "dataset") else None

    for bank_size, bank_select_mode in configs:
        effective_bank_size = bank_size
        if bank_size is not None and n_available is not None:
            effective_bank_size = min(bank_size, max(1, n_available))

        print(
            f"[sweep] bank_size={bank_size}, "
            f"effective_bank_size={effective_bank_size}, "
            f"select_mode={bank_select_mode}, "
            f"sigma_scale={sigma_scale}"
        )

        evaluate_empirical_latent_generation(
            model=model,
            P=P,
            test_loader=test_loader,
            edge_index=edge_index,
            max_node_size=max_node_size,
            num_samples=total_samples,
            sigma_scale=sigma_scale,
            bank_size=bank_size,
            bank_select_mode=bank_select_mode,
        )


def inspect_latent_distribution(model, test_loader):
    print("Inspecting latent distribution...")
    model.eval()

    all_means = []
    all_log_vars = []

    with torch.no_grad():
        for g in test_loader:
            g = g.to(device)
            mean, log_var = model.encoder(
                g.x,
                g.edge_index,
                g.tree_edge_type,
                batch=g.batch,
                ptr=g.ptr,
            )
            all_means.append(mean)
            all_log_vars.append(log_var)

    means_tensor = torch.stack(all_means).to(device)
    logvars_tensor = torch.stack(all_log_vars).to(device)

    mean_abs = means_tensor.abs().mean().item()
    mean_std = means_tensor.std().item()
    logvar_mean = logvars_tensor.mean().item()
    var_mean = logvars_tensor.exp().mean().item()

    print(f"[latent] |mean| avg     : {mean_abs:.6f}")
    print(f"[latent] mean std       : {mean_std:.6f}")
    print(f"[latent] log_var avg    : {logvar_mean:.6f}")
    print(f"[latent] exp(log_var) avg: {var_mean:.6f}")


def logits_to_soft_onehot(logits, num_edge_labels=None):
    if num_edge_labels is None:
        num_edge_labels = logits.shape[1]

    probs = torch.softmax(
        logits.view(logits.size(0), -1, num_edge_labels),
        dim=2,
    )
    return probs.view_as(logits)


def _collect_encoder_means(model, test_loader, device):
    all_means = []
    with torch.no_grad():
        for g in test_loader:
            g = g.to(device)
            mean, _ = model.encoder(
                g.x,
                g.edge_index,
                g.tree_edge_type,
                batch=g.batch,
                ptr=g.ptr,
            )
            all_means.append(mean)

    return all_means


def _compute_mu_stats(all_means, device):
    means_tensor = torch.stack(all_means).to(device)
    mu_mean = means_tensor.mean(dim=0).to(device)
    mu_std = means_tensor.std(dim=0).clamp_min(1e-8).to(device)

    return means_tensor, mu_mean, mu_std


def _flatten_mean_for_bank(mean):
    return mean.detach().cpu().numpy().reshape(-1).astype(np.float32)


def _select_empirical_latent_bank(
    all_means,
    bank_size=None,
    select_mode="fps",
):
    """
    empirical_latent 用の弱圧縮 latent bank を作る。
    bank_size=None なら全 mean をそのまま使う。

    select_mode:
      - "fps"    : farthest-point style に多様な mean を選ぶ
      - "random" : ランダム抽出
    """
    if not all_means:
        return []

    n = len(all_means)

    if bank_size is None or bank_size <= 0 or bank_size >= n:
        return list(all_means)

    if select_mode == "random":
        idxs = random.sample(range(n), bank_size)
        return [all_means[i] for i in idxs]

    # default: fps
    X = np.stack([_flatten_mean_for_bank(m) for m in all_means], axis=0)

    # 最初の1点は全体平均に最も近いもの
    global_mean = X.mean(axis=0, keepdims=True)
    first_idx = int(np.argmin(np.linalg.norm(X - global_mean, axis=1)))

    selected = [first_idx]
    min_dists = np.linalg.norm(X - X[first_idx:first_idx + 1], axis=1)

    while len(selected) < bank_size:
        next_idx = int(np.argmax(min_dists))

        if next_idx in selected:
            remaining = [i for i in range(n) if i not in selected]
            if not remaining:
                break
            next_idx = remaining[0]

        selected.append(next_idx)

        d = np.linalg.norm(X - X[next_idx:next_idx + 1], axis=1)
        min_dists = np.minimum(min_dists, d)

    return [all_means[i] for i in selected]


def _compute_tree_depths(edge_index, num_real_nodes):
    """
    BFS 再番号付け済みの木に対して、各ノードの深さを返す。
    data_utils.py / graph_utils.py の前提どおり parent < child を使う。
    """
    n = int(num_real_nodes)
    if n <= 0:
        return np.zeros(0, dtype=np.int64)

    edge_np = edge_index.detach().cpu().numpy()
    children = [[] for _ in range(n)]
    seen = set()

    # edge_index は双方向なので、親<子 の向きだけ 1 回採用
    for u, v in edge_np.T:
        u = int(u)
        v = int(v)

        if u >= n or v >= n or u == v:
            continue

        parent, child = (u, v) if u < v else (v, u)
        if (parent, child) in seen:
            continue

        seen.add((parent, child))
        children[parent].append(child)

    depths = np.full(n, -1, dtype=np.int64)
    depths[0] = 0

    queue = [0]
    head = 0
    while head < len(queue):
        parent = queue[head]
        head += 1

        for child in children[parent]:
            if depths[child] != -1:
                continue
            depths[child] = depths[parent] + 1
            queue.append(child)

    # 何らかの理由で未到達ノードがあれば、tail bucket 側へ寄せる
    if np.any(depths < 0):
        fallback_depth = int(depths[depths >= 0].max()) + 1 if np.any(depths >= 0) else 0
        depths[depths < 0] = fallback_depth

    return depths

def _l2_normalize_1d(x, eps=1e-8):
    x = np.asarray(x, dtype=np.float32)
    norm = np.linalg.norm(x)
    if (not np.isfinite(norm)) or norm < eps:
        return np.zeros_like(x, dtype=np.float32)
    return (x / norm).astype(np.float32, copy=False)


def _build_cluster_dataset(
    all_means,
    test_loader,
    pat_vertex_num,
    max_summary_depth=2,
    prefix_weight=1.0,
    summary_weight=0.00,
):
    """
    クラスタリング用の mixed feature を作る。

    feature =
      [ prefix(mean[:pat_vertex_num]) を L2 正規化したもの
        +
        depth-summary を L2 正規化したもの ]

    これで
      - 旧来の prefix 情報は残す
      - ただし浅い深さ要約も少し混ぜる
    という折衷案にする。
    """
    zs = []

    for mean, g in zip(all_means, test_loader):
        num_real_nodes = int(g.num_real_nodes.view(-1)[0].item())
        depths = _compute_tree_depths(g.edge_index, num_real_nodes)

        # 1) 旧来の prefix 特徴
        prefix_feat = (
            mean[:pat_vertex_num]
            .detach()
            .cpu()
            .numpy()
            .reshape(-1)
            .astype(np.float32)
        )
        prefix_feat = _l2_normalize_1d(prefix_feat)

        # 2) 浅い深さの summary 特徴
        latent_dim = mean.shape[1]
        bucket_vecs = []
        bucket_counts = []

        for d in range(max_summary_depth + 1):
            idxs = np.where(depths == d)[0]
            bucket_counts.append(len(idxs) / max(1, num_real_nodes))

            if len(idxs) == 0:
                bucket_vecs.append(
                    torch.zeros(latent_dim, device=mean.device, dtype=mean.dtype)
                )
            else:
                bucket_vecs.append(mean[idxs].mean(dim=0))

        tail_idxs = np.where(depths > max_summary_depth)[0]
        bucket_counts.append(len(tail_idxs) / max(1, num_real_nodes))

        if len(tail_idxs) == 0:
            bucket_vecs.append(
                torch.zeros(latent_dim, device=mean.device, dtype=mean.dtype)
            )
        else:
            bucket_vecs.append(mean[tail_idxs].mean(dim=0))

        latent_summary = torch.cat(bucket_vecs, dim=0).detach().cpu().numpy()
        count_summary = np.array(bucket_counts, dtype=np.float32)

        summary_feat = np.concatenate([latent_summary, count_summary], axis=0).astype(np.float32)
        summary_feat = _l2_normalize_1d(summary_feat)

        # 3) 混合
        z_mixed = np.concatenate(
            [
                prefix_weight * prefix_feat,
                summary_weight * summary_feat,
            ],
            axis=0,
        )

        zs.append(z_mixed)

    return zs


def _fit_kmeans(zs, num_clusters):
    num_clusters = min(num_clusters, max(1, len(zs)))
    kmeans = KMeans(n_clusters=num_clusters, random_state=0, n_init=10).fit(np.array(zs))
    return kmeans.cluster_centers_


def _fit_kmeans_and_select_representatives(
    zs,
    num_clusters,
    reps_per_cluster=3,
    return_indices=False,
):
    """
    各クラスタから 1 個の medoid ではなく、
    クラスタ中心に近い実サンプルを最大 reps_per_cluster 個返す。
    """
    zs_np = np.array(zs)
    if len(zs_np) == 0:
        return ([], []) if return_indices else []

    num_clusters = min(num_clusters, max(1, len(zs_np)))
    reps_per_cluster = max(1, int(reps_per_cluster))

    kmeans = KMeans(
        n_clusters=num_clusters,
        random_state=0,
        n_init=10,
    ).fit(zs_np)

    labels = kmeans.labels_
    centers = kmeans.cluster_centers_

    representatives = []
    representative_indices = []

    for c in range(num_clusters):
        idxs = np.where(labels == c)[0]
        if len(idxs) == 0:
            continue

        cluster_points = zs_np[idxs]
        dists = np.linalg.norm(cluster_points - centers[c], axis=1)
        order = np.argsort(dists)

        n_rep = min(reps_per_cluster, len(idxs))
        chosen = idxs[order[:n_rep]]

        for rep_idx in chosen:
            representatives.append(zs_np[rep_idx])
            representative_indices.append(int(rep_idx))

    if return_indices:
        return representatives, representative_indices
    return representatives


def _select_cluster_centers_from_mixed_features(
    all_means,
    test_loader,
    pat_vertex_num,
    num_clusters,
    reps_per_cluster=3,
    max_summary_depth=2,
    prefix_weight=1.0,
    summary_weight=0.00,
):
    """
    mixed feature 空間でクラスタリングし、
    各クラスタから複数の代表点を返す。
    実際の生成には、その代表サンプル自身の mean[:pat_vertex_num] を使う。
    """
    zs = _build_cluster_dataset(
        all_means=all_means,
        test_loader=test_loader,
        pat_vertex_num=pat_vertex_num,
        max_summary_depth=max_summary_depth,
        prefix_weight=prefix_weight,
        summary_weight=summary_weight,
    )

    _, representative_indices = _fit_kmeans_and_select_representatives(
        zs,
        num_clusters,
        reps_per_cluster=reps_per_cluster,
        return_indices=True,
    )

    centers = []
    for idx in representative_indices:
        z_top = all_means[idx][:pat_vertex_num]
        centers.append(z_top.detach().cpu().numpy().reshape(-1))

    return centers


def _rank_cluster_centers(
    centers,
    model,
    D,
    edge_index,
    mu_mean,
    mu_std,
    pat_vertex_num,
    max_node_size,
    top_sigma,
    temperature=1.0,
    rank_trials=5,
    top_k_clusters=7,
    device=None,
    use_sigmoid=True,
    return_ranked_info=False,
):
    if device is None:
        device = next(model.parameters()).device

    latent_dim = mu_mean.shape[1]
    cluster_scores = []

    with torch.no_grad():
        for center in centers:
            success = 0.0
            base_top = torch.from_numpy(center).to(
                device=device,
                dtype=torch.float32
            ).view(pat_vertex_num, latent_dim)

            for _ in range(rank_trials):
                z_top = base_top + top_sigma * torch.randn_like(base_top)

                z_rest_mu = mu_mean[pat_vertex_num:max_node_size]
                z_rest_std = mu_std[pat_vertex_num:max_node_size]
                z_rest = z_rest_mu + temperature * torch.randn_like(z_rest_mu) * z_rest_std

                z = torch.cat([z_top, z_rest], dim=0)

                try:
                    x_gen = model.decoder(z, edge_index, N=max_node_size)

                    gen_edge_type = torch.zeros(
                        edge_index.shape[1],
                        dtype=torch.long,
                        device=device,
                    )
                    gen_batch = torch.zeros(
                        x_gen.size(0),
                        dtype=torch.long,
                        device=device,
                    )

                    x_gen_for_D = logits_to_soft_onehot(x_gen)

                    d_logit = D(
                        x_gen_for_D,
                        edge_index,
                        gen_edge_type,
                        batch=gen_batch,
                    )

                    d_score = torch.sigmoid(d_logit) if use_sigmoid else d_logit
                    success += d_score.item()

                except Exception as e:
                    print(f"[warn] ranking gen error: {e}")
                    continue

            cluster_scores.append(success / max(1, rank_trials))

    top_indices = np.argsort(cluster_scores)[-top_k_clusters:][::-1]
    selected_centers = [centers[i] for i in top_indices]

    if not return_ranked_info:
        return selected_centers

    ranked_info = [
        {
            "rank": rank + 1,
            "cluster_index": int(i),
            "mean_d_score": float(cluster_scores[i]),
        }
        for rank, i in enumerate(top_indices)
    ]
    return selected_centers, ranked_info


def _generate_from_selected_centers(
    selected_centers,
    model,
    P,
    edge_index,
    mu_mean,
    mu_std,
    pat_vertex_num,
    max_node_size,
    samples_per_cluster=100,
    top_sigma=0.1,
    temperature=1.0,
    device=None,
):
    if device is None:
        device = next(model.parameters()).device

    latent_dim = mu_mean.shape[1]
    match_count = 0
    all_generated_graphs = []

    with torch.no_grad():
        for center in selected_centers:
            base_top = torch.from_numpy(center).to(
                device=device,
                dtype=torch.float32
            ).view(pat_vertex_num, latent_dim)

            for _ in range(samples_per_cluster):
                z_top = base_top + top_sigma * torch.randn_like(base_top)

                z_rest_mu = mu_mean[pat_vertex_num:max_node_size]
                z_rest_std = mu_std[pat_vertex_num:max_node_size]
                z_rest = z_rest_mu + temperature * torch.randn_like(z_rest_mu) * z_rest_std

                z = torch.cat([z_top, z_rest], dim=0)

                try:
                    x_gen = model.decoder(z, edge_index, N=max_node_size)
                    graphs = featurevec_to_digraph(x_gen.detach().cpu(), max_node_size)
                    all_generated_graphs.extend(graphs)

                    if any(tpl.unordered.matching(P, G) for G in graphs):
                        match_count += 1

                except Exception as e:
                    print(f"[warn] gen error: {e}")
                    continue

    return match_count, all_generated_graphs

def _sample_graph_from_mean(
    model,
    mean,
    edge_index,
    max_node_size,
    sigma_scale=0.3,
):
    z = mean + sigma_scale * torch.randn_like(mean)
    y = model.decoder(z, edge_index, N=max_node_size)
    G = featurevec_to_digraph(y.detach().cpu(), max_node_size)[0]
    return G


def _sample_graph_from_cluster_center(
    model,
    center,
    edge_index,
    mu_mean,
    mu_std,
    pat_vertex_num,
    max_node_size,
    top_sigma=0.1,
    temperature=0.5,
    device=None,
):
    if device is None:
        device = next(model.parameters()).device

    latent_dim = mu_mean.shape[1]

    base_top = torch.from_numpy(center).to(
        device=device,
        dtype=torch.float32,
    ).view(pat_vertex_num, latent_dim)

    z_top = base_top + top_sigma * torch.randn_like(base_top)

    z_rest_mu = mu_mean[pat_vertex_num:max_node_size]
    z_rest_std = mu_std[pat_vertex_num:max_node_size]
    z_rest = z_rest_mu + temperature * torch.randn_like(z_rest_mu) * z_rest_std

    z = torch.cat([z_top, z_rest], dim=0)

    y = model.decoder(z, edge_index, N=max_node_size)
    G = featurevec_to_digraph(y.detach().cpu(), max_node_size)[0]
    return G


def generate_and_save_cluster_center_debug(
    model,
    D,
    P,
    test_loader,
    edge_index,
    max_node_size,
    pat_vertex_num,
    out_file,
    n_samples=100,
    num_clusters=10,
    reps_per_cluster=3,
    top_k_clusters=5,
    top_sigma=0.1,
    temperature=0.5,
    rank_trials=5,
    max_mismatch_examples=10,
):
    device_ = next(model.parameters()).device
    edge_index = edge_index.to(device_)
    model.eval()
    D.eval()

    print(f"device: {device_}")

    all_means = _collect_encoder_means(model, test_loader, device_)
    if not all_means:
        print("[警告] test_loaderが空です")
        return 0, 0

    print(f"正例 {len(all_means)} 件のmeanを収集（cluster-center oracle debug generation）")

    means_tensor, mu_mean, mu_std = _compute_mu_stats(all_means, device_)

    centers = _select_cluster_centers_from_mixed_features(
        all_means=all_means,
        test_loader=test_loader,
        pat_vertex_num=pat_vertex_num,
        num_clusters=num_clusters,
        reps_per_cluster=reps_per_cluster,
        max_summary_depth=2,
        prefix_weight=1.0,
        summary_weight=0.00,
    )

    selected_centers = centers

    print(
        f"[cluster-center debug] num_clusters={num_clusters}, "
        f"reps_per_cluster={reps_per_cluster}, "
        f"selected_centers={len(selected_centers)}"
    )

    ranked_info = [
        {
            "rank": i + 1,
            "cluster_index": i,
            "mean_d_score": None,
        }
        for i in range(len(selected_centers))
    ]

    print("=== selected cluster centers (no D ranking) ===")
    for info in ranked_info:
        print(
            f"[rank {info['rank']}] "
            f"cluster={info['cluster_index']}, "
            f"mean_d_score=None"
        )

    if os.path.exists(out_file + ".txt"):
        os.remove(out_file + ".txt")

    seen_dfuds = set()
    saved_pos = 0
    saved_neg = 0
    total_gen = 0
    max_trials = max(n_samples * 50, 2000)

    first_mismatches = []
    center_use_counts = [0] * len(selected_centers)

    with torch.no_grad():
        for trial in range(max_trials):
            if total_gen >= n_samples:
                break

            center_idx = random.randrange(len(selected_centers))
            center = selected_centers[center_idx]
            center_use_counts[center_idx] += 1

            try:
                G = _sample_graph_from_cluster_center(
                    model=model,
                    center=center,
                    edge_index=edge_index,
                    mu_mean=mu_mean,
                    mu_std=mu_std,
                    pat_vertex_num=pat_vertex_num,
                    max_node_size=max_node_size,
                    top_sigma=top_sigma,
                    temperature=temperature,
                    device=device_,
                )
            except Exception as e:
                print(f"[warn] cluster-center debug generation error: {e}")
                continue

            prev_saved_neg = saved_neg

            is_new, saved_pos, saved_neg, total_gen = _save_graph_if_new(
                G=G,
                P=P,
                out_file=out_file,
                seen_dfuds=seen_dfuds,
                saved_pos=saved_pos,
                saved_neg=saved_neg,
                total_gen=total_gen,
            )

            if (
                is_new
                and saved_neg > prev_saved_neg
                and len(first_mismatches) < max_mismatch_examples
            ):
                first_mismatches.append(_graph_to_save_dfuds(G))

            if (trial + 1) % 200 == 0:
                print(
                    f"[progress] trial={trial + 1}, "
                    f"unique={total_gen}, pos={saved_pos}, neg={saved_neg}"
                )

    match_rate_gen = saved_pos / total_gen if total_gen > 0 else 0.0

    if total_gen < n_samples:
        print(f"[警告] 非同型グラフが {total_gen}/{n_samples} 件のみ生成")

    print(f"非同型グラフ数: {len(seen_dfuds)}/{max_trials} 試行")
    print(f"cluster-center debug生成完了: 正例={saved_pos} 件, 負例={saved_neg} 件, 総生成={total_gen} 件")
    print(f"Generate match rate (oracle debug): {match_rate_gen:.6f} ({saved_pos}/{total_gen})")

    print("=== center usage summary ===")
    for info, used in zip(ranked_info, center_use_counts):
        print(
            f"[rank {info['rank']}] "
            f"cluster={info['cluster_index']}, "
            f"mean_d_score=None, "
            f"used={used}"
        )

    if first_mismatches:
        print("=== first mismatches (DFUDS) ===")
        for i, dfuds in enumerate(first_mismatches, start=1):
            print(f"[neg {i}] {dfuds}")

    return saved_pos, saved_neg


def generate_and_save_cluster_center_blind(
    model,
    D,
    test_loader,
    edge_index,
    max_node_size,
    pat_vertex_num,
    out_file,
    n_samples=100,
    num_clusters=10,
    reps_per_cluster=3,
    top_k_clusters=5,
    top_sigma=0.1,
    temperature=0.5,
    rank_trials=5,
):
    device_ = next(model.parameters()).device
    edge_index = edge_index.to(device_)
    model.eval()
    D.eval()

    print(f"device: {device_}")

    all_means = _collect_encoder_means(model, test_loader, device_)
    if not all_means:
        print("[警告] test_loaderが空です")
        return 0

    print(f"正例 {len(all_means)} 件のmeanを収集（cluster-center blind generation）")

    means_tensor, mu_mean, mu_std = _compute_mu_stats(all_means, device_)

    centers = _select_cluster_centers_from_mixed_features(
        all_means=all_means,
        test_loader=test_loader,
        pat_vertex_num=pat_vertex_num,
        num_clusters=num_clusters,
        reps_per_cluster=reps_per_cluster,
        max_summary_depth=2,
        prefix_weight=1.0,
        summary_weight=0.00,
    )

    selected_centers = centers

    print(
        f"[cluster-center blind] num_clusters={num_clusters}, "
        f"reps_per_cluster={reps_per_cluster}, "
        f"selected_centers={len(selected_centers)}"
    )

    if os.path.exists(out_file + ".txt"):
        os.remove(out_file + ".txt")

    seen_dfuds = set()
    total_gen = 0
    max_trials = max(n_samples * 50, 2000)

    with torch.no_grad():
        for trial in range(max_trials):
            if total_gen >= n_samples:
                break

            center = random.choice(selected_centers)

            try:
                G = _sample_graph_from_cluster_center(
                    model=model,
                    center=center,
                    edge_index=edge_index,
                    mu_mean=mu_mean,
                    mu_std=mu_std,
                    pat_vertex_num=pat_vertex_num,
                    max_node_size=max_node_size,
                    top_sigma=top_sigma,
                    temperature=temperature,
                    device=device_,
                )
            except Exception as e:
                print(f"[warn] cluster-center blind generation error: {e}")
                continue

            is_new, total_gen = _save_graph_if_new_blind(
                G=G,
                out_file=out_file,
                seen_dfuds=seen_dfuds,
                total_gen=total_gen,
            )

            if (trial + 1) % 200 == 0:
                print(f"[progress] trial={trial + 1}, unique={total_gen}")

        if total_gen < n_samples:
            print(f"[警告] 非同型グラフが {total_gen}/{n_samples} 件のみ生成")

    print(f"非同型グラフ数: {len(seen_dfuds)}/{max_trials} 試行")
    print(f"blind生成完了(cluster-center): 総生成={total_gen} 件")
    print(f"saved to: {out_file}.txt")

    return total_gen


def evaluate_and_report_model(
    model,
    test_loader,
    D,
    P,
    max_node_size,
    PatVertexNum,
    latent_dim,
    num_samples=100,
    skip_cluster_center=True,
    empirical_bank_size=None,
    empirical_bank_select_mode="fps",
    empirical_sigma_scale=0.15,
):
    global _precomputed_edge_index, device

    device = next(model.parameters()).device
    model = model.to(device)
    D = D.to(device)

    inspect_latent_distribution(model, test_loader)

    if _precomputed_edge_index is None:
        _precomputed_edge_index = torch.tensor(
            my_base_graph(max_node_size), dtype=torch.long
        ).t().contiguous().to(device)

    edge_index = _precomputed_edge_index

    print(f"=== Evaluating Trained Model (temperature={TEMPERATURE}) ===")

    match_rate = evaluate_match_from_encoded_z(
        model,
        test_loader,
        P,
        max_node_size=max_node_size,
    )
    print(f"Match rate from encoded z: {match_rate:.6f}")

    if empirical_bank_size is None:
        sweep_empirical_latent_settings(
            model=model,
            P=P,
            test_loader=test_loader,
            edge_index=edge_index,
            max_node_size=max_node_size,
            total_samples=num_samples,
            sigma_scale=empirical_sigma_scale,
            configs=[
                (None, empirical_bank_select_mode),
                (100, empirical_bank_select_mode),
                (50, empirical_bank_select_mode),
                (20, empirical_bank_select_mode),
            ],
        )
    else:
        evaluate_empirical_latent_generation(
            model=model,
            P=P,
            test_loader=test_loader,
            edge_index=edge_index,
            max_node_size=max_node_size,
            num_samples=num_samples,
            sigma_scale=empirical_sigma_scale,
            bank_size=empirical_bank_size,
            bank_select_mode=empirical_bank_select_mode,
        )

    evaluate_mu_profile_scaled_generation(
        model,
        P,
        test_loader,
        edge_index,
        max_node_size,
        num_samples=num_samples,
    )

    if skip_cluster_center:
        print("=== Skip cluster-center evaluation ===")
        print("Cluster-center evaluation was skipped by configuration.")
    else:
        sweep_cluster_center_settings(
            model=model,
            D=D,
            P=P,
            test_loader=test_loader,
            edge_index=edge_index,
            max_node_size=max_node_size,
            PatVertexNum=PatVertexNum,
            total_samples=num_samples,
            temperature=TEMPERATURE,
            rank_trials=5,
        )


def evaluate_match_from_encoded_z(model, test_loader, P, max_node_size):
    match_count = 0
    model.eval()

    with torch.no_grad():
        for g in test_loader:
            g = g.to(device)
            N = g.x.size(0)

            mean, _ = model.encoder(
                g.x,
                g.edge_index,
                g.tree_edge_type,
                batch=g.batch,
                ptr=g.ptr,
            )

            dec_edge = g.full_edge_index if getattr(g, "full_edge_index", None) is not None else g.edge_index

            x_rec = model.decoder(
                mean,
                dec_edge,
                N=N,
                batch=g.batch,
            )

            graphs = featurevec_to_digraph(x_rec.detach().cpu(), N=max_node_size)
            if any(tpl.unordered.matching(P, G) for G in graphs):
                match_count += 1

    return match_count / len(test_loader)


def evaluate_random_generation(P, decoder, num_samples, latent_dim, edge_index, max_node_size):
    """完全ランダムな z からパターンにマッチする木を生成できるか検証する。"""
    print(f"Evaluating random generation (temperature={TEMPERATURE})...")
    edge_index = edge_index.to(device)
    match_count = 0

    with torch.no_grad():
        for _ in range(num_samples):
            z = TEMPERATURE * torch.randn((max_node_size, latent_dim), device=device)
            y = decoder(z, edge_index, N=max_node_size)
            graphs = featurevec_to_digraph(y.detach().cpu(), max_node_size)
            if any(tpl.unordered.matching(P, G) for G in graphs):
                match_count += 1

    print(f"Random generation match rate: {match_count / num_samples:.6f}")


def evaluate_mean_centered_generation(P, encoder, decoder, num_samples, edge_index, max_node_size):
    """正例潜在変数の平均を中心にサンプリングしてマッチ率を検証する。"""
    print(f"Evaluating mean-centered generation (temperature={TEMPERATURE})...")
    edge_index = edge_index.to(device)
    match_count = 0

    x_dummy = torch.zeros(max_node_size, max_node_size * FV_MULTIPLIER, device=device)

    with torch.no_grad():
        dummy_et = torch.zeros(edge_index.shape[1], dtype=torch.long, device=edge_index.device)
        mean, _ = encoder(x_dummy, edge_index, dummy_et)

        for _ in range(num_samples):
            noise = TEMPERATURE * torch.randn_like(mean)
            z = mean + noise
            y = decoder(z, edge_index, N=max_node_size)
            graphs = featurevec_to_digraph(y.detach().cpu(), max_node_size)
            if any(tpl.unordered.matching(P, G) for G in graphs):
                match_count += 1

    print(f"Mean-centered generation match rate: {match_count / num_samples:.6f}")


def evaluate_mu_profile_scaled_generation(model, P, test_loader, edge_index, max_node_size, num_samples=100):
    """正例の潜在変数の経験分布（ノードごとの mean/std）からサンプリングして評価する。"""
    print(f"Evaluating μ-profile scaled generation (temperature={TEMPERATURE})...")
    edge_index = edge_index.to(device)
    model.eval()

    all_means = _collect_encoder_means(model, test_loader, device)
    means_tensor, mu_mean, mu_std = _compute_mu_stats(all_means, device)

    match_count = 0
    all_generated_graphs = []

    with torch.no_grad():
        for _ in range(num_samples):
            z_noise = torch.normal(mean=mu_mean, std=mu_std)
            z = TEMPERATURE * z_noise

            if not torch.isfinite(z).all():
                continue

            x_gen = model.decoder(z, edge_index, N=max_node_size)
            graphs = featurevec_to_digraph(x_gen.detach().cpu(), N=max_node_size)
            all_generated_graphs.extend(graphs)

            if any(tpl.unordered.matching(P, G) for G in graphs):
                match_count += 1

    print(f"μ-profile scaled match rate: {match_count / num_samples:.6f}")
    num_unique, _ = count_nonisomorphic_graphs(all_generated_graphs)
    print(f"μ-profile scaled unique graphs: {num_unique}")


def evaluate_cluster_center_generation(
    model,
    D,
    P,
    test_loader,
    edge_index,
    max_node_size,
    PatVertexNum,
    num_clusters=15,
    reps_per_cluster=3,
    samples_per_cluster=20,
    top_sigma=None,
    top_sigma_factor=0.1,
    temperature=1.0,
    rank_trials=5,
    top_k_clusters=5,
    device=None,
    use_sigmoid=True,
):
    if device is None:
        device = next(model.parameters()).device

    edge_index = edge_index.to(device)

    print(f"Evaluating cluster-center generation (temperature={TEMPERATURE})...")
    model.eval()
    D.eval()

    all_means = _collect_encoder_means(model, test_loader, device)
    means_tensor, mu_mean, mu_std = _compute_mu_stats(all_means, device)

    centers = _select_cluster_centers_from_mixed_features(
        all_means=all_means,
        test_loader=test_loader,
        pat_vertex_num=PatVertexNum,
        num_clusters=num_clusters,
        reps_per_cluster=reps_per_cluster,
        max_summary_depth=2,
        prefix_weight=1.0,
        summary_weight=0.00,
    )

    if top_sigma is None:
        base_scale = mu_std[:PatVertexNum].mean().item()
        top_sigma = base_scale * top_sigma_factor

    selected_centers = centers

    print(
        f"[cluster-center eval] num_clusters={num_clusters}, "
        f"reps_per_cluster={reps_per_cluster}, "
        f"selected_centers={len(selected_centers)}"
    )

    match_count, all_generated_graphs = _generate_from_selected_centers(
        selected_centers=selected_centers,
        model=model,
        P=P,
        edge_index=edge_index,
        mu_mean=mu_mean,
        mu_std=mu_std,
        pat_vertex_num=PatVertexNum,
        max_node_size=max_node_size,
        samples_per_cluster=samples_per_cluster,
        top_sigma=top_sigma,
        temperature=temperature,
        device=device,
    )

    match_rate = match_count / (len(selected_centers) * max(1, samples_per_cluster))
    num_unique, _ = count_nonisomorphic_graphs(all_generated_graphs)

    print(f"Cluster-center generation match rate: {match_rate:.6f}")
    print(f"Cluster-center generation unique graphs: {num_unique}")


def sweep_cluster_center_settings(
    model,
    D,
    P,
    test_loader,
    edge_index,
    max_node_size,
    PatVertexNum,
    total_samples=100,
    configs=None,
    top_sigma=None,
    top_sigma_factor=0.1,
    temperature=1.0,
    rank_trials=5,
    device=None,
    use_sigmoid=True,
):
    if configs is None:
        configs = [
            (10, 1),
            (10, 3),
            (20, 2),
        ]

    print(f"=== Sweep cluster-center settings (target total_samples={total_samples}) ===")

    n_available = len(test_loader.dataset) if hasattr(test_loader, "dataset") else None

    for num_clusters, reps_per_cluster in configs:
        effective_num_clusters = num_clusters
        if n_available is not None:
            effective_num_clusters = min(num_clusters, max(1, n_available))

        approx_num_centers = max(1, effective_num_clusters * reps_per_cluster)
        samples_per_cluster = max(1, total_samples // approx_num_centers)
        actual_total = approx_num_centers * samples_per_cluster

        print(
            f"[sweep] num_clusters={num_clusters}, "
            f"effective_num_clusters={effective_num_clusters}, "
            f"reps_per_cluster={reps_per_cluster}, "
            f"samples_per_cluster={samples_per_cluster}, "
            f"actual_total={actual_total}"
        )

        evaluate_cluster_center_generation(
            model=model,
            D=D,
            P=P,
            test_loader=test_loader,
            edge_index=edge_index,
            max_node_size=max_node_size,
            PatVertexNum=PatVertexNum,
            num_clusters=num_clusters,
            reps_per_cluster=reps_per_cluster,
            samples_per_cluster=samples_per_cluster,
            top_sigma=top_sigma,
            top_sigma_factor=top_sigma_factor,
            temperature=temperature,
            rank_trials=rank_trials,
            top_k_clusters=5,
            device=device,
            use_sigmoid=use_sigmoid,
        )


def _graph_to_save_dfuds(G):
    try:
        return tpl.dfuds(G)
    except AttributeError:
        return tpl.draw.dfuds(G)


def _save_graph_if_new(
    G,
    P,
    out_file,
    seen_dfuds,
    saved_pos,
    saved_neg,
    total_gen,
):
    dfuds_key = graph_to_canonical_dfuds(G)
    if dfuds_key in seen_dfuds:
        return False, saved_pos, saved_neg, total_gen

    seen_dfuds.add(dfuds_key)
    total_gen += 1

    if tpl.unordered.matching(P, G):
        tpl.tree_save(G, class_=1, file_name=out_file)
        saved_pos += 1
    else:
        tpl.tree_save(G, class_=0, file_name=out_file)
        saved_neg += 1

    return True, saved_pos, saved_neg, total_gen


def _save_graph_if_new_blind(
    G,
    out_file,
    seen_dfuds,
    total_gen,
):
    dfuds_key = graph_to_canonical_dfuds(G)
    if dfuds_key in seen_dfuds:
        return False, total_gen

    seen_dfuds.add(dfuds_key)
    total_gen += 1

    save_dfuds = _graph_to_save_dfuds(G)

    with open(out_file + ".txt", "a", encoding="utf-8") as f:
        f.write(save_dfuds + "\n")

    return True, total_gen


def generate_and_save_debug(
    model,
    P,
    test_loader,
    edge_index,
    max_node_size,
    out_file,
    n_samples=1000,
    sigma_scale=0.15,
    bank_size=None,
    bank_select_mode="fps",
):
    device_ = next(model.parameters()).device
    edge_index = edge_index.to(device_)
    model.eval()
    print(f"device: {device_}")

    all_means = _collect_encoder_means(model, test_loader, device_)

    if not all_means:
        print("[警告] test_loaderが空です")
        return 0, 0

    bank_means = _select_empirical_latent_bank(
        all_means,
        bank_size=bank_size,
        select_mode=bank_select_mode,
    )

    print(f"正例 {len(all_means)} 件のmeanを収集（empirical-latent oracle debug generation）")
    print(
        f"[empirical-latent debug] bank_size={len(bank_means)}, "
        f"select_mode={bank_select_mode}, sigma_scale={sigma_scale}"
    )

    seen_dfuds = set()
    saved_pos = 0
    saved_neg = 0
    total_gen = 0
    max_trials = max(n_samples * 50, 2000)

    if os.path.exists(out_file + ".txt"):
        os.remove(out_file + ".txt")

    with torch.no_grad():
        for trial in range(max_trials):
            if total_gen >= n_samples:
                break

            mean = random.choice(bank_means)

            G = _sample_graph_from_mean(
                model=model,
                mean=mean,
                edge_index=edge_index,
                max_node_size=max_node_size,
                sigma_scale=sigma_scale,
            )

            is_new, saved_pos, saved_neg, total_gen = _save_graph_if_new(
                G=G,
                P=P,
                out_file=out_file,
                seen_dfuds=seen_dfuds,
                saved_pos=saved_pos,
                saved_neg=saved_neg,
                total_gen=total_gen,
            )

            if not is_new:
                continue

    match_rate_gen = saved_pos / total_gen if total_gen > 0 else 0.0

    if total_gen < n_samples:
        print(f"[警告] 非同型グラフが {total_gen}/{n_samples} 件のみ生成")

    print(f"非同型グラフ数: {len(seen_dfuds)}/{max_trials} 試行")
    print(f"生成完了: 正例={saved_pos} 件, 負例={saved_neg} 件, 総生成={total_gen} 件")
    print(f"Generate match rate (oracle debug): {match_rate_gen:.6f} ({saved_pos}/{total_gen})")
    return saved_pos, saved_neg


def generate_and_save_blind(
    model,
    test_loader,
    edge_index,
    max_node_size,
    out_file,
    n_samples=1000,
    sigma_scale=0.15,
    bank_size=None,
    bank_select_mode="fps",
):
    device_ = next(model.parameters()).device
    edge_index = edge_index.to(device_)
    model.eval()
    print(f"device: {device_}")

    all_means = _collect_encoder_means(model, test_loader, device_)

    if not all_means:
        print("[警告] test_loaderが空です")
        return 0

    bank_means = _select_empirical_latent_bank(
        all_means,
        bank_size=bank_size,
        select_mode=bank_select_mode,
    )

    print(f"正例 {len(all_means)} 件のmeanを収集（empirical-latent blind generation）")
    print(
        f"[empirical-latent blind] bank_size={len(bank_means)}, "
        f"select_mode={bank_select_mode}, sigma_scale={sigma_scale}"
    )

    seen_dfuds = set()
    total_gen = 0
    max_trials = max(n_samples * 50, 2000)

    if os.path.exists(out_file + ".txt"):
        os.remove(out_file + ".txt")

    with torch.no_grad():
        for _ in range(max_trials):
            if total_gen >= n_samples:
                break

            mean = random.choice(bank_means)

            G = _sample_graph_from_mean(
                model=model,
                mean=mean,
                edge_index=edge_index,
                max_node_size=max_node_size,
                sigma_scale=sigma_scale,
            )

            is_new, total_gen = _save_graph_if_new_blind(
                G=G,
                out_file=out_file,
                seen_dfuds=seen_dfuds,
                total_gen=total_gen,
            )

            if not is_new:
                continue

    if total_gen < n_samples:
        print(f"[警告] 非同型グラフが {total_gen}/{n_samples} 件のみ生成")

    print(f"非同型グラフ数: {len(seen_dfuds)}/{max_trials} 試行")
    print(f"blind生成完了: 総生成={total_gen} 件")
    print(f"saved to: {out_file}.txt")

    return total_gen


def load_generated_positive(file_path, class_=1):
    positive = []

    with open(file_path, encoding="UTF-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            parts = line.split(": ", 1)
            if len(parts) != 2:
                continue

            label, dfuds_str = parts[0], parts[1]
            if class_ is None or int(label) == class_:
                G = tpl.return_to_graph(dfuds_str)
                positive.append(G)

    print(f"{file_path} から {len(positive)} 件の正例を読み込みました")
    return positive


def load_generated_blind_dfuds(file_path):
    trees = []
    with open(file_path, "r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, start=1):
            dfuds = line.strip()
            if not dfuds:
                continue
            try:
                T = tpl.read_tree(StringIO(dfuds))
                trees.append(T)
            except Exception as e:
                print(f"[warn] failed to parse blind dfuds at line {lineno}: {e}")
                continue
    
    print(f"{file_path} から {len(trees)} 件の blind 木を読み込みました")
    return trees