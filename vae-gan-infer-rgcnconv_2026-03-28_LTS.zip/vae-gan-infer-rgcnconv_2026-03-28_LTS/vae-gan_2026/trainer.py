# trainer.py

import copy
import math
import torch
import torch.nn as nn

from models import TreeVAE, Discriminator
from data_utils import prepare_dataloaders_from_pattern, save_pattern_and_data
from config_utils import load_config, compute_model_dims, make_discriminator_path
from graph_utils import NUM_EDGE_LABELS

def multiclass_recon_loss(logits, target_onehot, num_edge_labels):
    """
    logits: [num_nodes, max_node_size * K]
    target_onehot: 同形状の one-hot
    各 (i, j) ブロックを K クラス分類として CrossEntropy で学習する。
    """
    K = num_edge_labels

    logits_3d = logits.view(-1, K)                 # [(num_nodes * max_node_size), K]
    target_idx = target_onehot.view(-1, K).argmax(dim=1)  # [(num_nodes * max_node_size)]

    return torch.nn.functional.cross_entropy(logits_3d, target_idx)


def masked_child_origin_recon_loss(
    logits,
    target_onehot,
    num_edge_labels,
    num_real_nodes,
    ptr,
):
    """
    child_origin 用の再構成 loss。

    有効領域:
      - 各グラフごとに 0 <= j < i < n_real
    無効領域:
      - j >= i
      - i >= n_real
      - j >= n_real

    logits:        [total_nodes_in_batch, max_node_size * K]
    target_onehot: 同形状
    num_real_nodes:[batch_size] 相当
    ptr:           PyG batch ptr
    """
    K = num_edge_labels

    logits_3d = logits.view(logits.size(0), -1, K)                 # [total_nodes, max_node_size, K]
    target_idx = target_onehot.view(target_onehot.size(0), -1, K).argmax(dim=2)

    if num_real_nodes.dim() > 1:
        num_real_nodes = num_real_nodes.view(-1)

    total_loss = logits.new_tensor(0.0)
    total_count = 0

    batch_size = ptr.numel() - 1
    for b in range(batch_size):
        s = int(ptr[b].item())
        e = int(ptr[b + 1].item())

        local_logits = logits_3d[s:e]      # [max_node_size, max_node_size, K]
        local_target = target_idx[s:e]     # [max_node_size, max_node_size]

        max_node_size = e - s
        n_real = int(num_real_nodes[b].item())

        valid_mask = torch.tril(
            torch.ones((max_node_size, max_node_size), dtype=torch.bool, device=logits.device),
            diagonal=-1
        )

        if n_real < max_node_size:
            valid_mask[n_real:, :] = False
            valid_mask[:, n_real:] = False

        if valid_mask.any():
            total_loss = total_loss + torch.nn.functional.cross_entropy(
                local_logits[valid_mask],
                local_target[valid_mask],
                reduction='sum'
            )
            total_count += int(valid_mask.sum().item())

    if total_count == 0:
        return logits.sum() * 0.0

    return total_loss / total_count


def logits_to_soft_onehot(logits, num_edge_labels):
    probs = torch.softmax(
        logits.view(logits.size(0), -1, num_edge_labels),
        dim=2,
    )
    return probs.view_as(logits)


class EarlyStopping:
    def __init__(self, patience=30, delta=1e-4, path='best_model.pt', verbose=False):
        self.patience = patience
        self.delta = delta
        self.path = path
        self.verbose = verbose
        self.counter = 0
        self.best_loss = None
        self.early_stop = False

    def __call__(self, val_loss, model):
        if self.best_loss is None or val_loss < self.best_loss - self.delta:
            self.best_loss = val_loss
            self.counter = 0
            torch.save(model.state_dict(), self.path)
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True


def warmup_cosine_scheduler(optimizer, warmup_epochs, total_epochs):
    import math as _math

    def lr_lambda(epoch):
        if epoch < warmup_epochs:
            return float(epoch + 1) / float(max(1, warmup_epochs))
        progress = float(epoch - warmup_epochs) / float(max(1, total_epochs - warmup_epochs))
        return max(0.0, 0.5 * (1.0 + _math.cos(_math.pi * progress)))

    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


def build_models(fv_len, latent_dim, hidden_dims, K, device, total_epochs=300):
    model = TreeVAE(
        fv_len,
        fv_len,
        hidden_dims,
        latent_dim,
        NUM_EDGE_LABELS,
        K,
        device=device
    ).to(device)

    discriminator = Discriminator(
        fv_len,
        hidden_dims,
        NUM_EDGE_LABELS,
        K
    ).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=2e-4)
    opt_D = torch.optim.Adam(discriminator.parameters(), lr=1e-4)
    scheduler = warmup_cosine_scheduler(
        optimizer,
        warmup_epochs=20,
        total_epochs=total_epochs
    )

    return model, discriminator, optimizer, opt_D, scheduler


def train_model(
    model,
    discriminator,
    train_loader,
    test_loader,
    recon_criterion,
    optimizer,
    opt_D,
    scheduler,
    model_save_path='best_model.pt',
    beta_scheduler=None,
    lambda_scheduler=None,
    total_epochs=300
):
    device = model.device
    early_stopping = EarlyStopping(
        patience=30,
        delta=1e-4,
        path=model_save_path,
        verbose=True
    )

    prev_model = copy.deepcopy(model)
    prev_optimizer = copy.deepcopy(optimizer)
    validation_nan_counter = 0

    bce_logits = torch.nn.BCEWithLogitsLoss()
    label_smooth_real = 0.9
    max_grad_norm = 1.0

    disc_save_path = make_discriminator_path(model_save_path)

    for epoch in range(1, total_epochs + 1):
        model.train()
        discriminator.train()
        train_loss = 0.0

        current_beta = beta_scheduler(epoch, total_epochs) if beta_scheduler else 0.0
        current_lambda_gan = lambda_scheduler(epoch, total_epochs) if lambda_scheduler else 0.0

        for batch_idx, g in enumerate(train_loader):
            g = g.to(device)

            # ===== Forward =====
            N = g.x.size(0)
            x_hat, _, mean, log_var = model(
                g.x,
                g.edge_index,
                g.full_edge_index,
                g.tree_edge_type,
                g.full_edge_type,
                batch=g.batch,
                N=N,
                ptr=g.ptr
            )

            if epoch % 5 == 0 and batch_idx == 0:
                print(
                    f"[Debug] Epoch {epoch}, x_hat stats: "
                    f"min={x_hat.min().item():.3f}, "
                    f"max={x_hat.max().item():.3f}, "
                    f"mean={x_hat.mean().item():.3f}"
                )

            log_var = torch.clamp(log_var, -10.0, 10.0)
            recon_loss = recon_criterion(
                x_hat,
                g.x_target,
                g.num_real_nodes,
                g.ptr,
            )
            kl_loss = -0.5 * torch.mean(1 + log_var - mean.pow(2) - log_var.exp())

            # ===== Discriminator update =====
            opt_D.zero_grad(set_to_none=True)

            with torch.no_grad():
                x_fake_for_D = logits_to_soft_onehot(
                    x_hat.detach(),
                    NUM_EDGE_LABELS,
                )

            D_real = discriminator(
                g.x,
                g.full_edge_index,
                g.full_edge_type,
                batch=g.batch
            )
            D_fake = discriminator(
                x_fake_for_D,
                g.full_edge_index,
                g.full_edge_type,
                batch=g.batch
            )

            real_t = torch.ones_like(D_real) * label_smooth_real
            fake_t = torch.zeros_like(D_fake)

            loss_D = bce_logits(D_real, real_t) + bce_logits(D_fake, fake_t)

            if torch.isnan(loss_D):
                print("[warn] NaN in loss_D; skip step")
            else:
                loss_D.backward()
                torch.nn.utils.clip_grad_norm_(discriminator.parameters(), max_grad_norm)
                opt_D.step()

            # ===== Generator / Encoder update =====
            optimizer.zero_grad(set_to_none=True)

            x_fake_for_G = logits_to_soft_onehot(
                x_hat,
                NUM_EDGE_LABELS,
            )

            D_fake_for_G = discriminator(
                x_fake_for_G,
                g.full_edge_index,
                g.full_edge_type,
                batch=g.batch
            )
            adv_loss_G = bce_logits(
                D_fake_for_G,
                torch.ones_like(D_fake_for_G) * label_smooth_real
            )

            loss_vae = recon_loss + current_beta * kl_loss
            loss_total = loss_vae + current_lambda_gan * adv_loss_G

            if torch.isnan(loss_total):
                print("[warn] NaN in loss_total; skip step")
                model = copy.deepcopy(prev_model).to(device)
                optimizer = torch.optim.Adam(model.parameters(), lr=2e-4)
                optimizer.load_state_dict(prev_optimizer.state_dict())
                continue

            prev_model = copy.deepcopy(model)
            prev_optimizer = copy.deepcopy(optimizer)

            loss_total.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
            optimizer.step()

            train_loss += loss_total.item()

        train_loss /= max(1, len(train_loader))
        scheduler.step()

        # ===== Validation =====
        model.eval()
        val_loss = 0.0
        nan_in_validation = False

        with torch.no_grad():
            for g in test_loader:
                g = g.to(device)

                N = g.x.size(0)
                x_hat, _, mean, log_var = model(
                    g.x,
                    g.edge_index,
                    g.full_edge_index,
                    g.tree_edge_type,
                    g.full_edge_type,
                    batch=g.batch,
                    N=N,
                    ptr=g.ptr
                )

                recon_loss = recon_criterion(
                    x_hat,
                    g.x_target,
                    g.num_real_nodes,
                    g.ptr,
                )

                if torch.isnan(recon_loss):
                    print(f"NaN detected in validation at Epoch {epoch}!")
                    nan_in_validation = True
                    break

                val_loss += recon_loss.item()

        if nan_in_validation:
            validation_nan_counter += 1
            if validation_nan_counter >= 3:
                print("Exceeded allowed NaN limit. Early stopping triggered.")
                break
            continue
        else:
            validation_nan_counter = 0
            val_loss /= max(1, len(test_loader))

        print(
            f"Epoch: {epoch}, "
            f"Train Loss: {train_loss:.6f}, "
            f"Val Loss: {val_loss:.6f}, "
            f"LR: {scheduler.get_last_lr()[0]:.6f}, "
            f"beta: {current_beta:.4f}, "
            f"lambda_gan: {current_lambda_gan:.4f}"
        )

        prev_best = early_stopping.best_loss
        early_stopping(val_loss, model)

        if early_stopping.best_loss is not None and early_stopping.best_loss != prev_best:
            torch.save(discriminator.state_dict(), disc_save_path)

        if early_stopping.early_stop:
            print("Early stopping triggered.")
            break

    print(f"Final Validation Loss = {val_loss:.6f}")
    torch.save(discriminator.state_dict(), disc_save_path)


def run_training(
    P,
    edgelists,
    AddVertexNum,
    device,
    max_beta=0.05,
    K=3,
    batch_size=16,
    total_epochs=300,
    model_save_path='best_model.pt',
    edge_labels_list=None,
    split_seed=1234,
    augment_copies=0,
):
    save_pattern_and_data(P, edgelists, edge_labels_list=edge_labels_list)

    train_loader, test_loader, fv_len, PatVertexNum = prepare_dataloaders_from_pattern(
        P,
        edgelists,
        AddVertexNum,
        batch_size,
        edge_labels_list=edge_labels_list,
        split_seed=split_seed,
        augment_train=(augment_copies > 0),
        augment_copies=augment_copies,
        augment_seed=split_seed + 1000,
    )

    cfg = load_config()
    encoder_layers = cfg["vae_gan"].get("encoder_layers", 2)

    max_node_size = fv_len // NUM_EDGE_LABELS
    fv_len, latent_dim, hidden_dims = compute_model_dims(
        max_node_size=max_node_size,
        num_edge_labels=NUM_EDGE_LABELS,
        encoder_layers=encoder_layers
    )

    model, discriminator, optimizer, opt_D, scheduler = build_models(
        fv_len,
        latent_dim,
        hidden_dims,
        K,
        device,
        total_epochs=total_epochs
    )

    def recon_criterion(x_hat, x_target, num_real_nodes, ptr):
        return masked_child_origin_recon_loss(
            x_hat,
            x_target,
            NUM_EDGE_LABELS,
            num_real_nodes,
            ptr,
        )

    def get_beta(epoch, total_epochs, max_beta=max_beta):
        return max_beta * min(epoch / (0.3 * total_epochs), 1.0)

    def get_lambda_gan(epoch, total_epochs, max_lambda=0.02):
        warmup_epochs = max(1, int(0.2 * total_epochs))
        if epoch <= warmup_epochs:
            return max_lambda * (epoch / warmup_epochs)
        return max_lambda

    train_model(
        model,
        discriminator,
        train_loader,
        test_loader,
        recon_criterion,
        optimizer,
        opt_D,
        scheduler,
        model_save_path=model_save_path,
        beta_scheduler=get_beta,
        lambda_scheduler=get_lambda_gan,
        total_epochs=total_epochs
    )
