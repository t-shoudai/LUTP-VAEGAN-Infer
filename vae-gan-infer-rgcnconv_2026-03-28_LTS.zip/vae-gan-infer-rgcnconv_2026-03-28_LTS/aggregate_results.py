#!/usr/bin/env python3
from __future__ import annotations

import re
import argparse
import csv
import json
from pathlib import Path
from typing import Any, Dict, List


def flatten_dict(d: Dict[str, Any], prefix: str = "") -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for k, v in d.items():
        key = f"{prefix}{k}" if not prefix else f"{prefix}.{k}"
        if isinstance(v, dict):
            out.update(flatten_dict(v, key))
        else:
            out[key] = v
    return out


def read_json_if_exists(path: Path) -> Dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"[WARN] JSON 読み込み失敗: {path} : {e}")
        return None


def read_text_if_exists(path: Path) -> str:
    if not path.exists():
        return ""
    try:
        return path.read_text(encoding="utf-8")
    except Exception as e:
        print(f"[WARN] テキスト読み込み失敗: {path} : {e}")
        return ""


def extract_empirical_sweep(eval_text: str) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    if not eval_text:
        return out

    pat = re.compile(
        r"\[sweep\]\s*bank_size=(None|\d+),.*?select_mode=([A-Za-z0-9_]+),\s*sigma_scale=([0-9.]+).*?"
        r"Empirical-latent match rate:\s*([0-9.]+).*?"
        r"Empirical-latent unique graphs:\s*([0-9]+)",
        re.S,
    )

    for m in pat.finditer(eval_text):
        bank_raw, mode, sigma, mr, uniq = m.groups()
        key = "full" if bank_raw == "None" else f"bank{bank_raw}"
        out[key] = {
            "bank_size": None if bank_raw == "None" else int(bank_raw),
            "select_mode": mode,
            "sigma_scale": float(sigma),
            "match_rate": float(mr),
            "unique_graphs": int(uniq),
        }

    return out


def normalize_scalar(v: Any) -> Any:
    if v is None:
        return ""
    if isinstance(v, (list, tuple, dict)):
        return json.dumps(v, ensure_ascii=False)
    return v


def extract_row_from_experiment_dir(exp_dir: Path) -> Dict[str, Any]:
    row: Dict[str, Any] = {
        "experiment_dir": str(exp_dir),
        "summary_path": str(exp_dir / "summary.json"),
    }

    print(f"[INFO] 読み込み中: {exp_dir}")

    # ---- summary.json ----
    summary = read_json_if_exists(exp_dir / "summary.json")
    if summary:
        for key, value in summary.items():
            if isinstance(value, dict):
                row.update(flatten_dict(value, key))
            else:
                row[key] = value
    else:
        print(f"[WARN] summary.json がありません: {exp_dir / 'summary.json'}")

    # ---- config.json ----
    cfg = read_json_if_exists(exp_dir / "config.json")
    if cfg:
        common = cfg.get("common", {})
        pipeline = cfg.get("pipeline", {})
        vae = cfg.get("vae_gan", {})

        row.setdefault("config.config_path", str(exp_dir / "config.json"))
        row.setdefault("config.config_name", "config.json")
        row.setdefault("config.config_stem", "config")

        if not row.get("config.seed"):
            row["config.seed"] = vae.get("seed", "")
        if not row.get("config.num_pos"):
            row["config.num_pos"] = vae.get("num_pos", "")
        if not row.get("config.gen_strategy"):
            row["config.gen_strategy"] = vae.get("gen_strategy", "")
        if not row.get("config.empirical_bank_size"):
            row["config.empirical_bank_size"] = vae.get("empirical_bank_size", "")
        if not row.get("config.empirical_bank_select_mode"):
            row["config.empirical_bank_select_mode"] = vae.get("empirical_bank_select_mode", "")
        if not row.get("config.empirical_sigma_scale"):
            row["config.empirical_sigma_scale"] = vae.get("empirical_sigma_scale", "")
        if not row.get("config.augment_copies"):
            row["config.augment_copies"] = vae.get("augment_copies", "")
        if not row.get("config.add_nodes"):
            row["config.add_nodes"] = common.get("add_nodes", "")
        if not row.get("config.n_samples"):
            row["config.n_samples"] = pipeline.get("n_samples", "")
    else:
        print(f"[WARN] config.json がありません: {exp_dir / 'config.json'}")

    # ---- pattern_eval.json ----
    pattern_eval = read_json_if_exists(exp_dir / "pattern_eval.json")
    if pattern_eval:
        for k, v in pattern_eval.items():
            row[f"pattern_eval.{k}"] = v

    # ---- logs ----
    eval_text = read_text_if_exists(exp_dir / "eval_report.txt")
    gen_text = read_text_if_exists(exp_dir / "generate_log.txt")
    refine_text = read_text_if_exists(exp_dir / "refine_log.txt")

    # encoded_z / mu_profile
    if not row.get("vae_eval.encoded_z"):
        m = re.search(r"Match rate from encoded z:\s*([0-9.]+)", eval_text, re.IGNORECASE)
        if m:
            row["vae_eval.encoded_z"] = float(m.group(1))

    if not row.get("vae_eval.mu_profile"):
        m = re.search(r"μ-profile scaled match rate:\s*([0-9.]+)", eval_text, re.IGNORECASE)
        if m:
            row["vae_eval.mu_profile"] = float(m.group(1))

    # empirical sweep 補完
    empirical_sweep = extract_empirical_sweep(eval_text)
    for key, d in empirical_sweep.items():
        for subk, subv in d.items():
            row[f"vae_eval_empirical_sweep.{key}.{subk}"] = subv

    # selected bank に対応する empirical_latent を補完
    if not row.get("vae_eval.empirical_latent"):
        selected_bank = row.get("config.empirical_bank_size", "")
        selected_key = "full" if selected_bank in ("", None) else f"bank{int(float(selected_bank))}"
        if selected_key in empirical_sweep:
            row["vae_eval.empirical_latent"] = empirical_sweep[selected_key]["match_rate"]
            row["vae_eval.empirical_latent_unique"] = empirical_sweep[selected_key]["unique_graphs"]

    # generate unique / total
    if not row.get("generate_eval.unique_graphs"):
        m = re.search(r"非同型グラフ数:\s*([0-9]+)/([0-9]+)\s*試行", gen_text)
        if m:
            row["generate_eval.unique_graphs"] = int(m.group(1))
            row["generate_eval.max_trials"] = int(m.group(2))

    if not row.get("generate_eval.total_gen"):
        m = re.search(r"blind生成完了(?:\(cluster-center\))?:\s*総生成=([0-9]+)\s*件", gen_text)
        if m:
            row["generate_eval.total_gen"] = int(m.group(1))

    # debug 生成だけは match_rate を拾える
    if not row.get("generate_eval.match_rate"):
        m = re.search(r"Generate match rate \(oracle debug\):\s*([0-9.]+)\s*\(([0-9]+/[0-9]+)\)", gen_text)
        if m:
            row["generate_eval.match_rate"] = float(m.group(1))
            row["generate_eval.match_rate_count"] = m.group(2)

    # Pprime vs original
    if not row.get("pattern_eval.Pprime_vs_original_match_rate"):
        m = re.search(r"Pprime vs original match rate:\s*([0-9.]+)\s*\(([0-9]+/[0-9]+)\)", refine_text)
        if m:
            row["pattern_eval.Pprime_vs_original_match_rate"] = float(m.group(1))
            row["pattern_eval.Pprime_vs_original_count"] = m.group(2)

    for k, v in list(row.items()):
        row[k] = normalize_scalar(v)

    return row


def build_fieldnames(rows: List[Dict[str, Any]]) -> List[str]:
    preferred = [
        "config.seed",
        "timestamp",
        "config.config_name",
        "config.config_stem",
        "config.config_path",
        "experiment_dir",
        "summary_path",
        "config.num_pos",
        "config.gen_strategy",
        "config.empirical_bank_size",
        "config.empirical_bank_select_mode",
        "config.empirical_sigma_scale",
        "config.augment_copies",
        "pattern_eval.P  DFUDS",
        "pattern_eval.P' DFUDS",
        "pattern_eval.ノード数の差 (P'- P)",
        "pattern_eval.辺数の差 (P'- P)",
        "pattern_eval.変数数の差 (P'- P)",
        "pattern_eval.DFUDS長の差 (P'- P)",
        "pattern_eval.特化度 (node増加率)",
        "pattern_eval.Pprime_vs_original_match_rate",
        "vae_eval.encoded_z",
        "vae_eval.empirical_latent",
        "vae_eval.empirical_latent_unique",
        "vae_eval.mu_profile",
        "generate_eval.match_rate",
        "generate_eval.unique_graphs",
    ]

    seen = set()
    fields: List[str] = []

    for key in preferred:
        if any(key in row for row in rows):
            fields.append(key)
            seen.add(key)

    extras = sorted({k for row in rows for k in row.keys()} - seen)
    fields.extend(extras)
    return fields


def write_csv(path: Path, rows: List[Dict[str, Any]], fieldnames: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="experiments から 1実験1行のCSVを作る")
    parser.add_argument("--experiments-dir", default="experiments")
    parser.add_argument("--output", default="runs.csv")
    return parser.parse_args()


def main() -> None:
    print("[INFO] aggregate_results.py を開始しました")

    args = parse_args()
    print(f"[INFO] experiments-dir = {args.experiments_dir}")
    print(f"[INFO] output          = {args.output}")

    experiments_dir = Path(args.experiments_dir)
    output_path = Path(args.output)

    if not experiments_dir.exists():
        print(f"[ERROR] ディレクトリが存在しません: {experiments_dir}")
        return

    if not experiments_dir.is_dir():
        print(f"[ERROR] ディレクトリではありません: {experiments_dir}")
        return

    exp_dirs = sorted([p for p in experiments_dir.iterdir() if p.is_dir()])
    print(f"[INFO] 実験ディレクトリ数: {len(exp_dirs)}")

    if not exp_dirs:
        print("[ERROR] experiments 配下に実験ディレクトリがありません")
        return

    rows: List[Dict[str, Any]] = []
    for exp_dir in exp_dirs:
        row = extract_row_from_experiment_dir(exp_dir)
        rows.append(row)

    print(f"[INFO] 抽出行数: {len(rows)}")

    fieldnames = build_fieldnames(rows)
    print(f"[INFO] 列数: {len(fieldnames)}")

    write_csv(output_path, rows, fieldnames)
    print(f"[INFO] 出力完了: {output_path}")


if __name__ == "__main__":
    main()