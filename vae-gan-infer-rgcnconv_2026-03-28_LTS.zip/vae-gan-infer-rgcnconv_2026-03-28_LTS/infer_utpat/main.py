import argparse
import os
from tqdm import tqdm
import random
import copy
import networkx as nx
import treepatlib as tpl
import treepatlib.infer
import importlib
importlib.reload(treepatlib.infer)

# ---- デフォルト設定 ----
ROOT_NAME = '#'
VARIABLE_NAME = 'X'

import json as _json
import os as _os

def _load_config(path=None):
    if path is None:
        env_path = _os.environ.get("CONFIG_PATH")
        if env_path:
            path = env_path
        else:
            path = _os.path.join(
                _os.path.dirname(_os.path.abspath(__file__)),
                "../config.json"
            )

    with open(path, "r", encoding="utf-8") as f:
        return _json.load(f)


def _normalize_edge_labels(raw_edge_labels):
    if isinstance(raw_edge_labels, int):
        if raw_edge_labels <= 0:
            raise ValueError("common.edge_labels must be a positive integer")
        if raw_edge_labels > 26:
            raise ValueError("common.edge_labels > 26 is not supported")
        return [chr(ord("a") + i) for i in range(raw_edge_labels)]

    if isinstance(raw_edge_labels, (list, tuple)):
        labels = [str(x) for x in raw_edge_labels]
        if not labels:
            raise ValueError("common.edge_labels list must not be empty")
        return labels

    raise TypeError(
        "common.edge_labels must be either an int or a list/tuple of labels"
    )


_cfg = _load_config()
_infer_cfg = _cfg.get("infer_utpat", {})
_common_cfg = _cfg.get("common", {})
_pipeline_cfg = _cfg.get("pipeline", {})

PATTERN_MIN_NODES = _infer_cfg.get("pattern_min_nodes", 2)
PATTERN_MAX_NODES = _infer_cfg.get("pattern_max_nodes", max(PATTERN_MIN_NODES, 10))
EDGE_FACTOR = _normalize_edge_labels(_common_cfg.get("edge_labels", 5))


# ============================================================
# ユーティリティ：DFUDS 変換・保存
# ============================================================

def graph_to_dfuds(G):
    """nx.DiGraph を DFUDS 文字列に変換する。"""
    return tpl.dfuds(G)


def save_pattern(G, file_path):
    """パターン木を DFUDS 形式で保存する。"""
    dfuds = graph_to_dfuds(G)
    with open(file_path, 'w') as f:
        f.write(dfuds + '\n')
    return dfuds


def load_positive_from_txt(file_path):
    trees = []

    with open(file_path, encoding="utf-8") as f:
        for lineno, line in enumerate(f, start=1):
            s = line.strip()
            if not s:
                continue

            # "1: DFUDS" / "0: DFUDS" 形式にも対応
            if ": " in s:
                head, tail = s.split(": ", 1)
                if head in {"0", "1"}:
                    s = tail.strip()

            try:
                trees.append(tpl.return_to_graph(s))
            except Exception as e:
                print(f"[warn] line {lineno} could not be parsed and was skipped: {e}")

    return trees


def load_pattern(file_path):
    """DFUDS 形式のファイルからパターン木を読み込む。"""
    with open(file_path) as f:
        dfuds = f.readline().strip()
    return tpl.return_to_graph(dfuds), dfuds


# ============================================================
# ユーティリティ：パターン差異評価
# ============================================================

def evaluate_patterns(P, P_prime, label_P='P', label_P_prime="P'"):
    """
    元のパターン P と精密化後のパターン P' の差異を評価する。

    Returns
    -------
    dict
        各評価指標の値。
    """
    n_P  = P.number_of_nodes()
    n_Pp = P_prime.number_of_nodes() if P_prime else 0
    e_P  = P.number_of_edges()
    e_Pp = P_prime.number_of_edges() if P_prime else 0

    # 変数ノード数
    var_P  = sum(1 for v in P.nodes()      if P.nodes[v]['name']       == VARIABLE_NAME)
    var_Pp = sum(1 for v in P_prime.nodes() if P_prime.nodes[v]['name'] == VARIABLE_NAME) if P_prime else 0

    # DFUDS 文字列長の差
    dfuds_P  = graph_to_dfuds(P)
    dfuds_Pp = graph_to_dfuds(P_prime) if P_prime else ''

    # 特化度：ノード数増加率（P' が P より大きいほど特化している）
    specificity = (n_Pp - n_P) / n_P if n_P > 0 else 0

    result = {
        f'{label_P}  ノード数':       n_P,
        f"{label_P_prime} ノード数":  n_Pp,
        'ノード数の差 (P\'- P)':      n_Pp - n_P,
        f'{label_P}  辺数':           e_P,
        f"{label_P_prime} 辺数":      e_Pp,
        '辺数の差 (P\'- P)':          e_Pp - e_P,
        f'{label_P}  変数数':         var_P,
        f"{label_P_prime} 変数数":    var_Pp,
        '変数数の差 (P\'- P)':        var_Pp - var_P,
        f'{label_P}  DFUDS長':        len(dfuds_P),
        f"{label_P_prime} DFUDS長":   len(dfuds_Pp),
        'DFUDS長の差 (P\'- P)':       len(dfuds_Pp) - len(dfuds_P),
        '特化度 (node増加率)':         round(specificity, 4),
        f'{label_P}  DFUDS':          dfuds_P,
        f"{label_P_prime} DFUDS":     dfuds_Pp,
    }
    return result


def print_evaluation(result):
    """評価結果を見やすく表示する。"""
    print()
    print('=' * 60)
    print(' パターン差異評価レポート')
    print('=' * 60)
    for k, v in result.items():
        if 'DFUDS' in k and len(str(v)) > 60:
            print(f'  {k}:')
            print(f'    {v}')
        else:
            print(f'  {k}: {v}')
    print('=' * 60)


def save_evaluation(result, file_path):
    """評価結果を JSON 形式で保存する。"""
    import json
    with open(file_path, 'w') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(f'  評価結果を {file_path} に保存しました')


# ============================================================
# 木生成・パターン生成
# ============================================================

def make_random_tree(num_nodes, edge_factor):
    G = nx.DiGraph()
    G.add_node(0, name=ROOT_NAME)
    for i in range(1, num_nodes):
        parent = random.randint(0, i - 1)
        label = random.choice(edge_factor)
        G.add_node(i, name=label)
        G.add_edge(parent, i)
    return G


def make_pattern(num_pattern, min_nodes, max_nodes, edge_factor):
    pattern_list = []
    for _ in range(num_pattern):
        num_nodes = random.randint(min_nodes, max_nodes)
        G = make_random_tree(num_nodes, edge_factor)
        leaves = [v for v in G.nodes()
                  if G.out_degree(v) == 0 and v != 0]
        if len(leaves) == 1:
            num_variables = 1
        else:
            num_variables = random.randint(1, len(leaves) - 1)
        variable_leaves = random.sample(leaves, num_variables)
        for v in variable_leaves:
            G.nodes[v]['name'] = VARIABLE_NAME
        # 標準形に変換（matching が正しく動くために必要）
        G = tpl.left_depth_priferred_tree(G)
        pattern_list.append(G)
    return pattern_list


def load_substitute_trees(num_vars, added_nodes,
                          tree_dir='unordered_trees', max_trees=10000):
    base = added_nodes // num_vars
    remainder = added_nodes % num_vars
    node_counts = {base + 2}
    if remainder > 0:
        node_counts.add(base + 3)
    lines = []
    for n in sorted(node_counts):
        path = os.path.join(tree_dir, f'{n}.txt')
        if not os.path.exists(path):
            continue
        with open(path) as f:
            lines.extend([l.strip() for l in f if l.strip()])
    if len(lines) > max_trees:
        lines = random.sample(lines, max_trees)
    return [tpl.return_to_graph(l) for l in lines]


# ============================================================
# run モード
# ============================================================

def run_mode(args):
    """パターン生成 → 正例生成 → 帰納学習"""
    ops = tpl.infer.make_refinement_operators(EDGE_FACTOR)
    Pattern = make_pattern(args.loop, PATTERN_MIN_NODES, PATTERN_MAX_NODES, EDGE_FACTOR)

    for loop_idx, P in enumerate(Pattern):
        print(f"=== LOOP {loop_idx} ===")
        try:
            tpl.draw.tree_draw(P, None, show=True)
        except Exception as e:
            print(f"  [描画スキップ] パターン描画エラー: {e}")

        # 元のパターン P を DFUDS 保存
        p_out = f'{args.pattern_out}_{loop_idx}_P.txt'
        dfuds_P = save_pattern(P, p_out)
        print(f"  元パターン P を {p_out} に保存 (DFUDS長: {len(dfuds_P)})")

        num_vars = sum(1 for v in P.nodes() if P.nodes[v]['name'] == VARIABLE_NAME)
        substitute_trees = load_substitute_trees(num_vars, args.add_nodes)
        print(f"  変数数: {num_vars}, 代入候補: {len(substitute_trees)} 本")

        Positive = tpl.unordered.make_positive(args.num_pos, substitute_trees, P)
        print(f"  正例: {len(Positive)} 件")

        file_name = f'{args.output}_{loop_idx}'
        if os.path.exists(file_name + '.txt'):
            os.remove(file_name + '.txt')
        for tree in Positive:
            tpl.tree_save(tree, class_=1, file_name=file_name)
        print(f"  {file_name}.txt に保存しました")

        t_init = tpl.infer.initial_pattern()
        print("  精密化開始...")
        result = tpl.infer.refine_pattern(
            t_init, Positive, EDGE_FACTOR,
            verbose=True,
        )

        # 精密化後のパターン P' を DFUDS 保存
        pp_out = f'{args.pattern_out}_{loop_idx}_Pprime.txt'
        if result:
            dfuds_Pp = save_pattern(result, pp_out)
            print(f"  精密化パターン P' を {pp_out} に保存 (DFUDS長: {len(dfuds_Pp)})")
        else:
            print("  精密化失敗: P' なし")

        print(f"  P  ノード数: {P.number_of_nodes()}")
        print(f"  P' ノード数: {result.number_of_nodes() if result else 'N/A'}")

        # 評価
        if args.eval and result:
            eval_result = evaluate_patterns(P, result)
            print_evaluation(eval_result)
            eval_out = f'{args.pattern_out}_{loop_idx}_eval.json'
            save_evaluation(eval_result, eval_out)

        try:
            tpl.tree_draw(result)
        except Exception as e:
            print(f"  [描画スキップ] 結果描画エラー: {e}")


# ============================================================
# refine モード
# ============================================================

def refine_mode(args):
    """vae-gan_2026 の generated.txt を使って帰納学習"""

    print(f"読み込み: {args.generated}")
    Positive = load_positive_from_txt(args.generated)
    print(f"正例: {len(Positive)} 件")

    if len(Positive) == 0:
        print("  [エラー] 正例が0件です。generated.txt の内容を確認してください。")
        return

    ops = tpl.infer.make_refinement_operators(EDGE_FACTOR)
    t_init = tpl.infer.initial_pattern()
    print("精密化開始...")
    result = tpl.infer.refine_pattern(
        t_init, Positive, EDGE_FACTOR,
        verbose=True,
    )
    print(f"精密化パターン P': {result}")

    # 精密化後のパターン P' を DFUDS 保存
    pp_out = args.pattern_out + '_Pprime.txt'
    if result:
        dfuds_Pp = save_pattern(result, pp_out)
        print(f"P' を {pp_out} に保存 (DFUDS長: {len(dfuds_Pp)})")

    if result and args.original and args.original and os.path.exists(args.original):
        orig_trees = load_positive_from_txt(args.original)
        if orig_trees:
            print(f"Pprime vs original: computing {len(orig_trees)} matches...")
            n_match = 0
            for _t in tqdm(orig_trees, desc="matching", unit="tree"):
                if tpl.unordered.matching(result, _t):
                    n_match += 1
            _orig_rate = n_match / len(orig_trees)
            _orig_count = f"{n_match}/{len(orig_trees)}"
            print(f"Pprime vs original match rate: {_orig_rate:.6f} ({_orig_count})")

    if args.eval and args.pattern_in and os.path.exists(args.pattern_in):
        P, dfuds_P = load_pattern(args.pattern_in)
        print(f"元パターン P を {args.pattern_in} から読み込みました")
        if result:
            eval_result = evaluate_patterns(P, result)
            print_evaluation(eval_result)
            eval_out = args.pattern_out + '_eval.json'
            save_evaluation(eval_result, eval_out)
            # Pprime_vs_original マッチ率を eval.json に追記
            if '_orig_rate' in dir() and '_orig_count' in dir():
                import json as _jj
                _ev = _jj.load(open(eval_out))
                _ev['Pprime_vs_original_match_rate'] = _orig_rate
                _ev['Pprime_vs_original_count'] = _orig_count
                _jj.dump(_ev, open(eval_out, 'w'), ensure_ascii=False, indent=2)
                print(f'Pprime_vs_original_match_rate を {eval_out} に追記')
    elif args.eval:
        print("  [注意] --pattern_in が指定されていないため、P vs P' の差異評価をスキップします")


# ============================================================
# main
# ============================================================

def main():
    parser = argparse.ArgumentParser(description='infer_utpat: 無順序木パターン帰納学習')
    parser.add_argument('--mode', choices=['run', 'refine'], required=True,
                        help='run: パターン生成+帰納学習 / refine: 生成ファイルから帰納学習')

    # --- run モード ---
    parser.add_argument('--loop', type=int, default=_infer_cfg.get('loop', 1),
                        help='run モード: 生成するパターン数（デフォルト: 1）')
    parser.add_argument('--num_pos', type=int, default=_infer_cfg.get('num_pos', 500),
                        help='run モード: 生成する正例数（デフォルト: 500）')
    parser.add_argument('--add_nodes', type=int, default=_common_cfg.get('add_nodes', 10),
                        help='変数への代入で増加する頂点数の合計')
    parser.add_argument('--output', type=str, default='dataset',
                        help='run モード: 正例データセットのファイル名プレフィックス（デフォルト: dataset）')

    # --- refine モード ---
    parser.add_argument('--generated', type=str, default='../vae-gan_2026/generated.txt',
                        help='refine モード: vae-gan_2026 の生成ファイルパス')

    # --- パターン保存・評価（共通） ---
    parser.add_argument(
        '--pattern_out',
        type=str,
        default=_infer_cfg.get(
            'pattern_out',
            _pipeline_cfg.get('pattern_out', 'pattern')
        ),
        help='パターン保存ファイル名のプレフィックス'
    )
    parser.add_argument('--pattern_in', type=str, default=None,
                        help='refine モード: 比較元パターン P の DFUDS ファイルパス（--eval 時に使用）')



    parser.add_argument('--original', type=str, default=None)
    parser.add_argument('--eval', action='store_true',
                        help='P と P\' の差異評価レポートを出力する')

    args = parser.parse_args()

    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    if args.mode == 'run':
        run_mode(args)
    elif args.mode == 'refine':
        refine_mode(args)


if __name__ == '__main__':
    main()
