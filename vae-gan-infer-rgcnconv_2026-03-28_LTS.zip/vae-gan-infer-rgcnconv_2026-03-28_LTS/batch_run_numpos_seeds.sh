#!/bin/bash
set -u
set -o pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG_DIR="$SCRIPT_DIR/configs"
RUN_PIPELINE="$SCRIPT_DIR/run_pipeline.sh"
LOG_DIR="$SCRIPT_DIR/batch_logs"
mkdir -p "$LOG_DIR"

# 実験計画に対応した config 群
CONFIGS=(
  "config.json"
#  "empirical/np500_bank100.json"
#  "empirical/np1000_bank100.json"
#  "empirical/np2000_bank100.json"
#  "empirical/np1000_bankfull.json"
#  "empirical/np1000_bank20.json"
#  "ablations/np1000_aug0_bank100.json"
#  "ablations/np1000_aug1_bank100.json"
)

# seed 群
SEEDS=(
  1234
#  1235
#  1236
#  1237
#  1238
)

if [ ! -f "$RUN_PIPELINE" ]; then
  echo "[ERROR] run_pipeline.sh が見つかりません: $RUN_PIPELINE"
  exit 1
fi

if [ ! -d "$CONFIG_DIR" ]; then
  echo "[ERROR] configs ディレクトリが見つかりません: $CONFIG_DIR"
  exit 1
fi

TOTAL=0
FAILED=0
SKIPPED=0

for cfg_rel in "${CONFIGS[@]}"; do
  CFG_PATH="$CONFIG_DIR/$cfg_rel"

  if [ ! -f "$CFG_PATH" ]; then
    echo "[WARN] 設定ファイルが見つからないのでスキップします: $CFG_PATH"
    SKIPPED=$((SKIPPED + 1))
    continue
  fi

  CFG_NAME="$(basename "$cfg_rel")"
  CFG_STEM="${CFG_NAME%.json}"

  for seed in "${SEEDS[@]}"; do
    TOTAL=$((TOTAL + 1))
    RUN_NAME="${CFG_STEM}_seed${seed}"
    RUN_LOG="$LOG_DIR/${RUN_NAME}.log"

    {
      echo "========================================"
      echo "START : $RUN_NAME"
      echo "CONFIG: $CFG_PATH"
      echo "SEED  : $seed"
      echo "TIME  : $(date '+%Y-%m-%d %H:%M:%S')"
      echo "========================================"
    } | tee "$RUN_LOG"

    if CONFIG_PATH="$CFG_PATH" SEED_OVERRIDE="$seed" bash "$RUN_PIPELINE" 2>&1 | tee -a "$RUN_LOG"; then
      echo "[OK] $RUN_NAME" | tee -a "$RUN_LOG"
    else
      FAILED=$((FAILED + 1))
      echo "[FAIL] $RUN_NAME" | tee -a "$RUN_LOG"
    fi

    echo | tee -a "$RUN_LOG"
  done
done

echo "========================================"
echo "Batch 完了"
echo "TOTAL  : $TOTAL"
echo "FAILED : $FAILED"
echo "SKIPPED: $SKIPPED"
echo "LOG_DIR: $LOG_DIR"
echo "========================================"

if [ "$FAILED" -gt 0 ]; then
  exit 1
fi
