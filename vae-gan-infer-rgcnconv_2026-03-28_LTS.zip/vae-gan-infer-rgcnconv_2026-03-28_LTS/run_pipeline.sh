#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VAE_DIR="$SCRIPT_DIR/vae-gan_2026"
INFER_DIR="$SCRIPT_DIR/infer_utpat"
CONFIG="${CONFIG_PATH:-$SCRIPT_DIR/config.json}"

if [ ! -f "$CONFIG" ]; then
    echo "[ERROR] 設定ファイルが見つかりません: $CONFIG"
    exit 1
fi

CONFIG_BASENAME="$(basename "$CONFIG")"
CONFIG_STEM="${CONFIG_BASENAME%.json}"

if ! command -v python3 >/dev/null 2>&1 && ! command -v python >/dev/null 2>&1; then
    echo "[ERROR] python / python3 が見つかりません。"
    exit 1
fi
PYTHON=$(command -v python3 || command -v python)

read_cfg() {
    $PYTHON -c "import json; d=json.load(open('$CONFIG', encoding='utf-8')); print(d$1)"
}

CONDA_ENV=$(read_cfg "['pipeline']['conda_env']")
PAT_NODES=$(read_cfg "['vae_gan']['pat_nodes']")
ADD_NODES=$(read_cfg "['common']['add_nodes']")
NUM_POS=$(read_cfg "['vae_gan']['num_pos']")
MAX_BETA=$(read_cfg "['vae_gan']['max_beta']")
K=$(read_cfg "['vae_gan']['K']")
TOTAL_EPOCHS=$(read_cfg "['vae_gan']['total_epochs']")
CFG_SEED=$(read_cfg "['vae_gan']['seed']")
SEED="${SEED_OVERRIDE:-$CFG_SEED}"
MODEL_PATH=$(read_cfg "['vae_gan']['model_path']")
OUTPUT_NAME=$(read_cfg "['vae_gan']['output']")

EVAL_NUM_SAMPLES=$(read_cfg "['vae_gan']['eval_num_samples']")
N_SAMPLES=$(read_cfg "['pipeline']['n_samples']")
INFER_ADD_NODES=$(read_cfg "['pipeline']['infer_add_nodes']")
PATTERN_OUT=$(read_cfg "['pipeline']['pattern_out']")
EDGE_LABELS=$(read_cfg "['common']['edge_labels']")
GEN_STRATEGY=$(read_cfg "['vae_gan']['gen_strategy']")

EMP_BANK_SIZE=$(read_cfg "['vae_gan'].get('empirical_bank_size', None)")
EMP_BANK_SELECT_MODE=$(read_cfg "['vae_gan'].get('empirical_bank_select_mode', 'fps')")
EMP_SIGMA_SCALE=$(read_cfg "['vae_gan'].get('empirical_sigma_scale', 0.15)")
AUGMENT_COPIES=$(read_cfg "['vae_gan'].get('augment_copies', 0)")

EMPIRICAL_ARGS=(
    --empirical_bank_select_mode "$EMP_BANK_SELECT_MODE"
    --empirical_sigma_scale "$EMP_SIGMA_SCALE"
)

if [ -n "${EMP_BANK_SIZE:-}" ] && [ "$EMP_BANK_SIZE" != "None" ]; then
    EMPIRICAL_ARGS+=(
        --empirical_bank_size "$EMP_BANK_SIZE"
    )
fi

TRAIN_AUG_ARGS=(
    --augment_copies "$AUGMENT_COPIES"
)

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
EXP_DIR="$SCRIPT_DIR/experiments/${TIMESTAMP}_${CONFIG_STEM}_seed${SEED}"
mkdir -p "$EXP_DIR"
cp "$CONFIG" "$EXP_DIR/config.json"

MODEL_BASENAME="$(basename "$MODEL_PATH")"
MODEL_ROOT="${MODEL_BASENAME%.*}"
MODEL_EXT="${MODEL_BASENAME##*.}"
if [ "$MODEL_EXT" = "$MODEL_BASENAME" ]; then
    MODEL_EXT="pt"
fi
if [[ "$MODEL_ROOT" == *_model ]]; then
    DISC_BASENAME="${MODEL_ROOT%_model}_discriminator.${MODEL_EXT}"
else
    DISC_BASENAME="${MODEL_ROOT}_discriminator.${MODEL_EXT}"
fi

if command -v conda >/dev/null 2>&1; then
    eval "$(conda shell.bash hook)"
    conda activate "$CONDA_ENV"
elif [ -f "$HOME/miniconda3/etc/profile.d/conda.sh" ]; then
    source "$HOME/miniconda3/etc/profile.d/conda.sh"
    conda activate "$CONDA_ENV"
elif [ -f "$HOME/anaconda3/etc/profile.d/conda.sh" ]; then
    source "$HOME/anaconda3/etc/profile.d/conda.sh"
    conda activate "$CONDA_ENV"
elif [ -f "/opt/conda/etc/profile.d/conda.sh" ]; then
    source "/opt/conda/etc/profile.d/conda.sh"
    conda activate "$CONDA_ENV"
else
    echo "[ERROR] conda が見つかりません。"
    exit 1
fi

if command -v python >/dev/null 2>&1; then
    PYTHON=python
elif command -v python3 >/dev/null 2>&1; then
    PYTHON=python3
fi

echo "========================================"
echo " Pipeline: train -> eval -> generate -> refine"
echo "========================================"
echo "実験フォルダ : $EXP_DIR"
echo "CONFIG_PATH=$CONFIG"
echo "CONFIG_NAME=$CONFIG_BASENAME"
echo "EDGE_LABELS  : $EDGE_LABELS"
echo "PAT_NODES=$PAT_NODES  ADD_NODES=$ADD_NODES  NUM_POS=$NUM_POS"
echo "MAX_BETA=$MAX_BETA  K=$K  N_SAMPLES=$N_SAMPLES"
echo "MODEL_PATH=$MODEL_PATH"
echo "DISC_PATH=$DISC_BASENAME"
echo "OUTPUT=$OUTPUT_NAME"
echo "GEN_STRATEGY=$GEN_STRATEGY"
echo "EMP_BANK_SIZE=$EMP_BANK_SIZE"
echo "EMP_BANK_SELECT_MODE=$EMP_BANK_SELECT_MODE"
echo "EMP_SIGMA_SCALE=$EMP_SIGMA_SCALE"
echo "AUGMENT_COPIES=$AUGMENT_COPIES"
echo "CFG_SEED=$CFG_SEED"
echo "SEED=$SEED"
echo ""

echo "[Step 1/4] vae-gan_2026: 訓練 (train)"
echo "----------------------------------------"
cd "$VAE_DIR"
$PYTHON -u main.py \
    --mode train \
    --pat_nodes "$PAT_NODES" \
    --add_nodes "$ADD_NODES" \
    --num_pos "$NUM_POS" \
    --max_beta "$MAX_BETA" \
    --K "$K" \
    --model_path "$MODEL_PATH" \
    --total_epochs "$TOTAL_EPOCHS" \
    --seed "$SEED" \
    "${TRAIN_AUG_ARGS[@]}" \
    2>&1 | tee "$EXP_DIR/train_log.txt"

cp "$MODEL_PATH" "$EXP_DIR/$MODEL_BASENAME"
if [ -f "$DISC_BASENAME" ]; then
    cp "$DISC_BASENAME" "$EXP_DIR/$DISC_BASENAME"
fi
cp pattern_and_data.pkl "$EXP_DIR/pattern_and_data.pkl"
cp pattern_P.txt "$EXP_DIR/pattern_P.txt"
if [ -f original_positive.txt ]; then
    cp original_positive.txt "$EXP_DIR/original_positive.txt"
fi
echo "[Step 1/4] 完了"
echo ""

echo "[Step 2/4] vae-gan_2026: 評価 (eval)"
echo "----------------------------------------"
$PYTHON -u main.py \
    --mode eval \
    --model_path "$VAE_DIR/$MODEL_BASENAME" \
    --add_nodes "$ADD_NODES" \
    --eval_samples "$EVAL_NUM_SAMPLES" \
    --seed "$SEED" \
    "${EMPIRICAL_ARGS[@]}" \
    2>&1 | tee "$EXP_DIR/eval_report.txt"

echo "[Step 2/4] 完了"
echo ""

echo "[Step 3/4] vae-gan_2026: 木の生成 (generate)"
echo "----------------------------------------"
$PYTHON -u main.py \
    --mode generate \
    --gen_strategy "$GEN_STRATEGY" \
    --model_path "$VAE_DIR/$MODEL_BASENAME" \
    --generate_samples "$N_SAMPLES" \
    --output "$OUTPUT_NAME" \
    --add_nodes "$ADD_NODES" \
    --seed "$SEED" \
    "${EMPIRICAL_ARGS[@]}" \
    2>&1 | tee "$EXP_DIR/generate_log.txt"

cp "${OUTPUT_NAME}.txt" "$EXP_DIR/generated.txt"
echo "[Step 3/4] 完了"
echo ""

echo "[Step 4/4] infer_utpat: 帰納学習 + 評価 (refine)"
echo "----------------------------------------"
if [ "$GEN_STRATEGY" = "cluster_center_debug" ]; then
    echo "[Step 4/4] skip: gen_strategy=$GEN_STRATEGY では generated.txt がラベル付きのため refine しません"
    echo ""
else
    cd "$INFER_DIR"
    $PYTHON -u main.py \
        --mode refine \
        --generated "$VAE_DIR/${OUTPUT_NAME}.txt" \
        --add_nodes "$INFER_ADD_NODES" \
        --pattern_out "$PATTERN_OUT" \
        --pattern_in "$VAE_DIR/pattern_P.txt" \
        --original "$VAE_DIR/original_positive.txt" \
        --eval \
        2>&1 | tee "$EXP_DIR/refine_log.txt"

    cp "${PATTERN_OUT}_Pprime.txt" "$EXP_DIR/pattern_Pprime.txt"
    cp "${PATTERN_OUT}_eval.json" "$EXP_DIR/pattern_eval.json"
    echo "[Step 4/4] 完了"
    echo ""
fi

$PYTHON - <<PYEOF
import json, os, re
import treepatlib as tpl

exp_dir = "$EXP_DIR"
cfg = json.load(open(os.path.join(exp_dir, "config.json"), encoding="utf-8"))


def r8(x):
    if x is None:
        return None
    return round(float(x), 8)


def load_dfuds_graph(path):
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as f:
        for line in f:
            s = line.strip()
            if not s:
                continue
            return tpl.return_to_graph(s)
    return None


def load_generated_graphs(path):
    graphs = []
    if not os.path.exists(path):
        return graphs

    with open(path, encoding="utf-8") as f:
        for lineno, line in enumerate(f, start=1):
            s = line.strip()
            if not s:
                continue

            if ": " in s:
                head, tail = s.split(": ", 1)
                if head in {"0", "1"}:
                    s = tail.strip()

            try:
                graphs.append(tpl.return_to_graph(s))
            except Exception as e:
                print(f"[warn] failed to parse generated tree at line {lineno}: {e}")
                continue

    return graphs


def compute_generate_oracle_metrics(pattern_path, generated_path):
    P = load_dfuds_graph(pattern_path)
    if P is None:
        return None

    graphs = load_generated_graphs(generated_path)
    if not graphs:
        return None

    saved_pos = 0
    saved_neg = 0

    for G in graphs:
        if tpl.unordered.matching(P, G):
            saved_pos += 1
        else:
            saved_neg += 1

    total_gen = saved_pos + saved_neg
    match_rate = (saved_pos / total_gen) if total_gen > 0 else None

    return {
        "saved_pos": saved_pos,
        "saved_neg": saved_neg,
        "total_gen": total_gen,
        "match_rate": r8(match_rate),
        "match_rate_count": f"{saved_pos}/{total_gen}" if total_gen > 0 else "",
    }


pattern_eval_path = os.path.join(exp_dir, "pattern_eval.json")
if os.path.exists(pattern_eval_path):
    eva = json.load(open(pattern_eval_path, encoding="utf-8"))
else:
    eva = {"status": "skipped", "reason": "refine was skipped for debug generation"}

match_rates = {}
empirical_sweep = {}
cluster_sweep = {}

eval_path = os.path.join(exp_dir, "eval_report.txt")
if os.path.exists(eval_path):
    txt = open(eval_path, encoding="utf-8").read()

    m = re.search(r"Match rate from encoded z:\s*([0-9.]+)", txt, re.IGNORECASE)
    if m:
        match_rates["encoded_z"] = r8(m.group(1))

    m = re.search(r"μ-profile scaled match rate:\s*([0-9.]+)", txt, re.IGNORECASE)
    if m:
        match_rates["mu_profile"] = r8(m.group(1))

    emp_pat = re.compile(
        r"\[sweep\]\s*bank_size=(None|\d+),.*?select_mode=([A-Za-z0-9_]+),\s*sigma_scale=([0-9.]+).*?"
        r"Empirical-latent match rate:\s*([0-9.]+).*?"
        r"Empirical-latent unique graphs:\s*([0-9]+)",
        re.S,
    )
    for m in emp_pat.finditer(txt):
        bank_raw, mode, sigma, mr, uniq = m.groups()
        key = "full" if bank_raw == "None" else f"bank{bank_raw}"
        empirical_sweep[key] = {
            "bank_size": None if bank_raw == "None" else int(bank_raw),
            "select_mode": mode,
            "sigma_scale": r8(sigma),
            "match_rate": r8(mr),
            "unique_graphs": int(uniq),
        }

    # 単発 empirical eval 形式にも対応
    selected_bank_for_direct = cfg["vae_gan"].get("empirical_bank_size", None)
    selected_key_for_direct = "full" if selected_bank_for_direct is None else f"bank{selected_bank_for_direct}"

    if selected_key_for_direct not in empirical_sweep:
        emp_direct_pat = re.search(
            r"Evaluating empirical-latent generation \(sigma_scale=([0-9.]+)\)\.\.\..*?"
            r"\[empirical-latent eval\]\s*total_means=([0-9]+),\s*bank_size=([0-9]+),\s*select_mode=([A-Za-z0-9_]+).*?"
            r"Empirical-latent match rate:\s*([0-9.]+).*?"
            r"Empirical-latent unique graphs:\s*([0-9]+)",
            txt,
            re.S,
        )
        if emp_direct_pat:
            sigma, total_means, actual_bank_size, mode, mr, uniq = emp_direct_pat.groups()
            empirical_sweep[selected_key_for_direct] = {
                "bank_size": selected_bank_for_direct,
                "actual_bank_size": int(actual_bank_size),
                "total_means": int(total_means),
                "select_mode": mode,
                "sigma_scale": r8(sigma),
                "match_rate": r8(mr),
                "unique_graphs": int(uniq),
            }

    cluster_pat = re.compile(
        r"\[sweep\]\s*num_clusters=([0-9]+),\s*effective_num_clusters=([0-9]+),\s*reps_per_cluster=([0-9]+),\s*"
        r"samples_per_cluster=([0-9]+),\s*actual_total=([0-9]+).*?"
        r"Cluster-center generation match rate:\s*([0-9.]+).*?"
        r"Cluster-center generation unique graphs:\s*([0-9]+)",
        re.S,
    )
    for m in cluster_pat.finditer(txt):
        num_clusters, effective_num_clusters, reps_per_cluster, samples_per_cluster, actual_total, mr, uniq = m.groups()
        key = f"c{num_clusters}_r{reps_per_cluster}"
        cluster_sweep[key] = {
            "num_clusters": int(num_clusters),
            "effective_num_clusters": int(effective_num_clusters),
            "reps_per_cluster": int(reps_per_cluster),
            "samples_per_cluster": int(samples_per_cluster),
            "actual_total": int(actual_total),
            "match_rate": r8(mr),
            "unique_graphs": int(uniq),
        }

    selected_bank = cfg["vae_gan"].get("empirical_bank_size", None)
    selected_key = "full" if selected_bank is None else f"bank{selected_bank}"
    if selected_key in empirical_sweep:
        match_rates["empirical_latent"] = empirical_sweep[selected_key]["match_rate"]
        match_rates["empirical_latent_unique"] = empirical_sweep[selected_key]["unique_graphs"]
    elif empirical_sweep:
        first_key = next(iter(empirical_sweep))
        match_rates["empirical_latent"] = empirical_sweep[first_key]["match_rate"]
        match_rates["empirical_latent_unique"] = empirical_sweep[first_key]["unique_graphs"]

    if cluster_sweep:
        best_key = max(cluster_sweep, key=lambda k: cluster_sweep[k]["match_rate"])
        match_rates["cluster_center_best"] = cluster_sweep[best_key]["match_rate"]
        match_rates["cluster_center_best_key"] = best_key

refine_log = os.path.join(exp_dir, "refine_log.txt")
if os.path.exists(refine_log):
    rtxt = open(refine_log, encoding="utf-8").read()
    mp = re.search(r"Pprime vs original match rate.*?([0-9.]+).*?\(([0-9]+/[0-9]+)\)", rtxt)
    if mp:
        match_rates["Pprime_vs_original"] = r8(mp.group(1))
        match_rates["Pprime_vs_original_count"] = mp.group(2)

generate_eval = {
    "strategy": "$GEN_STRATEGY",
}

gen_log = os.path.join(exp_dir, "generate_log.txt")
if os.path.exists(gen_log):
    gtxt = open(gen_log, encoding="utf-8").read()

    m = re.search(r"非同型グラフ数:\s*([0-9]+)/([0-9]+)\s*試行", gtxt)
    if m:
        generate_eval["unique_graphs"] = int(m.group(1))
        generate_eval["max_trials"] = int(m.group(2))

    m = re.search(
        r"(?:cluster-center debug)?生成完了:\s*正例=([0-9]+)\s*件,\s*負例=([0-9]+)\s*件,\s*総生成=([0-9]+)\s*件",
        gtxt
    )
    if m:
        generate_eval["saved_pos"] = int(m.group(1))
        generate_eval["saved_neg"] = int(m.group(2))
        generate_eval["total_gen"] = int(m.group(3))

    m = re.search(
        r"Generate match rate \(oracle debug\):\s*([0-9.]+)\s*\(([0-9]+/[0-9]+)\)",
        gtxt
    )
    if m:
        generate_eval["match_rate"] = r8(m.group(1))
        generate_eval["match_rate_count"] = m.group(2)

    m = re.search(r"blind生成完了(?:\(cluster-center\))?:\s*総生成=([0-9]+)\s*件", gtxt)
    if m and "total_gen" not in generate_eval:
        generate_eval["total_gen"] = int(m.group(1))

# blind 生成でも generated.txt と pattern_P.txt から oracle 的に後計算する
oracle_gen = compute_generate_oracle_metrics(
    os.path.join(exp_dir, "pattern_P.txt"),
    os.path.join(exp_dir, "generated.txt"),
)
if oracle_gen is not None:
    if "saved_pos" not in generate_eval:
        generate_eval["saved_pos"] = oracle_gen["saved_pos"]
    if "saved_neg" not in generate_eval:
        generate_eval["saved_neg"] = oracle_gen["saved_neg"]
    if "total_gen" not in generate_eval:
        generate_eval["total_gen"] = oracle_gen["total_gen"]
    if "match_rate" not in generate_eval:
        generate_eval["match_rate"] = oracle_gen["match_rate"]
        generate_eval["match_rate_count"] = oracle_gen["match_rate_count"]

summary = {
    "timestamp": "$TIMESTAMP",
    "config": {
        "config_path": "$CONFIG",
        "config_name": "$CONFIG_BASENAME",
        "config_stem": "$CONFIG_STEM",
        "gen_strategy": "$GEN_STRATEGY",
        "seed": int("$SEED"),
        "num_pos": cfg["vae_gan"]["num_pos"],
        "eval_num_samples": cfg["vae_gan"].get("eval_num_samples", 100),
        "edge_labels": cfg["common"]["edge_labels"],
        "pat_nodes": cfg["vae_gan"]["pat_nodes"],
        "add_nodes": cfg["common"]["add_nodes"],
        "max_beta": cfg["vae_gan"]["max_beta"],
        "K": cfg["vae_gan"]["K"],
        "config_seed": cfg["vae_gan"].get("seed", 1234),
        "n_samples": cfg["pipeline"]["n_samples"],
        "encoder_layers": cfg["vae_gan"].get("encoder_layers", 2),
        "total_epochs": cfg["vae_gan"].get("total_epochs", 300),
        "model_path": cfg["vae_gan"].get("model_path", "best_model.pt"),
        "output": cfg["vae_gan"].get("output", "generated"),
        "empirical_bank_size": cfg["vae_gan"].get("empirical_bank_size", None),
        "empirical_bank_select_mode": cfg["vae_gan"].get("empirical_bank_select_mode", "fps"),
        "empirical_sigma_scale": r8(cfg["vae_gan"].get("empirical_sigma_scale", 0.15)),
        "augment_copies": cfg["vae_gan"].get("augment_copies", 0)
    },
    "vae_eval": match_rates,
    "vae_eval_empirical_sweep": empirical_sweep,
    "vae_eval_cluster_sweep": cluster_sweep,
    "generate_eval": generate_eval,
    "pattern_eval": eva
}

with open(os.path.join(exp_dir, "summary.json"), "w", encoding="utf-8") as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)

print("summary.json 保存完了")
print(json.dumps(summary, ensure_ascii=False, indent=2))
PYEOF

echo "========================================"
echo " Pipeline 完了"
echo "実験フォルダ: $EXP_DIR"
ls -lh "$EXP_DIR"
echo "========================================"