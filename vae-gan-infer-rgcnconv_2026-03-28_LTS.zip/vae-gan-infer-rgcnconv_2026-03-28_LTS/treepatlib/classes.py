"""treepatlib のコアデータ構造定義。"""
from typing import List, Optional, Tuple

# 型エイリアス
source = int
target = int
x = float
y = float
area_harf = float


class Node:
    """グラフのノードを表すクラス。

    Attributes
    ----------
    node_id : int
        ノード識別子。
    label : str
        ノードの表示ラベル。
    edge_count : int
        接続辺数。
    upper_floor : list of int
        親方向のノード ID リスト。
    under_floor : list of int
        子方向のノード ID リスト。
    position : tuple of (float, float)
        描画時の (x, y) 座標。
    position_area : tuple of (float, float, float)
        描画領域の (x, y, half_width)。
    """

    def __init__(
        self,
        node_id: int = 0,
        label: str = "",
        edge_count: int = 0,
        upper_floor: Optional[List[int]] = None,
        under_floor: Optional[List[int]] = None,
        position: Tuple[x, y] = (),
        position_area: Tuple[x, y, area_harf] = (),
    ) -> None:
        self.node_id = node_id
        self.label = label
        self.edge_count = edge_count
        self.upper_floor = upper_floor if upper_floor is not None else []
        self.under_floor = under_floor if under_floor is not None else []
        self.position = position
        self.position_area = position_area

    def print_data(self) -> None:
        """ノード情報を標準出力に表示する。"""
        print(
            self.node_id,
            self.label,
            self.edge_count,
            self.upper_floor,
            self.under_floor,
            self.position,
            self.position_area,
        )


class Edge:
    """グラフの辺を表すクラス。

    Attributes
    ----------
    edge_id : int
        辺識別子。
    label : str
        辺の表示ラベル。
    edge : tuple of (int, int)
        (source_node_id, target_node_id)。
    """

    def __init__(
        self,
        edge_id: int = 0,
        label: str = "",
        edge: Tuple[source, target] = (),
    ) -> None:
        self.edge_id = edge_id
        self.label = label
        self.edge = edge

    def print_data(self) -> None:
        """辺情報を標準出力に表示する。"""
        print(self.edge_id, self.label, self.edge)


class Variable:
    """パターン中の変数（超辺）を表すクラス。

    Attributes
    ----------
    node_id : int
        変数ノードの ID。
    style : list of int
        描画スタイル情報。
    """

    def __init__(
        self,
        node_id: int = 0,
        style: Optional[List[int]] = None,
    ) -> None:
        self.node_id = node_id
        self.style = style if style is not None else []

    def print_data(self) -> None:
        """変数情報を標準出力に表示する。"""
        print(self.node_id, self.style)


class Graph:
    """グラフ全体を保持するコンテナクラス。

    Attributes
    ----------
    node : list of Node
        ノードのリスト。
    edge : list of Edge
        辺のリスト。
    variables : list of Variable
        変数（超辺）のリスト。
    drawing_order : list of int
        描画順のノード ID リスト。
    bind_num : int
        バインディング番号。
    """

    def __init__(
        self,
        node: Optional[List[Node]] = None,
        edge: Optional[List[Edge]] = None,
        variables: Optional[List[Variable]] = None,
        drawing_order: Optional[List[int]] = None,
        bind_num: int = 0,
    ) -> None:
        self.node = node if node is not None else []
        self.edge = edge if edge is not None else []
        self.variables = variables if variables is not None else []
        self.drawing_order = drawing_order if drawing_order is not None else []
        self.bind_num = bind_num

    def print_data(self) -> None:
        """グラフ情報を標準出力に表示する。"""
        print(self.node, self.edge, self.variables, self.drawing_order, self.bind_num)


class Binding:
    """パターンバインディングを表すクラス。

    変数ノードに対応する部分木をグラフに関連付ける情報を保持する。

    Attributes
    ----------
    target_label : str
        バインディング対象ノードのラベル。
    node : list of Node
        バインディンググラフのノードリスト。
    edge : list of Edge
        バインディンググラフの辺リスト。
    variables : list of Variable
        バインディンググラフの変数リスト。
    style : list of int
        描画スタイル情報。
    drawing_order : list of int
        描画順のノード ID リスト。
    bind_num : int
        バインディング番号。
    """

    def __init__(
        self,
        target_label: str = "",
        node: Optional[List[Node]] = None,
        edge: Optional[List[Edge]] = None,
        variables: Optional[List[Variable]] = None,
        style: Optional[List[int]] = None,
        drawing_order: Optional[List[int]] = None,
        bind_num: int = 0,
    ) -> None:
        self.target_label = target_label
        self.node = node if node is not None else []
        self.edge = edge if edge is not None else []
        self.variables = variables if variables is not None else []
        self.style = style if style is not None else []
        self.drawing_order = drawing_order if drawing_order is not None else []
        self.bind_num = bind_num

    def print_data(self) -> None:
        """バインディング情報を標準出力に表示する。"""
        print(
            self.target_label,
            self.node,
            self.edge,
            self.variables,
            self.style,
            self.drawing_order,
            self.bind_num,
        )


class Drawing:
    """描画データを保持するクラス。

    Attributes
    ----------
    graph : Graph or None
        描画対象グラフ。
    node_id_list : list of int or None
        描画に使うノード ID の順序リスト。
    node_type : list of bool or None
        各ノードが変数ノードかどうかのフラグリスト。
    """

    def __init__(
        self,
        graph: Optional[Graph] = None,
        node_id_list: Optional[List[int]] = None,
        node_type: Optional[List[bool]] = None,
    ) -> None:
        self.graph = graph
        self.node_id_list = node_id_list
        self.node_type = node_type

    def print_data(self) -> None:
        """描画データ情報を標準出力に表示する。"""
        print(self.graph, self.node_id_list, self.node_type)
