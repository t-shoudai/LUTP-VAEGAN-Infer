from networkx.algorithms.isomorphism import rooted_tree_isomorphism
from networkx.algorithms import bipartite
import networkx as nx
import treepatlib as tpl
import itertools
import random
import copy
from typing import Dict, Generator, List, Optional, Tuple

ROOT = 0
ROOT_NAME = '#'


def depth_sequence(
    G_sub: nx.DiGraph,
    G_pare: Optional[nx.DiGraph] = None,
) -> List[int]:
    """部分木 G_sub の各ノードの深さ列を返す。

    Parameters
    ----------
    G_sub:
        深さを計算する部分木（全体木の部分グラフ）。
    G_pare:
        深さの基準となる親木。None のとき G_sub 自身を使う。

    Returns
    -------
    list of int
        ノードを昇順に並べたときの各ノードの深さ。
    """
    if G_pare is None:
        G_pare = G_sub
    ds = []
    node = list(nx.dfs_tree(G_sub))
    node.sort()
    for v in node:
        ds.append(len(nx.shortest_path(G_pare, source=0, target=v)) - 1)
    return ds


def active(left_ds: List[int], right_ds: List[int]) -> bool:
    """2つの深さ列が先頭から一致するかを判定する（アクティブ判定）。

    Parameters
    ----------
    left_ds:
        左部分木の深さ列。
    right_ds:
        右部分木の深さ列（比較基準の長さ）。

    Returns
    -------
    bool
    """
    for i in range(len(right_ds)):
        if left_ds[i] != right_ds[i]:
            return False
    return True


def right_most_path(G: nx.DiGraph) -> List[int]:
    """無順序木の最右路を返す。

    左右の部分木同型判定に基づき、有効な最右路ノード列を返す。

    Parameters
    ----------
    G:
        対象の無順序木（有向グラフ）。

    Returns
    -------
    list of int
        根から最右葉方向への有効なノード列。
    """
    active_node = -1
    unordered_rmp = []
    rmp = tpl.ordered.right_most_path(G)

    if len(G) - 1 == len(nx.shortest_path(G, source=0, target=len(G) - 1)) - 1:
        unordered_rmp = copy.deepcopy(rmp)
    else:
        depth_sequence_right = []
        depth_sequence_left = []
        for v in rmp:
            if len(G.adj[v]) >= 2:
                right_v = list(G.adj[v])[len(G.adj[v]) - 1]
                right_v_list = [right_v]
                right_v_list.extend(list(nx.dfs_predecessors(G, right_v)))
                subtree_right = nx.subgraph(G, right_v_list)
                depth_sequence_right = depth_sequence(subtree_right, G)

                left_sibling_right_v = tpl.ordered.left_sibling(G, right_v)
                left_v_list = [left_sibling_right_v]
                left_v_list.extend(list(nx.dfs_predecessors(G, left_sibling_right_v)))
                subtree_left = nx.subgraph(G, left_v_list)
                depth_sequence_left = depth_sequence(subtree_left, G)

                if active(depth_sequence_left, depth_sequence_right):
                    if active_node == -1:
                        active_node = v
                        break
        if depth_sequence_right == depth_sequence_left:
            unordered_rmp = copy.deepcopy(rmp[0: rmp.index(active_node) + 1])
        else:
            unordered_rmp = copy.deepcopy(
                rmp[0: depth_sequence_left[(len(depth_sequence_right))]]
            )
    return unordered_rmp


def u_enumerate(
    G: Optional[nx.DiGraph] = None,
    num_edge: Optional[int] = None,
    num_graph: int = 0,
) -> List[nx.DiGraph]:
    """無順序木を列挙する。

    G を指定しない場合は根のみの木から辺を num_edge 本追加した全木を返す。
    G を指定した場合は G を起点に num_graph 個の木を返す。

    Parameters
    ----------
    G:
        起点グラフ。None のとき根のみの木から開始する。
    num_edge:
        G=None のとき追加する辺数の上限。None のとき対話入力を使う。
    num_graph:
        G を指定したとき生成するグラフ数。0 のとき対話入力を使う。

    Returns
    -------
    list of nx.DiGraph
    """
    if G is None:
        G = nx.DiGraph()
        G.add_node(0, name=ROOT_NAME)
        G = nx.convert_node_labels_to_integers(G)
        if num_edge is None:
            num_edge = int(input("number of edges:"))
        if num_edge == 0:
            return []
        pattern = [G]
        num = 0
        for j in range(num_edge):
            search = len(pattern)
            for i in range(num, search):
                unordered_rmp = right_most_path(pattern[i])
                for v in unordered_rmp:
                    G_new = copy.deepcopy(pattern[i])
                    length = len(pattern[i])
                    G_new.add_node(length)
                    G_new.add_edge(v, length)
                    pattern.append(G_new)
            num = search
        return pattern
    else:
        G = nx.convert_node_labels_to_integers(G)
        if num_graph == 0:
            num_graph = int(input("number of graph:"))
        if num_graph == 0:
            return []
        pattern = [G]
        tree_make = copy.deepcopy(pattern)
        while len(tree_make) < num_graph:
            unordered_rmp = right_most_path(pattern[0])
            for v in unordered_rmp:
                G_new = copy.deepcopy(pattern[0])
                length = len(pattern[0])
                G_new.add_node(length)
                G_new.add_edge(v, length)
                pattern.append(G_new)
                tree_make.append(G_new)
                if len(tree_make) >= num_graph:
                    break
            pattern.pop(0)
        return tree_make


def randomtree(
    num_graph: int,
    string_list: List[str],
    G: Optional[nx.DiGraph] = None,
) -> List[nx.DiGraph]:
    """ランダムにラベル付けされた無順序木を num_graph 個生成する。

    各辺の子頂点の name 属性にラベルが格納された木を返す。

    Parameters
    ----------
    num_graph:
        生成する木の数。
    string_list:
        子頂点ラベルに使う文字の候補リスト。
    G:
        起点グラフ。None のとき根のみの木から開始する。

    Returns
    -------
    list of nx.DiGraph
    """
    if G is None:
        G = nx.DiGraph()
        G.add_node(0, name=ROOT_NAME)
    G = nx.convert_node_labels_to_integers(G)

    tree_label = [G]
    # 同型チェック用: DFUDS 文字列の長さ → 文字列集合
    # 長さが異なれば構造が異なるので、同じ長さの集合だけと比較すればよい
    init_dfuds = tpl.draw.dfuds(left_depth_priferred_tree(G))
    dfuds_map: Dict[int, set] = {len(init_dfuds): {init_dfuds}}
    node_set: set = {len(G.nodes)}  # 一次フィルタ用: 既出ノード数集合
    pattern = [G]

    while len(tree_label) < num_graph:
        unordered_rmp = right_most_path(pattern[0])
        for v in unordered_rmp:
            G_new = copy.deepcopy(pattern[0])
            length = len(pattern[0])
            G_new.add_node(length)
            G_new.add_edge(v, length)
            pattern.append(G_new)

            labels = tpl.ordered.relabel(G_new, string_list)
            for labeled_tree in labels:
                n = len(labeled_tree.nodes)
                canonical = left_depth_priferred_tree(labeled_tree)
                dfuds_str = tpl.draw.dfuds(canonical)
                key = len(dfuds_str)
                if n not in node_set:
                    # 一次フィルタ: ノード数が新規 → 確実に非同型
                    node_set.add(n)
                    dfuds_map.setdefault(key, set()).add(dfuds_str)
                    tree_label.append(canonical)
                elif key not in dfuds_map or dfuds_str not in dfuds_map[key]:
                    # 二次フィルタ: 同ノード数あり → DFUDS で確認
                    dfuds_map.setdefault(key, set()).add(dfuds_str)
                    tree_label.append(canonical)
                if len(tree_label) >= num_graph:
                    break
            if len(tree_label) >= num_graph:
                break
        pattern.pop(0)
    return tree_label


def change(G: nx.DiGraph) -> nx.DiGraph:
    """順序木を無順序木に変換する（子の順序をランダムに並び替え）。

    Parameters
    ----------
    G:
        順序木として扱う有向グラフ。

    Returns
    -------
    nx.DiGraph
        子の順序をシャッフルした無順序木。
    """
    G_change = copy.deepcopy(G)
    for v in G.nodes():
        G_sub_list = []
        if len(G.adj[v]) > 1:
            G_v_adj = list(G.adj[v])
            for v_adj in G_v_adj:
                v_list = [v_adj]
                v_list.extend(list(nx.dfs_predecessors(G, v_adj)))
                G_change.remove_nodes_from(v_list)
                v_list.append(v)
                G_sub_list.append(nx.subgraph(G, v_list))
            random.shuffle(G_sub_list)
            for G_sub in G_sub_list:
                G_change = nx.compose(G_change, G_sub)
    return G_change


def node_divide(
    G: nx.DiGraph,
) -> Tuple[List[Tuple[int, str]], List[Tuple[int, str]]]:
    """ノードを葉と非葉に分類して返す。

    Parameters
    ----------
    G:
        対象グラフ。

    Returns
    -------
    tuple of (list, list)
        (葉ノードリスト, 非葉ノードリスト)。各要素は (node_id, label)。
    """
    leaves = []
    not_leaves = []
    for v in G.nodes():
        label = str(G.nodes[v]['name'])
        information = (v, label)
        if len(G.adj[v]) == 0:
            leaves.append(information)
        else:
            not_leaves.append(information)
    return leaves, not_leaves


def make_rule(
    G: nx.DiGraph,
    variable_name: str,
) -> Tuple[List[Tuple[int, str]], List[Optional[List[Tuple[int, str]]]]]:
    """パターングラフからマッチングルール（頭部・本体）を生成する。

    Parameters
    ----------
    G:
        パターングラフ。
    variable_name:
        変数として扱うノードのラベル名。

    Returns
    -------
    tuple of (heads, bodies)
        heads: 各ルールの頭部ノード。
        bodies: 各ルールの本体ノードリスト。
    """
    leaves, heads = node_divide(G)
    bodies: List[Optional[List[Tuple[int, str]]]] = [None for _ in heads]
    for enu, head in enumerate(heads):
        for v in G.adj[head[0]]:
            label = str(G.nodes[v]['name'])
            if bodies[enu] is None:
                bodies[enu] = [(v, label)]
            else:
                bodies[enu].append((v, label))
    for v in G.nodes():
        if str(G.nodes[v]['name']) == variable_name:
            information = (v, variable_name)
            heads.append(information)
            bodies.append([information])
    return heads, bodies


def matching(
    pattern: nx.DiGraph,
    G: nx.DiGraph,
    variable: bool = True,
) -> bool:
    """パターン pattern が木 G にマッチするかを判定する。

    二部マッチング（Hopcroft-Karp）を用いた無順序木パターンマッチング。

    Parameters
    ----------
    pattern:
        マッチングに使うパターン木。変数ノードは name='X' で表す。
    G:
        マッチング対象の木。
    variable:
        True のとき 'X' を変数として扱う。False のとき変数なし。

    Returns
    -------
    bool
        マッチすれば True。
    """
    variable_name = 'X' if variable else 'XX'

    if len(pattern) > len(G):
        return False

    cs: Dict[Tuple[int, str], Optional[List[Tuple[int, str]]]] = {}
    leaves_P, not_leaves_P = node_divide(pattern)
    leaves_G, not_leaves_G = node_divide(G)
    heads, bodies = make_rule(pattern, variable_name)

    for v in G.nodes():
        information: Tuple[int, str]
        if v == ROOT:
            information = (ROOT, ROOT_NAME)
        else:
            information = (v, str(G.nodes[v]['name']))
        cs[information] = None

    # 対応集合に葉の情報を追加
    for leaf_G in leaves_G:
        label_G = str(G.nodes[leaf_G[0]]['name'])
        for leaf_P in leaves_P:
            label_P = str(pattern.nodes[leaf_P[0]]['name'])
            if label_G == label_P or str(label_P) == variable_name:
                if cs[leaf_G] is None:
                    cs[leaf_G] = [leaf_P]
                else:
                    cs[leaf_G].append(leaf_P)

    depth_list = depth_sequence(G)
    depth_max = max(depth_list)

    for depth_search in range(depth_max, -1, -1):
        for cs_key in cs:
            if cs[cs_key] is not None:
                cs[cs_key] = [
                    cs_value for cs_value in cs[cs_key]
                    if cs_key[1] == cs_value[1] or str(cs_value[1]) == variable_name
                ]
        searches = []
        for v in G.nodes():
            depth = len(nx.shortest_path(G, source=0, target=v)) - 1
            if depth == depth_search and len(G.adj[v]) > 0:
                searches.append(v)

        for search in searches:
            for head, body in zip(heads, bodies):
                M = nx.Graph()
                top_nodes = []
                for child in G.adj[search]:
                    information = (child, str(G.nodes[child]['name']))
                    top_nodes.append(information)
                bottom_nodes = [(x[1], len(G) + x[0]) for x in body]
                M.add_nodes_from(top_nodes, bipartite=0)
                M.add_nodes_from(bottom_nodes, bipartite=1)
                for bottom in bottom_nodes:
                    for top in top_nodes:
                        if cs[top] is not None:
                            for cs_top in cs[top]:
                                if (
                                    bottom[1] - len(G) == cs_top[0]
                                    and bottom[0] == cs_top[1]
                                ):
                                    M.add_edge(top, bottom)
                match_result = bipartite.matching.hopcroft_karp_matching(M, top_nodes)

                body_label = [x[1] for x in body]
                if search == 0:
                    information = (ROOT, ROOT_NAME)
                else:
                    information = (search, str(G.nodes[search]['name']))

                if variable_name in body_label:
                    if len(match_result) // 2 == len(bottom_nodes):
                        if cs[information] is None:
                            cs[information] = [head]
                        else:
                            cs[information].append(head)
                else:
                    if (
                        len(match_result) // 2 == len(top_nodes)
                        and len(top_nodes) == len(bottom_nodes)
                    ):
                        if cs[information] is None:
                            cs[information] = [head]
                        else:
                            cs[information].append(head)

    if cs[(ROOT, ROOT_NAME)] is None:
        return False
    elif (ROOT, ROOT_NAME) in cs[(ROOT, ROOT_NAME)]:
        return True
    else:
        return False


def split_list(l: list, n: int) -> Generator:
    """リストを n 要素ずつに分割するジェネレータ。

    Parameters
    ----------
    l:
        分割対象リスト。
    n:
        チャンクサイズ。
    """
    for idx in range(0, len(l), n):
        yield l[idx:idx + n]


def binding(
    pattern: nx.DiGraph,
    variable_edge: tuple,
    tree: nx.DiGraph,
    leaf: int,
) -> nx.DiGraph:
    """パターンの変数辺に木を束縛（超辺置換）して返す。

    変数辺 (p, x) に対して以下の同一視を行う：
      - p （変数辺の親端点） と tree の根 を同一視
      - x （変数辺の子端点） と tree の指定葉 leaf を同一視

    x が内部ノードの場合、x の子サブツリーは leaf の子として接続される。
    現在のパターンクラスでは x は常に葉なので leaf の選択は結果に影響しない。

    Parameters
    ----------
    pattern:
        変数辺を含むパターン木。
    variable_edge:
        束縛する変数辺 (p, x)。x は name='X' のノードであること。
    tree:
        変数辺に代入する根付き木。
    leaf:
        tree の中で x と同一視する葉ノードの ID。

    Returns
    -------
    nx.DiGraph
        束縛後の木（ノードラベルは整数に正規化済み）。
    """
    p, x = variable_edge
    P = copy.deepcopy(pattern)
    T = copy.deepcopy(tree)

    # x の子サブツリーを退避（x が内部ノードの場合に必要）
    x_children = list(P.successors(x))

    # x をパターンから除去
    P.remove_node(x)

    # T のノードIDをずらして P に統合（p と leaf の対応を考慮）
    P_v_max = max(list(P.nodes()))
    # T のノード ID マッピング:
    #   根 (0) → p （親端点と同一視）
    #   leaf → x_id として後で x_children を接続するための一時ID
    #   その他 → v + P_v_max
    # ただし x 自体はすでに除去済みなので、leaf に x_children を接続するため
    # leaf を P_v_max + leaf として追加し、最後に x_children を付け替える

    t_map = {}
    for v in T.nodes():
        if v == 0:
            t_map[v] = p  # 根 → p と同一視
        else:
            t_map[v] = v + P_v_max

    # T のノード・辺を P に追加（根 p は既存なので name は上書きしない）
    for v in T.nodes():
        mapped = t_map[v]
        if mapped != p:
            label = str(T.nodes[v]['name'])
            P.add_node(mapped, name=label)
    for u_node, v_node in T.edges():
        P.add_edge(t_map[u_node], t_map[v_node])

    # x の子サブツリーを leaf の対応先に接続（x が内部ノードの場合）
    leaf_mapped = t_map[leaf]
    for child in x_children:
        P.add_edge(leaf_mapped, child)

    return nx.convert_node_labels_to_integers(P)


def substitute(
    pattern: nx.DiGraph,
    trees: List[nx.DiGraph],
    leaves: Optional[List[int]] = None,
) -> nx.DiGraph:
    """パターンのすべての変数辺に木を代入して返す。

    各変数辺に対して binding を順に呼び出す。
    leaves を省略した場合は各 tree の最初の葉を自動的に使用する
    （現在のパターンクラスでは変数は常に葉なので結果は同じ）。

    Parameters
    ----------
    pattern:
        変数 'X' を含むパターン木。
    trees:
        各変数辺に代入する木のリスト。変数辺の数と同じ長さ。
    leaves:
        各 tree の中で子端点と同一視する葉ノードのリスト。
        None のとき各 tree の最初の葉を自動選択。

    Returns
    -------
    nx.DiGraph
        代入後の木。
    """
    variable_name = 'X'
    P = copy.deepcopy(pattern)

    for i, tree in enumerate(trees):
        # 現時点の P から変数辺を1つ取得
        var_edge = next(
            (p, x) for p, x in P.edges()
            if str(P.nodes[x].get('name', '')) == variable_name
        )
        # leaf の決定
        if leaves is not None:
            leaf = leaves[i]
        else:
            leaf = next(
                v for v in tree.nodes()
                if tree.out_degree(v) == 0
            )
        P = binding(P, var_edge, tree, leaf)

    return P


def make_positive(
    num_pos: int,
    graph_list: List[nx.DiGraph],
    pattern: nx.DiGraph,
) -> List[nx.DiGraph]:
    """パターンにマッチする正例木を num_pos 個生成する。

    パターン内の変数 'X' に graph_list の木を代入して正例を構成する。

    Parameters
    ----------
    num_pos:
        生成する正例数の上限。
    graph_list:
        変数に代入する木のリスト。
    pattern:
        変数 'X' を含むパターン木。

    Returns
    -------
    list of nx.DiGraph
        正例木のリスト（num_pos 以下）。
    """
    variable_name = 'X'
    P = copy.deepcopy(pattern)
    positive = []
    P_variable_before = []
    P_variable_after = []
    dfuds_map: Dict[int, set] = {}  # 同型チェック用: DFUDS 長さ → 文字列集合
    node_set: set = set()  # 一次フィルタ用: 既出ノード数集合

    for edge in P.edges():
        P_label = str(P.nodes[edge[1]]['name'])
        if str(P_label) == variable_name:
            P_variable_before.append(edge[0])
            P_variable_after.append(edge[1])
    P.remove_nodes_from(P_variable_after)

    if len(P_variable_before) >= 2:
        graph_split_list = list(split_list(graph_list, len(P_variable_before) * 2))
    else:
        graph_split_list = list(split_list(graph_list, len(P_variable_before)))

    for i in range(len(graph_split_list)):
        for G_list in itertools.product(
            graph_split_list[i], repeat=len(P_variable_before)
        ):
            P_pos = substitute(pattern, list(G_list))

            P_pos = left_depth_priferred_tree(P_pos)
            if len(P_pos.nodes) < len(pattern.nodes):
                continue  # パターンより頂点数が少ない木は除外
            dfuds_str = tpl.draw.dfuds(P_pos)
            key = len(dfuds_str)
            if key not in dfuds_map or dfuds_str not in dfuds_map[key]:
                dfuds_map.setdefault(key, set()).add(dfuds_str)
                positive.append(P_pos)
            if len(positive) % 100 == 0:
                print(f'make positive: {len(positive):04d} / {num_pos}')
            if len(positive) >= num_pos:
                return positive

    print(f'final positive number: {len(positive):04d}')
    return positive


def make_negative(
    num_neg: int,
    string_list: List[str],
    pattern: nx.DiGraph,
    G: Optional[nx.DiGraph] = None,
) -> List[nx.DiGraph]:
    """パターンにマッチしない負例木を num_neg 個生成する。

    Parameters
    ----------
    num_neg:
        生成する負例数。
    string_list:
        ノードラベルに使う文字の候補リスト。
    pattern:
        マッチング判定に使うパターン木。
    G:
        起点グラフ。None のとき根のみの木から開始する。

    Returns
    -------
    list of nx.DiGraph
    """
    if G is None:
        G = nx.DiGraph()
        G.add_node(0, name=ROOT_NAME)
    G = nx.convert_node_labels_to_integers(G)

    tree = [G]
    negative = []
    dfuds_map: Dict[int, set] = {}  # 同型チェック用: DFUDS 長さ → 文字列集合
    node_set: set = set()  # 一次フィルタ用: 既出ノード数集合

    while len(negative) < num_neg:
        unordered_rmp = right_most_path(tree[0])
        for v in unordered_rmp:
            G_new = copy.deepcopy(tree[0])
            length = len(tree[0])
            G_new.add_node(length)
            G_new.add_edge(v, length)
            tree.append(G_new)
            labels = tpl.ordered.relabel(G_new, string_list)

            for New_1 in labels:
                cont = 0
                for enu, New_2 in enumerate(labels):
                    result = matching(New_1, New_2)
                    if result is True and cont != 0:
                        labels.pop(enu)
                    elif result is True and cont == 0:
                        cont += 1

            for match_judge in labels:
                if len(match_judge.nodes) < len(pattern.nodes):
                    continue  # パターンより頂点数が少ない木は除外
                result = matching(pattern, match_judge)
                if result is False:
                    # 無順序木は子の並び順が違っても同型なので標準形に変換してチェック
                    # 一次フィルタ: ノード数が既出にない → 確実に新規（変換不要）
                    n = len(match_judge.nodes)
                    if n not in node_set:
                        node_set.add(n)
                        canonical = left_depth_priferred_tree(match_judge)
                        dfuds_str = tpl.draw.dfuds(canonical)
                        dfuds_map.setdefault(len(dfuds_str), set()).add(dfuds_str)
                        negative.append(canonical)
                    else:
                        # 二次フィルタ: 同じノード数がある場合のみ標準形変換して確定
                        canonical = left_depth_priferred_tree(match_judge)
                        dfuds_str = tpl.draw.dfuds(canonical)
                        key = len(dfuds_str)
                        if key not in dfuds_map or dfuds_str not in dfuds_map[key]:
                            dfuds_map.setdefault(key, set()).add(dfuds_str)
                            negative.append(canonical)
                    if len(negative) % 100 == 0:
                        print(f'make negative: {len(negative):04d} / {num_neg}')
                    if len(negative) >= num_neg:
                        return negative
        tree.pop(0)
    return negative


def is_leaf(G: nx.DiGraph, v: int) -> bool:
    """ノード v が葉かどうかを返す。

    Parameters
    ----------
    G:
        対象グラフ。
    v:
        確認するノード ID。

    Returns
    -------
    bool
    """
    return G.out_degree(v) == 0


def left_depth_priferred_tree(beginning_tree: nx.DiGraph) -> nx.DiGraph:
    """深さ優先左優先標準形（canonical form）に変換する。

    子のいるノードについて部分木を深さ列の降順・ラベル昇順で並び替える。

    Parameters
    ----------
    beginning_tree:
        正規化対象の木。

    Returns
    -------
    nx.DiGraph
        標準形に変換された木。
    """
    T = copy.deepcopy(beginning_tree)
    nodes = reversed(list(nx.bfs_tree(T, source=ROOT).nodes))
    for v in nodes:
        num_child = len(T.adj[v])
        if num_child > 1:
            sub_tree_list = []
            ds_list = []
            delete_node_list = []
            for i, root in enumerate(list(T.adj[v])):
                vertices = [root]
                delete_node = list(nx.dfs_predecessors(T, root))
                vertices.extend(delete_node)
                sub_tree = nx.dfs_tree(nx.subgraph(T, vertices), source=root)
                s = ''
                for u in sub_tree.nodes:
                    s += beginning_tree.nodes[u]['name']
                sub_tree_list.append(sub_tree)
                ds = depth_sequence(sub_tree, G_pare=T)
                ds_list.append([ds, s, i])
                delete_node_list.extend(vertices)

            ds_sort = sorted(ds_list, key=lambda x: x[1])
            ds_sort = sorted(ds_sort, key=lambda x: x[0], reverse=True)

            temp_tree = copy.deepcopy(T)
            temp_tree.remove_nodes_from(delete_node_list)

            for _, __, index in ds_sort:
                G = sub_tree_list[index]
                temp_tree = nx.compose(temp_tree, G)
                min_vertex = min(G.nodes)
                temp_tree.add_edge(v, min_vertex)
            T = copy.deepcopy(temp_tree)

    T = nx.dfs_tree(T, source=ROOT)
    T_nodes = T.nodes
    for v in T_nodes:
        name = beginning_tree.nodes[v]['name']
        T.add_node(v, name=name)
    T_edges = T.edges
    for e1, e2 in T_edges:
        T.add_node(e1, name=beginning_tree.nodes[e1]['name'])
        T.add_node(e2, name=beginning_tree.nodes[e2]['name'])
        T.add_edge(e1, e2)
    return tpl.draw.clear(T)


def right_depth_preferred_tree(beginning_tree: nx.DiGraph) -> nx.DiGraph:
    """深さ優先右優先標準形（canonical form）に変換する。

    left_depth_priferred_tree の逆順版。

    Parameters
    ----------
    beginning_tree:
        正規化対象の木。

    Returns
    -------
    nx.DiGraph
        標準形に変換された木。
    """
    T = copy.deepcopy(beginning_tree)
    nodes = reversed(list(nx.bfs_tree(T, source=ROOT).nodes))
    for v in nodes:
        num_child = len(T.adj[v])
        if num_child > 1:
            sub_tree_list = []
            ds_list = []
            delete_node_list = []
            for i, root in enumerate(list(T.adj[v])):
                vertices = [root]
                delete_node = list(nx.dfs_predecessors(T, root))
                vertices.extend(delete_node)
                sub_tree = nx.dfs_tree(nx.subgraph(T, vertices), source=root)
                s = ''
                for u in sub_tree.nodes:
                    s += beginning_tree.nodes[u]['name']
                sub_tree_list.append(sub_tree)
                ds = depth_sequence(sub_tree, G_pare=T)
                ds_list.append([ds, s, i])
                delete_node_list.extend(vertices)

            ds_sort = sorted(ds_list, key=lambda x: x[1])
            ds_sort = sorted(ds_sort, key=lambda x: x[0])

            temp_tree = copy.deepcopy(T)
            temp_tree.remove_nodes_from(delete_node_list)

            for _, __, index in ds_sort:
                G = sub_tree_list[index]
                temp_tree = nx.compose(temp_tree, G)
                min_vertex = min(G.nodes)
                temp_tree.add_edge(v, min_vertex)
            T = copy.deepcopy(temp_tree)

    T = nx.dfs_tree(T, source=ROOT)
    T_nodes = T.nodes
    for v in T_nodes:
        name = beginning_tree.nodes[v]['name']
        T.add_node(v, name=name)
    T_edges = T.edges
    for e1, e2 in T_edges:
        T.add_node(e1, name=beginning_tree.nodes[e1]['name'])
        T.add_node(e2, name=beginning_tree.nodes[e2]['name'])
        T.add_edge(e1, e2)
    return tpl.draw.clear(T)
