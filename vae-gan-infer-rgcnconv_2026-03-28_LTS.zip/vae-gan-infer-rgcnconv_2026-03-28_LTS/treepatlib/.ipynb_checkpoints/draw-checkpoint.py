import matplotlib.pyplot as plt
import treepatlib.classes as myclass
import treepatlib as tpl
import networkx as nx

def drawing(drawing_data, node_label = True, edge_label = True):
    graph        = drawing_data.graph
    node_id_list = drawing_data.node_id_list
    node_type    = drawing_data.node_type

    plt.figure(figsize=(6, 4), dpi=80)
    #図形要素の変更get current figureの略?
    ax = plt.gca()
    #メモリ非表示
    ax.axes.xaxis.set_visible(False)
    ax.axes.yaxis.set_visible(False)
    #枠の非表示
    ax.spines['top'].set_visible(False)
    ax.spines['left'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['bottom'].set_visible(False) 
    
    node = graph.node
    edge = graph.edge
 
    for i, draw_node in enumerate(node):
        if node_type[i] == False:
            plt.scatter(draw_node.position[0],draw_node.position[1], s=100 , c='white', marker='o', linewidths=1, edgecolors='#777777', zorder=2)
        else:
            plt.scatter(draw_node.position[0],draw_node.position[1], s=100 , c='#ffff66', marker='s', linewidths=1, edgecolors='#777777', zorder=2)
        
        if node_label:
            plt.text(draw_node.position[0], draw_node.position[1], draw_node.label)
        else:
            plt.text(draw_node.position[0], draw_node.position[1], draw_node.node_id)
        
        # 木がPathであれば線幅がautoscaleして画面幅と同一になる。それを回避するため、見えない点を描く。(by T.Shoudai)
        if draw_node.position[0] == 5.0 and draw_node.position[1] == 0:
            plt.scatter([0,10],[0,0],s=0,c='white',edgecolor='white')
 
    for draw_edge in edge:
        souce_node1 = draw_edge.edge[0]
        souce_node2 = draw_edge.edge[1]
        
        source = node_id_list.index(souce_node1)
        target = node_id_list.index(souce_node2)
        
        sx = node[source].position[0]
        sy = node[source].position[1]
        tx = node[target].position[0] - sx
        ty = node[target].position[1] - sy

        plt.arrow(sx, sy, tx, ty, head_width=0, head_length=0, width = 0.001, color='#777777')
        
        x_t = sx + (tx/2)
        y_t = sy + (ty/2)
        
        if edge_label:
            plt.text(x_t,y_t,draw_edge.label)
        else:
            plt.text(x_t,y_t,draw_edge.edge_id)
            
def coloring_node(nodes, node_id_list, node_ids, colors, label = True):
    
    ax = plt.gca()
    #メモリ非表示
    ax.axes.xaxis.set_visible(False)
    ax.axes.yaxis.set_visible(False)
    #枠の非表示
    ax.spines['top'].set_visible(False)
    ax.spines['left'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['bottom'].set_visible(False) 
    
    
    for node_id, color in zip(node_ids, colors):
        node_id_index = node_id_list.index(node_id)
        node = nodes[node_id_index]
        
        plt.scatter(node.position[0], node.position[1], s=100 , c=color, marker='o', linewidths=1, edgecolors='#777777', zorder=2)
        
        if label:
            plt.text(node.position[0], node.position[1], node.label)
        else:
            plt.text(node.position[0], node.position[1], node.node_id)

# 木のDFUDS形式表現
def dfuds(G):
    G_dfs = nx.dfs_tree(G, source=0)
    node_list = list(G_dfs.nodes)
    dfuds = '0'
    before = ',0'
    edge_label = ''
    for v in node_list:
        v_adj = len(G.adj[v])
        edge_label = G.nodes[v]['name']
        dfuds = dfuds + before * v_adj + "," + edge_label
    return dfuds

# 木の描画
def tree_draw(T, file_name = None, show=True):
    G = tree_from_networkx(T)
    DG = tpl.tree_graph_creation_module.drawing_graph_data_creation(G)
    drawing(DG)
    if file_name != None:
        plt.savefig(file_name + '.png')
    if show == True:
        plt.show()
    plt.close()

def tree_from_networkx(T):
    G = myclass.Graph()
    G.node = []
    G.edge = []
    for v in T.nodes:
        #node = myclass.Node(v,T.nodes[v]['label'])
        node = myclass.Node(v,v)
        G.node.append(node)
    for e in T.edges:
        #edge = myclass.Edge(T.edges[e]['id'],T.nodes[e[1]]['name'],e)
        if T.nodes(data='name')[v] == None:
            edge = myclass.Edge(list(T.edges(e))[0][1],str(e[1]-1),e)
        else:
            edge = myclass.Edge(list(T.edges(e))[0][1],T.nodes[e[1]]['name'],e)
        G.edge.append(edge)    
    return G

def tree_save(G, class_, file_name):
    f = open(file_name + '.txt', 'a', encoding='UTF-8')
    save  = str(class_) + ': '
    save += tpl.draw.dfuds(G)
    f.write(save)
    f.write('\n')
    f.close()

def return_to_graph(dfuds):
    v = 0
    count = 0
    dict_name = {}
    dict_child = {}
    
    for df in dfuds:
        if (df != '0') and (df != ','):
            dict_name[count] = df
            count += 1
    count = 0
    for enu, d in enumerate(dfuds):
        if enu != 0:
            if d == '0':
                count += 1
            elif d == ',':
                pass
            else:
                dict_child[v] = count
                count = 0
                v += 1
    G = nx.DiGraph()
    for enu, i in enumerate(dict_name):
        G.add_node(enu)
    count = 0
    for i in dict_name:
        for j in range(dict_child[i]):
            if i == 0:
                G.add_edge(i, count+1)
                count += 1
            else:
                G.add_edge(list(nx.dfs_preorder_nodes(G, source=0))[i], count+1)
                count += 1
    G = nx.dfs_tree(G, source=0)
    for enu, v in enumerate(G.nodes()):
        G.add_node(v, name=dict_name[enu])
    return clear(G)

def clear(G):
    G = nx.convert_node_labels_to_integers(G)
    dict_name = {}
    dict_node = {}
    for i, v in enumerate(list(nx.dfs_tree(G, source=0))):
        dict_name[i] = G.nodes[v]['name']
        dict_node[v] = i
    T = nx.DiGraph()
    for i, v in enumerate(list(nx.dfs_tree(G, source=0))):
        T.add_node(dict_node[v], id=i, label=str(i), name=dict_name[i])
    for i, edge in enumerate(list(nx.dfs_edges(G, source=0))):
        T.add_edge(dict_node[edge[0]], dict_node[edge[1]], id=i, label=str(i))
    return nx.convert_node_labels_to_integers(T)