import treepatlib.graph_data_creation_module   as graph_creation
import treepatlib.gml_data_creation_module     as gml_creation
import treepatlib.drawing_data_creation_module as graph_data_creation
import treepatlib.draw    as drawing
import treepatlib.classes as myclass

import matplotlib.pyplot as plt
import copy
import time

def drawing_graph_data_creation(graph,top_node_id = None):
    graph = graph_data_creation.graph_data_check(graph)
    graph = copy.deepcopy(graph)
    
    if(top_node_id == None):
        top_node_id = graph.node[0].node_id
    node_id_list    = graph_data_creation.node_id_list_creation(graph.node)
    adjacent_list   = graph_data_creation.adjacent_list_creation(graph.edge, node_id_list)
    connecting_list = graph_data_creation.connecting_list_creation(graph.node, node_id_list, adjacent_list)
    
    graph_data_creation.node_floor_data_creation(graph.node, graph.drawing_order, node_id_list, connecting_list, top_node_id)
    node_hierarchy, how_many_to_floor, hierarchy_node_max = graph_data_creation.floor_infomation_creation(graph.node, node_id_list, top_node_id)
    node_type, half_distance_node                         = graph_data_creation.hyper_edge_node_decision(graph.node, node_id_list, graph.variables)

    graph_data_creation.graph_node_position_creation(graph.node, graph.drawing_order, node_id_list, how_many_to_floor, hierarchy_node_max, half_distance_node, node_interval = 10)
    
    drawing_data = myclass.Drawing()
    drawing_data.graph        = graph
    drawing_data.node_id_list = node_id_list
    drawing_data.node_type    = node_type
    
    return drawing_data

def binding_add_graph(drawing_data, binding_data):
    bindings = []
    id_lists          = []
    type_lists        = []
    graph              = copy.deepcopy(drawing_data.graph)
    graph_node_id_list = copy.deepcopy(drawing_data.node_id_list)
    binding            = copy.deepcopy(binding_data)
    
    type_lists = copy.deepcopy(drawing_data.node_type)
    
    if binding.node == []:
        empty = True
    else:
        empty = False
        
    target_ids, top_node, variable_list = graph_data_creation.binding_checker(graph, binding)
    
    bindings = graph_data_creation.binding_data_creation(graph, binding, target_ids, top_node)
    
    if empty:
        for i, (one_binding, target_id) in enumerate(zip(bindings, target_ids)):
            top = top_node[i]
            variable = variable_list[i]
            target_index = target_ids.index(target_id)
            graph_variable = variable_list[target_index]
            
            type_lists = copy.deepcopy(drawing_data.node_type)
                
            binding_graph, id_list, type_lists = graph_data_creation.binding_drawing_data_creation_other(graph, graph_node_id_list, variable, one_binding, id_lists, target_ids, type_lists)
            node_type, half_distance_node      = graph_data_creation.hyper_edge_node_decision(binding_graph.node, id_list, binding_graph.variables)
                
            binding_graph.drawing_order = graph_data_creation.order_list_maker(binding_graph.node, binding_graph.drawing_order, node_type, node_interval = 10)
            
    else:
        for i, (one_binding, target_id) in enumerate(zip(bindings, target_ids)):
            top = top_node[i]
            variable = variable_list[i]
            target_index = target_ids.index(target_id)
            graph_variable = variable_list[target_index]
            
            node_id_list    = graph_data_creation.node_id_list_creation(one_binding.node)
            adjacent_list   = graph_data_creation.adjacent_list_creation(one_binding.edge, node_id_list)
            connecting_list = graph_data_creation.connecting_list_creation(one_binding.node, node_id_list, adjacent_list)
            graph_data_creation.node_floor_data_creation(one_binding.node, one_binding.drawing_order, node_id_list, connecting_list, top)
            
            node_hierarchy, how_many_to_floor, hierarchy_node_max = graph_data_creation.floor_infomation_creation(one_binding.node, node_id_list, top)
            node_type, half_distance_node                         = graph_data_creation.hyper_edge_node_decision(one_binding.node, node_id_list, one_binding.variables)
                
            graph_data_creation.binding_node_position_creation(graph, graph_variable, graph_node_id_list, one_binding, top, node_id_list, node_hierarchy, how_many_to_floor, hierarchy_node_max, half_distance_node, node_interval = 10)
                
            id_lists.append(node_id_list)
            type_lists.append(node_type)
            
        binding_graph ,id_list         = graph_data_creation.binding_drawing_data_creation(graph, graph_node_id_list, variable_list, bindings, id_lists, target_ids, type_lists)
        node_type, half_distance_node  = graph_data_creation.hyper_edge_node_decision(binding_graph.node, id_list, binding_graph.variables)
        binding_graph.drawing_order = graph_data_creation.order_list_maker(binding_graph.node, binding_graph.drawing_order, node_type, node_interval = 10)
            
    drawing = myclass.Drawing()
    drawing.graph        = binding_graph
    drawing.node_id_list = id_list
    drawing.node_type    = node_type
    
    return drawing
    
def make_variable(drawing_data, frame_node_list, new_node_id, new_edge_id, new_label, gml_file_name):
    graph = copy.deepcopy(drawing_data.graph)
    graph_node_id_list = copy.deepcopy(drawing_data.node_id_list)
    graph_order_list   = copy.deepcopy(graph.drawing_order)
    
    graph, variable_graph = graph_data_creation.variable_conversion_maker(graph, graph_node_id_list, graph_order_list, frame_node_list, new_node_id, new_edge_id,new_label)
    drawing_graph = drawing_graph_data_creation(graph, top_node_id = None)
    gml_creation.gml_data_creation(gml_file_name, variable_graph)
    
    return drawing_graph
    
    
def make_gml(graph,data_name):
    graph = graph_data_creation.graph_data_check(graph)
    gml_creation.gml_data_creation(data_name, graph)

if __name__ == "__main__":
    main()
