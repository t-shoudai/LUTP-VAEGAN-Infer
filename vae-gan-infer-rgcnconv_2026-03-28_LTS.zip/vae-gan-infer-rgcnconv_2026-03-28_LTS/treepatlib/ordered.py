import matplotlib.pyplot as plt
import networkx as nx
import random
import copy
from typing import List, Optional

ROOT = 0
ROOT_NAME = '#'


def o_enumerate(
    G: Optional[nx.DiGraph] = None,
    num_edge: Optional[int] = None,
    num_graph: Optional[int] = None,
) -> List[nx.DiGraph]:
    """順序木を列挙する。

    起点グラフ G を指定しない場合は根のみの木から生成を開始する。
    G を指定した場合は G から拡張して num_graph 個の木を返す。

    Parameters
    ----------
    G:
        起点グラフ。None のとき根のみの木を起点とする。
    num_edge:
        G=None のとき、追加する辺数の上限。
    num_graph:
        G を指定したとき、生成するグラフ数。

    Returns
    -------
    list of nx.DiGraph
    """
    if G is None:
        G = nx.DiGraph()
        G.add_node(0, name=ROOT_NAME)
        if num_edge is None:
            num_edge = int(input("number of edges:"))
        if num_edge == 0:
            return []
        G = nx.convert_node_labels_to_integers(G)
        tree = [G]
        num = 0
        for j in range(num_edge):
            search = len(tree)
            for i in range(num, search):
                rmp = right_most_path(tree[i])
                for v in rmp:
                    G_new = copy.deepcopy(tree[i])
                    length = len(tree[i])
                    G_new.add_node(length, name=str(length - 1))
                    G_new.add_edge(v, length)
                    tree.append(G_new)
            num = search
        return tree
    else:
        G = nx.convert_node_labels_to_integers(G)
        if num_graph is None:
            num_graph = int(input("number of graph:"))
        if num_graph == 0:
            return []
        tree = [G]
        tree_make = copy.deepcopy(tree)
        while len(tree_make) < num_graph:
            rmp = right_most_path(tree[0])
            for v in rmp:
                G_new = copy.deepcopy(tree[0])
                length = len(tree[0])
                G_new.add_node(length, name=str(length - 1))
                G_new.add_edge(v, length)
                tree.append(G_new)
                tree_make.append(G_new)
                if len(tree_make) >= num_graph:
                    break
            tree.pop(0)
        return tree_make


def random_string(num_edge: int, string_list: List[str]) -> str:
    """ランダムな文字列を生成する。

    Parameters
    ----------
    num_edge:
        生成する文字数（辺数に対応）。
    string_list:
        文字の候補リスト。

    Returns
    -------
    str
    """
    random_list = [random.choice(string_list) for _ in range(num_edge)]
    return ''.join(random_list)


def relabel(G: nx.DiGraph, string_list: List[str]) -> List[nx.DiGraph]:
    """各辺の子頂点ラベルをランダムに付け直した木のリストを返す。

    辺の数と同じ長さのランダム文字列を生成し、
    各文字を対応する辺の子頂点（根以外）の name 属性に格納する。
    同一ラベル列が重複しないように生成する。

    Parameters
    ----------
    G:
        ラベルを付け替える対象のグラフ（子頂点に name 属性がないこと）。
    string_list:
        使用する文字候補。

    Returns
    -------
    list of nx.DiGraph
        子頂点の name 属性にラベルが格納された木のリスト。
    """
    num_string = len(string_list)
    loop = 0
    while loop == 0:
        label = []
        label_check = []
        num_edge = len(G.edges)
        num_graph = random.randint(1, max(num_string, num_edge))
        for i in range(1, num_graph + 1):
            label.append(random_string(num_edge, string_list))
        for i in label:
            if i not in label_check:
                label_check.append(i)
                loop = 1
            else:
                loop = 0
                break
    tree_label = []
    for label in label_check:
        G_new = copy.deepcopy(G)
        for e, v in enumerate(G_new.nodes):
            if v != ROOT and G_new.nodes(data='name')[v] is None:
                G_new.nodes[v]['name'] = label[e - 1]
        tree_label.append(G_new)
    return tree_label


def right_most_path(G: nx.DiGraph) -> List[int]:
    """順序木の最右路を返す。

    Parameters
    ----------
    G:
        対象の順序木（有向グラフ）。

    Returns
    -------
    list of int
        根から最右葉までのノード列。
    """
    G_copy = copy.deepcopy(G)
    G_copy = nx.dfs_tree(G_copy, source=ROOT)
    rmp = [0]
    n = 0
    while len(G_copy.adj[n]) != 0:
        keep = list(G_copy.adj[n])
        n = keep[-1]
        rmp.append(n)
    return rmp


def randomtree(
    num_graph: int,
    string_list: List[str],
    G: Optional[nx.DiGraph] = None,
) -> List[nx.DiGraph]:
    """ランダムにラベル付けされた順序木を num_graph 個生成する。

    各辺の子頂点の name 属性にラベルが格納された木を返す。

    Parameters
    ----------
    num_graph:
        生成する木の数。
    string_list:
        子頂点ラベルに使う文字の候補リスト。
    G:
        起点グラフ。None のとき根のみの木から開始する。

    Returns
    -------
    list of nx.DiGraph
    """
    if G is None:
        G = nx.DiGraph()
        G.add_node(0, name=ROOT_NAME)
    G = nx.convert_node_labels_to_integers(G)

    tree_label = [G]
    tree = [G]

    while len(tree_label) < num_graph:
        rmp = right_most_path(tree[0])
        for v in rmp:
            G_new = copy.deepcopy(tree[0])
            length = len(tree[0])
            G_new.add_node(length)
            G_new.add_edge(v, length)
            tree.append(G_new)

            labels = relabel(G_new, string_list)
            for label in labels:
                G_copy = copy.deepcopy(G_new)
                for e, v in enumerate(G_new.nodes):
                    if v != ROOT and G_copy.nodes(data='name')[v] is None:
                        G_copy.nodes[v]['name'] = label[e - 1]
                tree_label.append(G_copy)
                if len(tree_label) >= num_graph:
                    break
            if len(tree_label) >= num_graph:
                break
        tree.pop(0)
    return tree_label


def left_sibling(G: nx.DiGraph, v: int) -> int:
    """ノード v の一つ左の兄弟ノードを返す。

    v が根または左端の子の場合は v 自身を返す。

    Parameters
    ----------
    G:
        対象グラフ。
    v:
        対象ノード。

    Returns
    -------
    int
        左兄弟のノード ID。
    """
    left = 0
    if v != 0:
        parent = list(G.predecessors(v))[0]
        left = list(G.adj[parent])[list(G.adj[parent]).index(v) - 1]
        if v <= left:
            left = v
    return left
