# treepatlib

無順序木・順序木のパターンマッチングと列挙のための Python ライブラリです。

## 主な機能

- **木の列挙**: 辺数を指定した順序木・無順序木の全列挙 (`o_enumerate`, `u_enumerate`)
- **ランダム生成**: ラベル付き木のランダム生成 (`ordered.randomtree`, `unordered.randomtree`)
- **パターンマッチング**: 変数付き無順序木パターンマッチング (`matching`)
- **正例・負例生成**: パターンに対する正例/負例木の生成 (`make_positive`, `make_negative`)
- **標準形変換**: 深さ優先左/右優先標準形への変換 (`left_depth_priferred_tree`, `right_depth_preferred_tree`)
- **描画**: matplotlib を使った木の可視化 (`tree_draw`, `drawing`)
- **シリアライズ**: DFUDS 形式での木の保存・復元 (`dfuds`, `return_to_graph`, `tree_save`)
- **帰納学習**: 正例集合からパターンを帰納的に学習 (`infer.refine_pattern`)
- **GML 入出力**: GML 形式によるグラフの読み書き

## インストール

```bash
pip install -e .
```

## 使い方

### 無順序木の列挙

```python
import treepatlib as tpl

# 辺数 3 以下の無順序木を全列挙
trees = tpl.u_enumerate(num_edge=3)
print(f"{len(trees)} 個の木を列挙")
```

### 順序木の列挙

```python
# 辺数 3 以下の順序木を全列挙
trees = tpl.o_enumerate(num_edge=3)
```

### ランダム木の生成

```python
import networkx as nx

# ラベルアルファベット
labels = ['a', 'b', 'c']

# 無順序木を 50 個ランダム生成
trees = tpl.unordered.randomtree(50, labels)
```

### パターンマッチング

変数ノード（`name='X'`）を含むパターン木に対してマッチング判定ができます。

```python
import networkx as nx

# パターン木を構築（根 → a → X の形）
P = nx.DiGraph()
P.add_node(0, name='#')  # 根
P.add_node(1, name='a')
P.add_node(2, name='X')  # 変数
P.add_edge(0, 1)
P.add_edge(1, 2)

# 対象木
G = nx.DiGraph()
G.add_node(0, name='#')
G.add_node(1, name='a')
G.add_node(2, name='b')
G.add_edge(0, 1)
G.add_edge(1, 2)

result = tpl.matching(P, G)  # True
```

### 正例・負例の生成

```python
# 正例を 100 個生成
pos_trees = tpl.make_positive(100, trees, P)

# 負例を 100 個生成
neg_trees = tpl.make_negative(100, labels, P)
```

### 木の描画

```python
import networkx as nx

T = nx.DiGraph()
T.add_node(0, name='#')
T.add_node(1, name='a')
T.add_node(2, name='b')
T.add_edge(0, 1)
T.add_edge(0, 2)

tpl.tree_draw(T, file_name='my_tree')  # my_tree.png に保存
```

### DFUDS シリアライズ

```python
# 木 → DFUDS 文字列
s = tpl.dfuds(T)

# DFUDS 文字列 → 木
T2 = tpl.return_to_graph(s)
```

## モジュール構成

| モジュール | 説明 |
|---|---|
| `classes` | コアデータ構造 (`Node`, `Edge`, `Graph`, `Binding`, `Drawing`) |
| `ordered` | 順序木の列挙・ランダム生成・最右路 |
| `unordered` | 無順序木のマッチング・列挙・正負例生成 |
| `draw` | 描画・DFUDS シリアライズ・NetworkX 変換 |
| `tree_graph_creation_module` | 描画データ生成・バインディング処理 |
| `graph_data_creation_module` | GML ファイル読み込み |
| `gml_data_creation_module` | GML ファイル書き出し |
| `drawing_data_creation_module` | レイアウト計算 |
| `infer` | 正例集合からの帰納学習（精密化演算子・メインループ） |

## 変数ノードについて

パターン中の変数ノードは `name='X'` のノードとして表します。
`matching()` 呼び出し時に `variable=True`（デフォルト）のとき有効になります。

## 依存ライブラリ

- Python >= 3.8
- networkx >= 2.6
- matplotlib >= 3.4


### 帰納学習

```python
import treepatlib as tpl

# 初期パターン: 根 -> X
t_init = tpl.infer.initial_pattern()

# 帰納学習（positive_set: 正例の nx.DiGraph リスト）
t_result = tpl.infer.refine_pattern(
    t_init,
    positive_set,
    edge_factor=['a', 'b', 'c', 'd', 'e'],
    verbose=True,
)
print([(n, t_result.nodes[n]['name']) for n in t_result.nodes()])
```
