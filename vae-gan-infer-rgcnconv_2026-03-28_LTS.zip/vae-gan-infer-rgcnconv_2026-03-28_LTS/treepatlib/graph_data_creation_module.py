import os
os.getcwd()
import treepatlib.classes as myclass

def graph_data_creation(gml_file_name):
    gml_file_data = os.path.join(os.getcwd(), gml_file_name)
    #gml_file_data = os.path.join(os.path.dirname(__file__), gml_file_name)
    gml_file      = open(gml_file_data,'r',encoding="utf_8")
    #print('open gml file name :',gml_file_data)
    graph = myclass.Graph()
    data_type_node       = 'node'
    data_type_edge       = 'edge'
    data_type_hyper_edge = 'hyper_edge'
    
    node_data_rows       = []
    edge_data_rows       = []
    hyper_edge_data_rows = []
    
    while True:
        line = gml_file.readline() 
        if line:
            split_data = line.split()
                
            if split_data[0] == data_type_node:
                if len(split_data) > 1:
                    data_count = 3
                else:
                    data_count = 4
                element_rows = data_acquisition(gml_file, data_count)
                #print(element_rows)
                node_data_rows.append(element_rows)
                
            elif split_data[0] == data_type_edge:
                if len(split_data) > 1:
                    data_count = 5
                else:
                    data_count = 6
                element_rows = data_acquisition(gml_file, data_count)
                #print(element_rows)
                edge_data_rows.append(element_rows)
                
            elif split_data[0] == data_type_hyper_edge:
                data_count = 6
                element_rows = data_acquisition(gml_file, data_count)
                hyper_edge_data_rows.append(element_rows)
        else:
            break
        
    node = node_data(node_data_rows)
    edge = edge_data(edge_data_rows)
    h_node,h_edge,variable = hyper_edge_data(hyper_edge_data_rows)
    
    node.extend(h_node)
    edge.extend(h_edge)

    graph.node      = node
    graph.edge      = edge
    graph.variables = variable
    graph.drawing_order = []
    graph.bind_num      = 0
    
    gml_file.close()
    #print('Graph data has been created.\n ')
    return graph

def binding_data_creation(gml_file_name,target_label,style):
    gml_file_date = os.path.join(os.path.dirname(__file__), gml_file_name)
    gml_file      = open(gml_file_date,'r',encoding="utf_8")
    print('open gml file name :',gml_file_date)
    
    binding = myclass.Binding()
    data_type_node       = 'node'
    data_type_edge       = 'edge'
    data_type_hyper_edge = 'hyper_edge'
    
    node_data_rows       = []
    edge_data_rows       = []
    hyper_edge_data_rows = []
    
    while True:
        line = gml_file.readline() 
        if line:
            split_data = line.split()
                
            if split_data[0] == data_type_node:
                data_count = 4
                element_rows = data_acquisition(gml_file, data_count)
                node_data_rows.append(element_rows)
                
            elif split_data[0] == data_type_edge:
                data_count = 6
                element_rows = data_acquisition(gml_file, data_count)
                edge_data_rows.append(element_rows)
                
            elif split_data[0] == data_type_hyper_edge:
                data_count = 6
                element_rows = data_acquisition(gml_file, data_count)
                hyper_edge_data_rows.append(element_rows)
        else:
            break

    node = node_data(node_data_rows)
    edge = edge_data(edge_data_rows)
    h_node,h_edge,variable = hyper_edge_data(hyper_edge_data_rows)
    
    node.extend(h_node)
    edge.extend(h_edge)
    #---
    binding.target_label  = target_label
    binding.node          = node
    binding.edge          = edge
    binding.variables     = variable
    binding.style         = style
    binding.drawing_order = []
    binding.bind_num      = 0
    
    gml_file.close()
    print('Binding data has been created.\n ')

    return binding

def data_acquisition(gml_file,data_count):
    element_rows = []
    for i in range(data_count):
        line = gml_file.readline().split()
        element_rows.append(line)
        #print(line)
    if element_rows[data_count - 1][0] != ']':
        raise Exception('There was an error with this file.')
    else:
        element_rows.pop(-1)
    element_rows.sort()
    element_rows.append([']'])
    if element_rows[0][0] != '[':
        element_rows.insert(0,['['])
    return element_rows

def node_data(node_data_row):
    node_id_row = 1
    label_row   = 2
    nodes       = []
    #label処理用変数
    exclusion    = "\""
    label_list   = []
    label_str    = ""
    
    for row in node_data_row:
        one_node = myclass.Node()
        one_node.node_id    = int(row[node_id_row][1])
        #label処理
        label_str  = ""
        label_list = list(row[label_row][1])
        for labels in label_list:
            if labels != exclusion:
                label_str += labels
        one_node.label      = label_str
        nodes.append(one_node)
        #one_node.print_data()
        del one_node
    return nodes

def edge_data(edge_data_row):
    edge_id_row = 1
    label_row   = 2
    source_row  = 3
    target_row  = 4
    edges       = []
    #label処理用変数
    exclusion    = "\""
    label_list   = []
    label_str    = ""
    
    for row in edge_data_row:
        one_edge = myclass.Edge()
        one_edge.edge_id  = int(row[edge_id_row][1])
        one_edge.edge     = (int(row[source_row][1]),int(row[target_row][1]))
        #label処理
        label_str  = ""
        label_list = list(row[label_row][1])
        for labels in label_list:
            if labels != exclusion:
                label_str += labels
        one_edge.label      = label_str
        edges.append(one_edge)
        #one_edge.print_data()
        del one_edge
    return edges

def hyper_edge_data(hyper_edge_data_row):
    node_id_row  = 1
    edge_id_row  = 2
    label_row    = 3
    target_row   = 4
    nodes        = []
    edges        = []
    variables    = []
    #label処理用変数
    exclusion    = "\""
    label_list   = []
    label_str    = ""
    
    for row in hyper_edge_data_row:
        node_id  = int(row[node_id_row][1])
        #label処理
        label_str  = ""
        label_list = list(row[label_row][1])
        for labels in label_list:
            if labels != exclusion:
                label_str += labels
        label    = label_str
        edge_ids = value_list_creation(row[edge_id_row][1])
        targets  = value_list_creation(row[target_row][1])
        if len(edge_ids) != len(targets):
            raise Exception('There was an error with this file.')
        #node
        one_node         = myclass.Node()
        one_node.node_id = node_id
        one_node.label   = label
        nodes.append(one_node)
        #one_node.print_data()
        del one_node
        #variable
        one_variable         = myclass.Variable()
        one_variable.node_id = node_id
        one_variable.style   = targets
        variables.append(one_variable)
        #one_variable.print_data()
        del one_variable
        #edge
        for edge_id,target in zip(edge_ids, targets):
            one_edge = myclass.Edge()
            one_edge.edge_id = edge_id
            one_edge.edge    = (node_id,target)
            one_edge.label   = label
            edges.append(one_edge)
            #one_edge.print_data()
            del one_edge
    return nodes,edges,variables
        
def value_list_creation(row):
    value_list = []
    value = ''
    row_data = list(row)
    for data in row_data:
        if (data != '[') & (data != ']'):
            value += data
    value_data = value.split(',')
    for data in value_data:
        if data.isdigit():
            value_list.append(int(data))
    return value_list
