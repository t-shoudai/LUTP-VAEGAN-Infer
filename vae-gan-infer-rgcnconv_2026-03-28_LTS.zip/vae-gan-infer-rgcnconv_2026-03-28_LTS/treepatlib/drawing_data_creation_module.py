import treepatlib.classes as myclass
import copy

def graph_data_check(graph_data):
    if type(graph_data) is myclass.Drawing:
        graph = graph_data.graph
    else:
        graph = graph_data
    return graph

def node_id_list_creation(node):
    node_id_list = [node_data.node_id for node_data in node]
    
    return node_id_list

def adjacent_list_creation(edge, node_id_list):
    adjacent_list = [[0]*len(node_id_list) for node in node_id_list]
        
    for edge_data in edge:
        source = edge_data.edge[0]
        target = edge_data.edge[1]
        
        s = node_id_list.index(source)
        t = node_id_list.index(target)
        
        adjacent_list[s][t] = 1
        adjacent_list[t][s] = 1
        
    return adjacent_list

def connecting_list_creation(node, node_id_list, adj_list):
    connecting_list = []
    connecting_node = []
    for i in range(len(node_id_list)):
        for j,adj in enumerate(adj_list[i]):
            if adj == 1:
                connecting_node.append(node_id_list[j])
        connecting_list.append(connecting_node)
        node[i].edge_count = len(connecting_node)
        connecting_node = []
        
    return connecting_list

def node_floor_data_creation(node, order, node_id_list, connecting_list, top_node_id):
    if order != []:
        order.clear()
    current_hierarchy  = [top_node_id]
    under_hierarchy    = []
    upper_floor_nodes  = []
    under_floor_nodes  = []
    for node_id in node_id_list:
        if len(current_hierarchy) != 0:
            for current_node in current_hierarchy:
                order.append(current_node)
                current_node_index = node_id_list.index(current_node)
                connecting_nodes   = connecting_list[current_node_index]
                upper_nodes        = node[current_node_index].upper_floor
                
                for connecting_node in connecting_nodes:
                    if connecting_node not in upper_nodes:
                        under_floor_nodes.append(connecting_node)
                node[current_node_index].under_floor = under_floor_nodes.copy()
                upper_floor_nodes = [current_node]
                
                for under_floor in under_floor_nodes:
                    under_floor_index  = node_id_list.index(under_floor)
                    node[under_floor_index].upper_floor = upper_floor_nodes.copy()
                under_hierarchy += under_floor_nodes
                under_floor_nodes.clear()
                upper_floor_nodes.clear()
            current_hierarchy = under_hierarchy.copy()
            under_hierarchy.clear()
        else:
            break
        
def floor_infomation_creation(node, node_id_list, top_node_id):
    lower_node      = []
    how_many_to_floor  = []
    hierarchy_node_max = 0
        
    node_hierarchy = [0 for i in range(len(node_id_list))]
        
    hierarchy = 0
    hierarchy_nodes = [top_node_id]
    
    for i in range(len(node_id_list)):
        if len(hierarchy_nodes) != 0:
            how_many_to_floor.append(len(hierarchy_nodes))
            for j,hierarchy_node in enumerate(hierarchy_nodes):
                current_node_index = node_id_list.index(hierarchy_node)
                node_hierarchy[current_node_index] = hierarchy
                lower_node += node[current_node_index].under_floor
            hierarchy += 1
            hierarchy_nodes = lower_node
            lower_node      = []
            if len(hierarchy_nodes) > hierarchy_node_max:
                hierarchy_node_max = len(hierarchy_nodes)
        else:
            break
        
    return node_hierarchy, how_many_to_floor, hierarchy_node_max

def hyper_edge_node_decision(node, node_id_list, variables):
    variable  = []
    node_type = []
    half_distance_node  = []
    different_pos_nodes = []
    
    variable = [variable_data.node_id for variable_data in variables]
    variable_styles = [variable_data.style for variable_data in variables]
        
    for i in range(len(node_id_list)):
        node_type.append(False)
        half_distance_node.append(False)
        
    for i in range(len(node_id_list)):
        if node_id_list[i] in variable:
            node_type[i]          = True  
            half_distance_node[i] = True
            different_pos_nodes.append(node[i].under_floor)
            
    for different_pos_node, style_nodes in zip(different_pos_nodes, variable_styles):
        for node in different_pos_node:
            if node in style_nodes:
                index = node_id_list.index(node)
                half_distance_node[index] = True
            
    return node_type, half_distance_node

def graph_node_position_creation(node, draw_order_list, node_id_list, how_many_to_floor, hierarchy_node_max, half_distance_node, node_interval = 10):
    hierarchy_count = len(how_many_to_floor)
    under_nodes     = []
    next_hierarchy  = []
    width = node_interval * hierarchy_node_max
    py    = 0
    count = 0
    
    for i,floor in enumerate(how_many_to_floor):
        if i == 0:
            area      = width/floor
            area_harf = area/2
            min_pos   = 0
            
            for j in range(floor):
                node_index = node_id_list.index(draw_order_list[count])
                px = min_pos + area_harf + area*j
                py = py
                node[node_index].position      = (px,py)
                node[node_index].position_area = (px,py,area_harf)
                under_nodes.append(node[node_index].under_floor)
                count += 1
            next_hierarchy = under_nodes
            under_nodes    = []
            width          = area
            
        elif len(next_hierarchy) != 0:
            for next_hierarchy_nodes in next_hierarchy:
                for j,hierarchy_node in enumerate(next_hierarchy_nodes):
                    node_index = node_id_list.index(draw_order_list[count])
                    if j == 0:
                        before_node       = node[node_index].upper_floor
                        before_node_index = node_id_list.index(before_node[0])
                        before_px         = node[before_node_index].position_area[0]
                        before_py         = node[before_node_index].position_area[1]
                        before_area_half  = node[before_node_index].position_area[2]
                        
                        width     = before_area_half*2
                        min_pos   = before_px - before_area_half
                        area      = width/len(next_hierarchy_nodes)
                        area_harf = area/2
                    px = min_pos + area_harf + area*j
                    
                    if half_distance_node[node_index] == True:
                        py = before_py - (node_interval/2)
                    else:
                        py = before_py - node_interval
                    node[node_index].position      = (px,py)
                    node[node_index].position_area = (px,py,area_harf)
                    if (len(node[node_index].under_floor) != 0):
                        under_nodes.append(node[node_index].under_floor)
                    count += 1
            next_hierarchy = under_nodes
            under_nodes    = []
            
def binding_checker(graph, binding):
    all_variable_list     = []
    variable_list         = []
    variable_node_id_list = []
    target_node_id_list   = []
    target_upper_node_id  = []
    error_data = []
    
    for variable in graph.variables:
        all_variable_list.append(variable)
        variable_node_id_list.append(variable.node_id)
        
    for node in graph.node:
        if (node.node_id in variable_node_id_list) & (node.label == binding.target_label):
            target_node_id_list.append(node.node_id)
            target_upper_on_graph = node.upper_floor[0]
            variable_index        = variable_node_id_list.index(node.node_id)
            target_upper_indedx   = all_variable_list[variable_index].style.index(target_upper_on_graph)
            target_upper_node_id.append(binding.style[target_upper_indedx])
            variable_list.append(all_variable_list[variable_index])
            
    for variable_node_id, variable in zip(variable_node_id_list, all_variable_list):
        if (variable_node_id in target_node_id_list) & (len(variable.style) != len(binding.style)):
            error_data.append(variable_node_id)
    
    if len(error_data) != 0:
        error_str = ''
        if len(error_data) > 1:
            for i,error in enumerate(error_data):
                if i < len(error_data) - 1:
                    error_str += (str(error) + (', '))
                else:
                    error_str += str(error)
        else:
            error_str += error_str + str(error_data[len(error_data) - 1])
        raise Exception(f'The style of node id {error_str} is wrong.')
    return target_node_id_list, target_upper_node_id, variable_list

def binding_data_creation(graph, binding, target_id, top_node):
    graph_node_digits = len(str(len(graph.node)))
    bindings  = []
    
    for i in range(len(target_id)):
        
        nodes = []
        edges = []
        variables = []
        styles    = []
        this_bind_num = graph.bind_num + i + 1
        
        for node_data in binding.node.copy():
            node = myclass.Node()
            node.node_id = node_data.node_id * (10**graph_node_digits) + this_bind_num
            if node_data.node_id == top_node[i]:
                top_node[i] = node.node_id
            node.label   = node_data.label
            nodes.append(node)
            del node
            
        for edge_data in binding.edge.copy():
            edge = myclass.Edge()
            edge.edge_id = edge_data.edge_id * (10**graph_node_digits) + this_bind_num
            edge.label   = edge_data.label
            source       = edge_data.edge[0] * (10**graph_node_digits) + this_bind_num
            target       = edge_data.edge[1] * (10**graph_node_digits) + this_bind_num
            edge.edge    = (source,target)
            edges.append(edge)
            del edge
            
        for variable_data in binding.variables.copy():
            style_list = []
            variable = myclass.Variable()
            variable.node_id  = variable_data.node_id * (10**graph_node_digits) + this_bind_num
            for style_node in variable_data.style:
                style_list.append(style_node * (10**graph_node_digits) + this_bind_num)
            variable.style = style_list
            variables.append(variable)
            del variable
            
        for style_data in binding.style.copy():
            style = 0
            style = style_data * (10**graph_node_digits) + this_bind_num
            styles.append(style)
            
        bind               = myclass.Binding()
        bind.node          = nodes.copy()
        bind.edge          = edges.copy()
        bind.variables     = variables.copy()
        bind.style         = styles.copy()
        bind.drawing_order = []
        bind.bind_num      = this_bind_num
        
        bindings.append(bind)
        
        del bind,nodes,edges,variables,styles
    return bindings

def binding_node_position_creation(graph, graph_variable, graph_node_id_list, binding, top_node, node_id_list, node_hierarchy, how_many_to_floor, hierarchy_node_max, half_distance_node, node_interval = 10):
    binding.drawing_order = draw_order(graph.drawing_order, graph_variable, binding.node, binding.style, binding.drawing_order, node_id_list, node_hierarchy, how_many_to_floor)
    binding_node_position(graph, graph_variable, graph_node_id_list, binding, node_id_list, node_hierarchy, how_many_to_floor, hierarchy_node_max, half_distance_node, node_interval)
    
def draw_order(graph_drawing_order, graph_variable, binding_node, binding_style, binding_drawing_order, node_id_list, node_hierarchy, how_many_to_floor):
    descending_order = []
    des = []
    asc = []
    for node in reversed(graph_drawing_order):
        if node in graph_variable.style:
            node_index = graph_variable.style.index(node)
            descending_order.append(binding_style[node_index])
    
    for node in reversed(binding_drawing_order):
        if node in descending_order:
            des.append(node)
    
    drawing_hierarcky = []
    hierarchy         = []
    count = 0
    for floor in how_many_to_floor:
        hierarchy = []
        for i in range(floor):
            hierarchy.append(binding_drawing_order[count])
            count += 1
        drawing_hierarcky.append(hierarchy)
    
    count  = 0
    uppers = []
    for node_list in descending_order:
        node_num = node_list
        index = node_id_list.index(node_num)
        hi    = node_hierarchy[index]
        upper = binding_node[index].upper_floor
        for floor in reversed(range(hi)):
            for up in upper:
                index = node_id_list.index(up)
                uppers += binding_node[index].upper_floor
                if len(drawing_hierarcky[floor]) > 1:
                    pop_index = drawing_hierarcky[floor].index(up)
                    pop_data = drawing_hierarcky[floor].pop(pop_index)
                    drawing_hierarcky[floor].insert(count,pop_data)
            upper = uppers
            uppers = []
        
    for floor in drawing_hierarcky:
        for node in floor:
            asc.append(node)
    return asc

def binding_node_position(graph, graph_variable, graph_node_id_list, binding, node_id_list, node_hierarchy, how_many_to_floor, hierarchy_node_max, half_distance_node, node_interval):
    hierarchy_count = len(how_many_to_floor)
    x = []
    y = []
    harf = []
    under_nodes     = []
    next_hierarchy  = []
    top_only = False
    
    top_node = graph.node[0]
    
    for variable_data in graph_variable.style:
        node_index = graph_node_id_list.index(variable_data)
        position_area = graph.node[node_index].position_area
        x.append(position_area[0])
        y.append(position_area[1])
        harf.append(position_area[2])
        if node_index == 0:
            top_only = True
        
    if len(x) < 2:
        append_node_index = graph_node_id_list.index(graph_variable.node_id)
        append = graph.node[append_node_index].position_area
        x.append(append[0])
        y.append(append[1]*2)
        harf.append(append[2])
        
    x_max = max(x)
    x_min = min(x)
    y_max = max(y)
    y_min = min(y)
    harf_min = min(harf)
    under_count = harf.count(harf_min)
    x_area = ((x_min - harf_min) + (x_min + harf_min))*under_count
    y_area = y_max - y_min
    print(x_min,x_max,y_min,y_max)
    
    width       = x_area
    py_distance = y_area / (hierarchy_count - 1)
    py          = y_max
    count       = 0
    
    for i, floor in enumerate(how_many_to_floor):
        if i == 0:
            area      = width/floor
            area_harf = x_area/2
            print(area_harf)
            
            if top_only == True:
                min_pos = harf_min
            else:
                min_pos = 0
            
            for j in range(floor):
                node_index = node_id_list.index(binding.drawing_order[count])
                px = min_pos + area_harf + area*j
                py = py
                binding.node[node_index].position      = (px,py)
                binding.node[node_index].position_area = (px,py,area_harf)
                under_nodes.append(binding.node[node_index].under_floor)
                count += 1
            next_hierarchy = under_nodes
            under_nodes    = []
            width          = area
            
        elif len(next_hierarchy) != 0:
            for next_hierarchy_nodes in next_hierarchy:
                for j,hierarchy_node in enumerate(next_hierarchy_nodes):
                    node_index = node_id_list.index(binding.drawing_order[count])
                    if j == 0:
                        before_node       = binding.node[node_index].upper_floor
                        before_node_index = node_id_list.index(before_node[0])
                        before_px         = binding.node[before_node_index].position_area[0]
                        before_py         = binding.node[before_node_index].position_area[1]
                        before_area_half  = binding.node[before_node_index].position_area[2]
                        
                        width     = before_area_half*2
                        min_pos   = before_px - before_area_half
                        area      = width/len(next_hierarchy_nodes)
                        area_harf = area/2
                    px = min_pos + area_harf + area*j
                    
                    if half_distance_node[node_index] == True:
                        py = before_py - (py_distance/2)
                    else:
                        py = before_py - py_distance
                    binding.node[node_index].position      = (px,py)
                    binding.node[node_index].position_area = (px,py,area_harf)
                    if (len(binding.node[node_index].under_floor) != 0):
                        under_nodes.append(binding.node[node_index].under_floor)
                    count += 1
            next_hierarchy = under_nodes
            under_nodes    = []
            
def binding_drawing_data_creation(graph, graph_node_id_list, variable_list, binding, node_id_list, target_node_id, node_type):
    binding_graph = myclass.Graph()
    node          = copy.deepcopy(graph.node)
    edge          = copy.deepcopy(graph.edge)
    variables     = copy.deepcopy(graph.variables)
    drawing_order = []
    #---
    bind_num_max = 0
    #---
    id_list   = copy.deepcopy(graph_node_id_list)

    remove_node      = []
    remove_edge      = []
    remove_variables = []
    
    for i,target in enumerate(target_node_id):
        node_index = id_list.index(target)
        remove_object = node[node_index]
        node.remove(remove_object)
        remove_node.append(target)
        id_list.remove(target)
    dels = []
    
    for i,target in enumerate(target_node_id):
        dust = []
        variable = variable_list[i].style.copy()
        style    = binding[i].style
        for j, (variable_data, style_data) in enumerate(zip(variable, style)):
            index1 = id_list.index(variable_data)
            index2 = node_id_list[i].index(style_data)
            node[index1].node_id = binding[i].node[index2].node_id
            node[index1].label   = binding[i].node[index2].label
            node[index1].edge_count = binding[i].node[index2].edge_count
            node[index1].upper_floor = binding[i].node[index2].upper_floor
            for under in node[index1].under_floor:
                und = []
                if (under not in binding[i].node[index2].under_floor) & (under != target):
                    und.append(under)
            node[index1].under_floor = binding[i].node[index2].under_floor + und
            dust.append(binding[i].node[index2])
            id_list[index1] = binding[i].node[index2].node_id
        dels.append(dust)
        
    for i,delete in enumerate(dels):
        for obj in reversed(delete):
            binding[i].node.remove(obj)
            
    for i,target in enumerate(target_node_id):
        variable = variable_list[i].style
        style    = binding[i].style
        
        for edge_data in edge:
            if edge_data not in remove_edge:
                if (edge_data.edge[0] == target) | (edge_data.edge[1] == target):
                    remove_edge.append(edge_data)
                elif edge_data.edge[0] in variable:
                    num = variable.index(edge_data.edge[0])
                    edge_data.edge = (style[num],edge_data.edge[1])
                elif edge_data.edge[1] in variable:
                    num = variable.index(edge_data.edge[1])
                    edge_data.edge = (edge_data.edge[0],style[num])
    
    for remove_object in remove_edge:
        edge.remove(remove_object)
    
    for variable_data in variables:
        if variable_data.node_id in remove_node:
            remove_variables.append(variable_data)
    
    for remove_object in remove_variables:
        variables.remove(remove_object)
    
    for i,bind in enumerate(binding):
        for node_data in bind.node:
            node.append(node_data)
            id_list.append(node_data.node_id)
        for edge_data in bind.edge:
            edge.append(edge_data)
        for variable_data in bind.variables:
            variables.append(variable_data)
            
        bind_num_max = bind.bind_num
        
    for node_data in node:
        for i, upper in enumerate(node_data.upper_floor):
            for variable_data in variable_list:
                variable_style = variable_data.style
                if upper in variable_style:
                    index = variable_style.index(upper)
                    node_data.upper_floor[i] = style[index]
        for i,under in enumerate(node_data.under_floor):
            for variable_data in variable_list:
                variable_style = variable_data.style
                if under in variable_style:
                    index = variable_style.index(under)
                    node_data.under_floor[i] = style[index]
                    
    binding_graph.node          = node.copy()
    binding_graph.edge          = edge.copy()
    binding_graph.variables     = variables.copy()
    binding_graph.drawing_order = drawing_order.copy()
    binding_graph.bind_num      = bind_num_max
    
    return binding_graph, id_list

def order_list_maker(node, graph_drawing_order, node_type, node_interval = 10):
    #drawing_order
    drawing_order_rev = []
    x = []
    y = []
    node_ids = []
    for i, node_data in enumerate(node):
        x.append(node_data.position[0])
        if node_type[i] == True:
            data = node_data.position[1] - (node_interval/2)
            y.append(data)
        else:
            y.append(node_data.position[1])
        node_ids.append(node_data.node_id)
    ids = node_ids.copy()
    count = len(node_ids)
    while 0 < count:
        y_mins = [i for i, v in enumerate(y) if v == min(y)]
        del_nums = y_mins.copy()
        xs = [x[y_num] for y_num in y_mins]
        now_len = len(y_mins)
        for i in range(now_len):
            num = xs.index(max(xs))
            drawing_order_rev.append(node_ids[y_mins[num]])
            y_mins.pop(num)
            xs.pop(num)
            count -= 1
        for dels in reversed(del_nums):
            x.pop(dels)
            y.pop(dels)
            node_ids.pop(dels)
    drawing_order = [data for data in reversed(drawing_order_rev)]
        
    return drawing_order

def binding_drawing_data_creation_other(graph, graph_node_id_list, variable, binding, node_id_list, target_node_id, node_type):
    binding_graph = myclass.Graph()
    nodes         = copy.deepcopy(graph.node)
    edges         = copy.deepcopy(graph.edge)
    variables     = copy.deepcopy(graph.variables)
    drawing_order = []
    #---
    #---
    id_list   = copy.deepcopy(graph_node_id_list)
    type_list = copy.deepcopy(graph.drawing_order)
   
    remove_type_pos  = []
    remove_node      = []
    remove_edge      = []
    remove_variables = []
    remove_ids       = []
 
    target_upper_node = []
    target_under_node = []
    more_under_node   = []
   
    remove_nodes = []
   
    for i,target in enumerate(target_node_id):
        remove_nodes.append(target)
        node_index = id_list.index(target)
        #target_getter
        target_upper_node += nodes[node_index].upper_floor
        target_under_node.append(nodes[node_index].under_floor)
        remove_nodes += nodes[node_index].under_floor
        #
        remove_object = nodes[node_index]
        remove_node.append(remove_object)
        remove_ids.append(target)
        
    for remove_id in remove_ids:
        for node in nodes:
            if remove_id in node.upper_floor:
                node.upper_floor.remove(remove_id)
            if remove_id in node.under_floor:
                node.under_floor.remove(remove_id)
 
    for target_under in target_under_node:
        for under in target_under:
            node_index = id_list.index(under)
            remove_object = nodes[node_index]
            if under in variable.style:
                more_under_node += remove_object.under_floor
                remove_node.append(remove_object)
                remove_ids.append(under)
            else:
                more_under_node.append(under)
           
    dels = []
   
    for edge in edges:
        if (edge.edge[0] in remove_ids) | (edge.edge[1] in remove_ids):
            remove_edge.append(edge)
                   
    for remove_object in remove_edge:
        edges.remove(remove_object)
   
    for variable_data in variables:
        if variable_data.node_id in remove_ids:
            remove_variables.append(variable_data)
   
    for remove_object in remove_variables:
        variables.remove(remove_object)
 
    graph_node_digits = len(str(len(graph.node)))
    this_bind_num     = binding.bind_num
   
    for target, upper_node in zip(target_node_id, target_upper_node):
        for i, more_under in enumerate(more_under_node):
            index = id_list.index(target)
            append_edge = myclass.Edge()
            append_edge.edge_id = (i + 1) * (10**graph_node_digits) + this_bind_num
            append_edge.label   = nodes[index].label
            append_edge.edge    = (upper_node, more_under)
           
            edges.append(append_edge)
           
            del append_edge
   
    for remove_object in reversed(remove_node):
        nodes.remove(remove_object)
   
    for obj in reversed(remove_ids):
        id_index = id_list.index(obj)
        id_list.remove(obj)
        node_type.pop(id_index)
   
    drawing_order = [ids for ids in id_list]
   
    binding_graph.node          = nodes.copy()
    binding_graph.edge          = edges.copy()
    binding_graph.variables     = variables.copy()
    binding_graph.drawing_order = drawing_order.copy()
    binding_graph.bind_num      = this_bind_num
   
    return binding_graph, id_list, node_type
 
def variable_conversion_maker(graph, graph_node_id_list, graph_order_list, id_list, new_node_id, new_edge_id, new_label):
    if len(id_list) != len(new_edge_id):
        raise Exception('The number of nodes does not match the number of ids.')
    x = []
    y = []
    harf = []
    under_nodes     = []
    next_hierarchy  = []
        
    #--
    variable_nodes     = []
    remove_nodes       = []
    remove_nodes_add   = []
    remove_edges       = []
    remove_variables   = []
    variable_nodes_id_list = []
    remove_nodes_id_list   = []
    count = 0
    
    for target_id in graph_order_list:
        node_index = graph_node_id_list.index(target_id)
        node       = graph.node[node_index]
        if (target_id in id_list):
            top_node = node.node_id
            break
    
    under_floors = []
    under_nodes  = []
    node_index = graph_node_id_list.index(top_node)
    under_floors       = graph.node[node_index].under_floor
            
    variable_nodes.append(graph.node[node_index])
    variable_nodes_id_list.append(graph.node[node_index].node_id)
    
    while count < (len(id_list) - 1):
        for under_node in under_floors:
            node_index = graph_node_id_list.index(under_node)
            node       = graph.node[node_index]
            
            variable_nodes.append(node)
            variable_nodes_id_list.append(node.node_id)
            
            if under_node in id_list:
                count += 1
                
            else:
                remove_nodes.append(node)
                remove_nodes_id_list.append(node.node_id)
                under_nodes += node.under_floor
        
        under_floors = under_nodes

    for edge in graph.edge:
        if (edge.edge[0] in remove_nodes_id_list) | (edge.edge[1] in remove_nodes_id_list):
            remove_edges.append(edge)
    
    for variable in graph.variables:
        if variable.node_id in remove_nodes_id_list:
            remove_variables.append(variable)
                
    variable_graph = myclass.Graph()
    variable_graph.node      = variable_nodes
    variable_graph.edge      = remove_edges
    variable_graph.variables = remove_variables
    
    #remove
    for remove_node in remove_nodes:
        graph.node.remove(remove_node)
        
    for remove_edge in remove_edges:
        graph.edge.remove(remove_edge)
        
    for remove_variable in remove_variables:
        graph.variables.remove(remove_variable)
        
    #add
    add_node = myclass.Node()
    add_edge = myclass.Edge()
    add_variable = myclass.Variable()
    
    add_node.node_id = new_node_id
    add_node.label   = new_label
    
    graph.node.append(copy.deepcopy(add_node))
    
    add_edge.label = new_label
    for target, new_id in zip(id_list, new_edge_id):
        add_edge.edge_id = new_id
        add_edge.edge    = (new_node_id, target)
        graph.edge.append(copy.deepcopy(add_edge))
        
    add_variable.node_id = new_node_id
    add_variable.style   = id_list
    
    graph.variables.append(copy.deepcopy(add_variable))
    
    return graph, variable_graph