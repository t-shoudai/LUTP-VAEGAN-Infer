"""treepatlib.infer: 無順序木パターンの帰納学習（精密化アルゴリズム）。

正例の木集合から無順序木パターンを帰納的に学習するモジュール。
精密化演算子（HE / VE / ER）を幅優先順に試みながら、
全正例にマッチする範囲でパターンを段階的に詳細化します。

精密化演算子
----------------
HE       : 変数辺 1 本を 「根 -> X, 根 -> X」 に展開（子数を 1 増やす）
VE[label]: 変数辺 1 本を 「根 -> label -> X」 に置き換え（辺ラベルを確定し変数辺を残す）
ER[label]: 変数辺 1 本を 「根 -> label」 に置き換え（辺ラベルを確定し変数辺なし）

主な関数
--------
initial_pattern()                                      最一般な初期パターン（根 -> X）を返す
make_refinement_operators(edge_factor)                 全演算子辞書を返す
refine(pattern, variable_edge, operator)               1 ステップの精密化を実行する
refine_pattern(pattern, positive_set, edge_factor)     帰納学習メインループ

使い方
--------
import treepatlib as tpl

positive_set = [...]  # nx.DiGraph のリスト
t_init   = tpl.infer.initial_pattern()
t_result = tpl.infer.refine_pattern(
    t_init,
    positive_set,
    edge_factor=['a', 'b', 'c', 'd', 'e'],
    verbose=True,
)
"""

from __future__ import annotations

import copy
from collections import deque
from typing import Dict, List, Optional

import networkx as nx

# ライブラリ定数
ROOT          = 0
ROOT_NAME     = '#'
VARIABLE_NAME = 'X'


# ============================================================
# 精密化演算子の生成
# ============================================================

def make_HE() -> nx.DiGraph:
    """HE 演算子: 根を親とする変数辺 2 本（無順序）を返す。"""
    P = nx.DiGraph()
    P.add_node(0, name=ROOT_NAME)
    P.add_node(1, name=VARIABLE_NAME)
    P.add_node(2, name=VARIABLE_NAME)
    P.add_edge(0, 1)
    P.add_edge(0, 2)
    return P


def make_VE(label: str) -> nx.DiGraph:
    """VE[label] 演算子: 根 → label → X を返す。"""
    P = nx.DiGraph()
    P.add_node(0, name=ROOT_NAME)
    P.add_node(1, name=label)
    P.add_node(2, name=VARIABLE_NAME)
    P.add_edge(0, 1)
    P.add_edge(1, 2)
    return P


def make_ER(label: str) -> nx.DiGraph:
    """ER[label] 演算子: 根 → label（変数なし）を返す。"""
    P = nx.DiGraph()
    P.add_node(0, name=ROOT_NAME)
    P.add_node(1, name=label)
    P.add_edge(0, 1)
    return P


def make_refinement_operators(edge_factor: List[str]) -> Dict[str, nx.DiGraph]:
    """精密化演算子を辞書で返す。

    Parameters
    ----------
    edge_factor:
        辺ラベルの候補リスト（例: ['a', 'b', 'c']）。

    Returns
    -------
    dict
        キー: 演算子名（'HE', 'VE_a', 'ER_a', ...）
        値: nx.DiGraph（対応するパターン）
    """
    ops: Dict[str, nx.DiGraph] = {}
    ops['HE'] = make_HE()
    for label in edge_factor:
        ops[f'VE_{label}'] = make_VE(label)
    for label in edge_factor:
        ops[f'ER_{label}'] = make_ER(label)
    return ops


# ============================================================
# 精密化の基本操作
# ============================================================

def initial_pattern() -> nx.DiGraph:
    """最も一般的な初期パターン（根 → X）を返す。"""
    t = nx.DiGraph()
    t.add_node(0, name=ROOT_NAME)
    t.add_node(1, name=VARIABLE_NAME)
    t.add_edge(0, 1)
    return t


def refine(
    pattern: nx.DiGraph,
    variable_edge: tuple,
    operator: nx.DiGraph,
) -> nx.DiGraph:
    """パターンの変数辺を精密化演算子で置き換える。

    Parameters
    ----------
    pattern:
        変数辺を含むパターン木。
    variable_edge:
        精密化する変数辺 (p, x)。x は name='X' のノード。
    operator:
        精密化演算子（make_refinement_operators で得たパターン）。

    Returns
    -------
    nx.DiGraph
        精密化後のパターン。
    """
    import treepatlib.unordered as _unordered
    import treepatlib
    leaf = next(v for v in operator.nodes() if operator.out_degree(v) == 0)
    result = _unordered.binding(pattern, variable_edge, operator, leaf)
    return treepatlib.left_depth_priferred_tree(result)


# ============================================================
# 帰納学習メインループ（内部ユーティリティ）
# ============================================================

def _get_variable_edges_bfs(pattern: nx.DiGraph) -> List[tuple]:
    """パターンの変数辺を幅優先順に返す。"""
    var_edges = []
    visited: set = set()
    queue: deque = deque([ROOT])
    while queue:
        node = queue.popleft()
        if node in visited:
            continue
        visited.add(node)
        for child in pattern.successors(node):
            if pattern.nodes[child].get('name') == VARIABLE_NAME:
                var_edges.append((node, child))
            else:
                queue.append(child)
    return var_edges


def _matches_all(pattern: nx.DiGraph, positive_set: List[nx.DiGraph]) -> bool:
    """pattern が positive_set の全正例にマッチするか判定する。"""
    import treepatlib.unordered as _unordered
    return all(_unordered.matching(pattern, G) for G in positive_set)


# ============================================================
# 帰納学習メインループ
# ============================================================


def refine_pattern(
    pattern,
    positive_set,
    edge_factor,
    verbose=False,
):
    """精密化アルゴリズム: 全正例にマッチする範囲でパターンを精密化する。

    変数辺を幅優先順に取得し、HE → VE_* → ER_* の順に演算子を試みる。
    全正例にマッチすれば採用してパターンを更新、変数辺を取り直して再開。
    1つでもマッチしなければ次の演算子へ。全失敗で終了。

    Parameters
    ----------
    pattern : nx.DiGraph
    positive_set : list of nx.DiGraph
    edge_factor : list of str
    verbose : bool

    Returns
    -------
    nx.DiGraph
    """
    import treepatlib.unordered as _unordered

    ops      = make_refinement_operators(edge_factor)
    op_order = ['HE'] + [f'VE_{l}' for l in edge_factor] + [f'ER_{l}' for l in edge_factor]

    t       = copy.deepcopy(pattern)
    changed = True

    while changed:
        changed   = False
        var_edges = _get_variable_edges_bfs(t)
        if not var_edges:
            break

        for var_edge in var_edges:
            for op_name in op_order:
                op      = ops[op_name]
                op_leaf = next((v for v in op.nodes() if op.out_degree(v) == 0), None)
                try:
                    candidate = _unordered.binding(t, var_edge, op, op_leaf)
                except Exception:
                    continue
                if _matches_all(candidate, positive_set):
                    if verbose:
                        nodes = [(n, candidate.nodes[n]['name']) for n in candidate.nodes()]
                        print(f"  適用: {op_name} on {var_edge} -> {nodes}")
                    t       = candidate
                    changed = True
                    break  # op_order ループを抜ける

    return t
