import os
os.getcwd()
import copy
import treepatlib.classes as myclass

def gml_data_creation(gml_file_name, graph):
    gml_file_date = os.path.join(os.path.dirname(__file__), gml_file_name)
    gml_file      = open(gml_file_date,'w',encoding="utf_8")
    
    remove_nodes   = []
    remove_edges   = []
    variable_nodes = []
    variable_edges = []
    
    nodes     = copy.deepcopy(graph.node)
    edges     = copy.deepcopy(graph.edge)
    variables = copy.deepcopy(graph.variables)
    
    variable_node_id_list = [variable.node_id for variable in variables]
    
    for node in nodes:
        if node.node_id in variable_node_id_list:
            remove_nodes.append(node)
            variable_nodes.append(node)
            
    for remove_node in remove_nodes:
        nodes.remove(remove_node) 
    
    for variable in variable_node_id_list:
        one_variable_edge = []
        for edge in edges:
            if (edge.edge[0] == variable) | (edge.edge[1] == variable):
                remove_edges.append(edge)
                one_variable_edge.append(edge)
        variable_edges.append(one_variable_edge)
    
    for remove_edge in remove_edges:
        edges.remove(remove_edge)
    
    gml_file.write('graph\n[\n')
    
    node_write(gml_file, nodes)
    edge_write(gml_file, edges)
    variable_write(gml_file, variable_nodes, variable_edges)
    
    gml_file.write(']')
    
    gml_file.close()
    print(f'{gml_file_name} has been created.\n ')
    
def node_write(gml_file, nodes):
    indent = '    '
    first_row = f'{indent}node\n{indent}[\n'
    tail_row  = f'{indent}]\n'
    
    for node in nodes:
        gml_file.write(first_row)
        
        gml_file.write(f'{indent}{indent}id {node.node_id}\n')
        gml_file.write(f'{indent}{indent}label \"{node.label}\"\n')
        
        gml_file.write(tail_row)
        
def edge_write(gml_file, edges):
    indent = '    '
    first_row = f'{indent}edge\n{indent}[\n'
    tail_row  = f'{indent}]\n'
    
    for edge in edges:
        gml_file.write(first_row)
        
        gml_file.write(f'{indent}{indent}id {edge.edge_id}\n')
        gml_file.write(f'{indent}{indent}label \"{edge.label}\"\n')
        gml_file.write(f'{indent}{indent}source {edge.edge[0]}\n')
        gml_file.write(f'{indent}{indent}target {edge.edge[1]}\n')
        
        gml_file.write(tail_row)
        
def variable_write(gml_file, variable_nodes, variable_edges):
    indent = '    '
    first_row = f'{indent}hyper_edge\n{indent}[\n'
    tail_row  = f'{indent}]\n'
    
    for node, edges in zip(variable_nodes, variable_edges):
        edge_id_str = ''
        edge_target_str = ''
        
        for i, edge in enumerate(edges):
            if i == len(edges) - 1:
                edge_id_str += str(edge.edge_id)
                
                if edge.edge[0] == node.node_id:
                    edge_target_str += str(edge.edge[1])
                elif edge.edge[1] == node.node_id:
                    edge_target_str += str(edge.edge[0])
            else:
                edge_id_str += f"{edge.edge_id},"
                
                if edge.edge[0] == node.node_id:
                    edge_target_str += f"{edge.edge[1]},"
                elif edge.edge[1] == node.node_id:
                    edge_target_str += f"{edge.edge[0]},"
        
        gml_file.write(first_row)
        
        gml_file.write(f'{indent}{indent}node_id {node.node_id}\n')
        gml_file.write(f'{indent}{indent}edge_id [{edge_id_str}]\n')
        gml_file.write(f'{indent}{indent}label \"{node.label}\"\n')
        gml_file.write(f'{indent}{indent}target [{edge_target_str}]\n')
        
        gml_file.write(tail_row)