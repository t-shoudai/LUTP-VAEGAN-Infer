"""treepatlib: 無順序木・順序木のパターンマッチングと列挙ライブラリ。"""

# データ構造
from treepatlib.classes import Node, Edge, Variable, Graph, Binding, Drawing

# 描画・シリアライズ
from treepatlib.draw import (
    drawing,
    coloring_node,
    dfuds,
    tree_draw,
    tree_from_networkx,
    tree_save,
    return_to_graph,
    clear,
)

# レイアウト計算
from treepatlib.drawing_data_creation_module import *

# GML 入出力
from treepatlib.gml_data_creation_module import *

# グラフデータ読み込み
from treepatlib.graph_data_creation_module import *

# 描画グラフ生成・バインディング
from treepatlib.tree_graph_creation_module import (
    drawing_graph_data_creation,
    binding_add_graph,
    make_variable,
    make_gml,
)

# 帰納学習
from treepatlib import infer

# 順序木
from treepatlib import ordered

# 無順序木
from treepatlib import unordered
from treepatlib.unordered import (
    depth_sequence,
    active,
    matching,
    node_divide,
    make_rule,
    make_positive,
    make_negative,
    is_leaf,
    left_depth_priferred_tree,
    right_depth_preferred_tree,
    u_enumerate,
    randomtree as u_randomtree,
    change,
    split_list,
    substitute,
    binding,
)

__all__ = [
    # classes
    "Node", "Edge", "Variable", "Graph", "Binding", "Drawing",
    # draw
    "drawing", "coloring_node", "dfuds", "tree_draw",
    "tree_from_networkx", "tree_save", "return_to_graph", "clear",
    # tree_graph_creation_module
    "drawing_graph_data_creation", "binding_add_graph", "make_variable", "make_gml",
    # unordered
    "depth_sequence", "active", "matching", "node_divide", "make_rule",
    "make_positive", "make_negative", "is_leaf",
    "left_depth_priferred_tree", "right_depth_preferred_tree",
    "u_enumerate", "u_randomtree", "change", "split_list", "substitute", "binding",
    # submodules
    "ordered", "unordered", "infer",
]
