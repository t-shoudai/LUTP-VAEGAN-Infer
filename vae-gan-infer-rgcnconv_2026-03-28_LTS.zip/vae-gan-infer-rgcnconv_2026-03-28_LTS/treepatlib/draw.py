"""木の描画・シリアライズ・NetworkX 変換ユーティリティ。"""
import matplotlib.pyplot as plt
import treepatlib.classes as myclass
import treepatlib as tpl
import networkx as nx
from typing import List, Optional


def drawing(
    drawing_data: myclass.Drawing,
    node_label: bool = True,
    edge_label: bool = True,
) -> None:
    """Drawing オブジェクトをもとに木を matplotlib で描画する。

    Parameters
    ----------
    drawing_data:
        描画データ（Graph・ノード ID リスト・ノード種別）。
    node_label:
        True のときノードラベルを表示。False のときノード ID を表示。
    edge_label:
        True のとき辺ラベルを表示。False のとき辺 ID を表示。
    """
    graph = drawing_data.graph
    node_id_list = drawing_data.node_id_list
    node_type = drawing_data.node_type

    plt.figure(figsize=(6, 4), dpi=80)
    ax = plt.gca()
    ax.axes.xaxis.set_visible(False)
    ax.axes.yaxis.set_visible(False)
    ax.spines['top'].set_visible(False)
    ax.spines['left'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['bottom'].set_visible(False)

    node = graph.node
    edge = graph.edge

    for i, draw_node in enumerate(node):
        if node_type[i] is False:
            plt.scatter(
                draw_node.position[0], draw_node.position[1],
                s=100, c='white', marker='o', linewidths=1,
                edgecolors='#777777', zorder=2,
            )
        else:
            plt.scatter(
                draw_node.position[0], draw_node.position[1],
                s=100, c='#ffff66', marker='s', linewidths=1,
                edgecolors='#777777', zorder=2,
            )

        if node_label:
            plt.text(draw_node.position[0], draw_node.position[1], draw_node.label)
        else:
            plt.text(draw_node.position[0], draw_node.position[1], draw_node.node_id)

        # 木が Path のとき線幅が autoscale して画面幅と同一になるのを回避する。(by T.Shoudai)
        if draw_node.position[0] == 5.0 and draw_node.position[1] == 0:
            plt.scatter([0, 10], [0, 0], s=0, c='white', edgecolor='white')

    for draw_edge in edge:
        souce_node1 = draw_edge.edge[0]
        souce_node2 = draw_edge.edge[1]

        source = node_id_list.index(souce_node1)
        target = node_id_list.index(souce_node2)

        sx = node[source].position[0]
        sy = node[source].position[1]
        tx = node[target].position[0] - sx
        ty = node[target].position[1] - sy

        plt.arrow(sx, sy, tx, ty, head_width=0, head_length=0, width=0.001, color='#777777')

        x_t = sx + (tx / 2)
        y_t = sy + (ty / 2)

        if edge_label:
            plt.text(x_t, y_t, draw_edge.label)
        else:
            plt.text(x_t, y_t, draw_edge.edge_id)


def coloring_node(
    nodes: List[myclass.Node],
    node_id_list: List[int],
    node_ids: List[int],
    colors: List[str],
    label: bool = True,
) -> None:
    """指定ノードを任意の色で上書き描画する。

    drawing() で描画した後に呼び出して特定ノードを強調できる。

    Parameters
    ----------
    nodes:
        グラフの全ノードリスト。
    node_id_list:
        描画順のノード ID リスト。
    node_ids:
        色を変えるノード ID のリスト。
    colors:
        node_ids に対応する色文字列のリスト（matplotlib カラー指定）。
    label:
        True のときノードラベルを表示。
    """
    ax = plt.gca()
    ax.axes.xaxis.set_visible(False)
    ax.axes.yaxis.set_visible(False)
    ax.spines['top'].set_visible(False)
    ax.spines['left'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['bottom'].set_visible(False)

    for node_id, color in zip(node_ids, colors):
        node_id_index = node_id_list.index(node_id)
        node = nodes[node_id_index]

        plt.scatter(
            node.position[0], node.position[1],
            s=100, c=color, marker='o', linewidths=1,
            edgecolors='#777777', zorder=2,
        )

        if label:
            plt.text(node.position[0], node.position[1], node.label)
        else:
            plt.text(node.position[0], node.position[1], node.node_id)


def dfuds(G: nx.DiGraph) -> str:
    """木を DFUDS（深さ優先単項次数列）形式の文字列に変換する。

    DFUDS は木の構造とラベルをコンパクトに表現したシリアライズ形式。

    Parameters
    ----------
    G:
        対象の木（有向グラフ）。各ノードに 'name' 属性が必要。

    Returns
    -------
    str
        DFUDS 形式の文字列。
    """
    G_dfs = nx.dfs_tree(G, source=0)
    node_list = list(G_dfs.nodes)
    result = '0'
    before = ',0'
    for v in node_list:
        v_adj = len(G.adj[v])
        edge_label = G.nodes[v]['name']
        result = result + before * v_adj + "," + edge_label
    return result


def tree_draw(
    T: nx.DiGraph,
    file_name: Optional[str] = None,
    show: bool = True,
) -> None:
    """NetworkX の木を描画し、必要に応じてファイルに保存する。

    Parameters
    ----------
    T:
        描画する木（NetworkX 有向グラフ）。
    file_name:
        保存先ファイル名（拡張子なし）。None のとき保存しない。
    show:
        True のとき plt.show() を呼び出す。
    """
    G = tree_from_networkx(T)
    DG = tpl.tree_graph_creation_module.drawing_graph_data_creation(G)
    drawing(DG)
    if file_name is not None:
        plt.savefig(file_name + '.png')
    if show:
        plt.show()
    plt.close()


def tree_from_networkx(T: nx.DiGraph) -> myclass.Graph:
    """NetworkX の有向グラフを Graph クラスのインスタンスに変換する。

    Parameters
    ----------
    T:
        変換対象の NetworkX 有向グラフ。

    Returns
    -------
    myclass.Graph
    """
    G = myclass.Graph()
    G.node = []
    G.edge = []
    for v in T.nodes:
        node = myclass.Node(v, v)
        G.node.append(node)
    for e in T.edges:
        if T.nodes(data='name')[e[1]] is None:
            edge = myclass.Edge(list(T.edges(e))[0][1], str(e[1] - 1), e)
        else:
            edge = myclass.Edge(list(T.edges(e))[0][1], T.nodes[e[1]]['name'], e)
        G.edge.append(edge)
    return G


def tree_save(G: nx.DiGraph, class_: object, file_name: str) -> None:
    """木を DFUDS 形式でテキストファイルに追記保存する。

    Parameters
    ----------
    G:
        保存する木。
    class_:
        クラスラベル（正例・負例などの識別子）。
    file_name:
        保存先ファイル名（拡張子なし）。
    """
    with open(file_name + '.txt', 'a', encoding='UTF-8') as f:
        save = str(class_) + ': ' + tpl.draw.dfuds(G) + '\n'
        f.write(save)


def return_to_graph(dfuds_str: str) -> nx.DiGraph:
    """DFUDS 形式の文字列から木（DiGraph）を復元する。

    Parameters
    ----------
    dfuds_str:
        dfuds() で生成した DFUDS 文字列。

    Returns
    -------
    nx.DiGraph
        復元された木。
    """
    v = 0
    count = 0
    dict_name = {}
    dict_child = {}

    for df in dfuds_str:
        if (df != '0') and (df != ','):
            dict_name[count] = df
            count += 1
    count = 0
    for enu, d in enumerate(dfuds_str):
        if enu != 0:
            if d == '0':
                count += 1
            elif d == ',':
                pass
            else:
                dict_child[v] = count
                count = 0
                v += 1

    G = nx.DiGraph()
    for enu, i in enumerate(dict_name):
        G.add_node(enu)
    count = 0
    for i in dict_name:
        for j in range(dict_child[i]):
            if i == 0:
                G.add_edge(i, count + 1)
                count += 1
            else:
                G.add_edge(list(nx.dfs_preorder_nodes(G, source=0))[i], count + 1)
                count += 1
    G = nx.dfs_tree(G, source=0)
    for enu, v in enumerate(G.nodes()):
        G.add_node(v, name=dict_name[enu])
    return clear(G)


def clear(G: nx.DiGraph) -> nx.DiGraph:
    """ノード・辺の ID を DFS 順に振り直して正規化する。

    Parameters
    ----------
    G:
        正規化対象の木。

    Returns
    -------
    nx.DiGraph
        ノード・辺が整番された木。
    """
    G = nx.convert_node_labels_to_integers(G)
    dict_name = {}
    dict_node = {}
    for i, v in enumerate(list(nx.dfs_tree(G, source=0))):
        dict_name[i] = G.nodes[v]['name']
        dict_node[v] = i
    T = nx.DiGraph()
    for i, v in enumerate(list(nx.dfs_tree(G, source=0))):
        T.add_node(dict_node[v], id=i, label=str(i), name=dict_name[i])
    for i, edge in enumerate(list(nx.dfs_edges(G, source=0))):
        T.add_edge(dict_node[edge[0]], dict_node[edge[1]], id=i, label=str(i))
    return nx.convert_node_labels_to_integers(T)
