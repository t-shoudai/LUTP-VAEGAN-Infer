# treepatlib API リファレンス

木構造パターンライブラリ **treepatlib** の関数・クラス一覧です。
`import treepatlib as tpl` でインポートして使います。

---

## 目次

1. [データ構造（classes）](#1-データ構造classes)
2. [順序木（ordered）](#2-順序木ordered)
3. [無順序木（unordered）](#3-無順序木unordered)
4. [描画・シリアライズ（draw）](#4-描画シリアライズdraw)
5. [グラフ生成・バインディング（tree_graph_creation_module）](#5-グラフ生成バインディングtree_graph_creation_module)
6. [GML 入出力](#6-gml-入出力)
7. [レイアウト計算（drawing_data_creation_module）](#7-レイアウト計算drawing_data_creation_module)
8. [ノートブック用ユーティリティ](#8-ノートブック用ユーティリティ)
9. [帰納学習（infer）](#9-帰納学習infer)

---

## 1. データ構造（classes）

`from treepatlib.classes import ...`

ライブラリ全体で使われるコアデータ構造です。

### `Node`

グラフのノード 1 つを表します。

| 属性 | 型 | 説明 |
|---|---|---|
| `node_id` | `int` | ノード識別子 |
| `label` | `str` | 表示ラベル |
| `edge_count` | `int` | 接続辺数 |
| `upper_floor` | `list[int]` | 親ノード ID リスト |
| `under_floor` | `list[int]` | 子ノード ID リスト |
| `position` | `(float, float)` | 描画座標 `(x, y)` |
| `position_area` | `(float, float, float)` | 描画領域 `(x, y, half_width)` |

```python
node = Node(node_id=1, label='a')
node.print_data()  # 属性を標準出力に表示
```

---

### `Edge`

グラフの辺 1 本を表します。

| 属性 | 型 | 説明 |
|---|---|---|
| `edge_id` | `int` | 辺識別子 |
| `label` | `str` | 辺ラベル |
| `edge` | `(int, int)` | `(source_id, target_id)` |

---

### `Variable`

パターン中の変数ノード（超辺）を表します。
描画時に黄色の四角形で表示されます。

| 属性 | 型 | 説明 |
|---|---|---|
| `node_id` | `int` | 変数ノードの ID |
| `style` | `list[int]` | 接続先ノード ID リスト（描画スタイル情報） |

---

### `Graph`

グラフ全体を保持するコンテナです。

| 属性 | 型 | 説明 |
|---|---|---|
| `node` | `list[Node]` | ノードのリスト |
| `edge` | `list[Edge]` | 辺のリスト |
| `variables` | `list[Variable]` | 変数ノードのリスト |
| `drawing_order` | `list[int]` | 描画順のノード ID |
| `bind_num` | `int` | バインディング番号 |

---

### `Binding`

変数ノードに対応する部分木をグラフに関連付けるバインディング情報です。

| 属性 | 型 | 説明 |
|---|---|---|
| `target_label` | `str` | バインディング対象ノードのラベル |
| `node` | `list[Node]` | バインディンググラフのノード |
| `edge` | `list[Edge]` | バインディンググラフの辺 |
| `variables` | `list[Variable]` | バインディンググラフの変数 |
| `style` | `list[int]` | 描画スタイル情報 |
| `drawing_order` | `list[int]` | 描画順 |
| `bind_num` | `int` | バインディング番号 |

---

### `Drawing`

描画に必要なデータをまとめたクラスです。
`drawing_graph_data_creation()` の戻り値として使われます。

| 属性 | 型 | 説明 |
|---|---|---|
| `graph` | `Graph` | 描画対象グラフ |
| `node_id_list` | `list[int]` | 描画順のノード ID リスト |
| `node_type` | `list[bool]` | 各ノードが変数ノードか否かのフラグ |

---

## 2. 順序木（ordered）

`import treepatlib as tpl` → `tpl.ordered.関数名` でアクセスします。

### `o_enumerate(G=None, num_edge=None, num_graph=None)`

**順序木を列挙する。**

- `G=None` のとき：根のみの木を起点に辺を `num_edge` 本追加した全木を返す
- `G` を指定したとき：`G` から拡張して `num_graph` 個の木を返す

| 引数 | 型 | 説明 |
|---|---|---|
| `G` | `nx.DiGraph \| None` | 起点グラフ。`None` のとき根から開始 |
| `num_edge` | `int \| None` | 追加する辺数の上限（`G=None` 時のみ有効） |
| `num_graph` | `int \| None` | 生成するグラフ数（`G` 指定時のみ有効） |

**戻り値：** `list[nx.DiGraph]`

```python
trees = tpl.ordered.o_enumerate(num_edge=3)
# 辺数 0〜3 の全順序木を返す（9 個）
```

---

### `randomtree(num_graph, string_list, G=None)`

**ランダムにラベル付けされた順序木を生成する。**

| 引数 | 型 | 説明 |
|---|---|---|
| `num_graph` | `int` | 生成する木の数 |
| `string_list` | `list[str]` | ノードラベルの候補文字リスト |
| `G` | `nx.DiGraph \| None` | 起点グラフ。`None` のとき根から開始 |

**戻り値：** `list[nx.DiGraph]`

```python
trees = tpl.ordered.randomtree(50, ['a', 'b', 'c'])
```

---

### `right_most_path(G)`

**順序木の最右路（根から最右葉までのパス）を返す。**

| 引数 | 型 | 説明 |
|---|---|---|
| `G` | `nx.DiGraph` | 対象の順序木 |

**戻り値：** `list[int]`（ノード ID 列）

---

### `relabel(G, string_list)`

**各辺の子頂点ラベルをランダムに付け直した木のリストを返す。**
辺の数と同じ長さのランダム文字列を生成し、各文字を対応する辺の子頂点（根以外）の `name` 属性に格納します。同一ラベル列が重複しないように生成します。

| 引数 | 型 | 説明 |
|---|---|---|
| `G` | `nx.DiGraph` | ラベルを付け替える対象グラフ（子頂点に `name` 属性がないこと） |
| `string_list` | `list[str]` | 使用する文字候補 |

**戻り値：** `list[nx.DiGraph]`（子頂点の `name` 属性にラベルが格納された木のリスト）

---

### `random_string(num_edge, string_list)`

**ランダムな文字列を生成する。**

| 引数 | 型 | 説明 |
|---|---|---|
| `num_edge` | `int` | 生成する文字数 |
| `string_list` | `list[str]` | 文字の候補リスト |

**戻り値：** `str`

---

### `left_sibling(G, v)`

**ノード `v` の一つ左の兄弟ノード ID を返す。**
`v` が根または左端の子の場合は `v` 自身を返します。

| 引数 | 型 | 説明 |
|---|---|---|
| `G` | `nx.DiGraph` | 対象グラフ |
| `v` | `int` | 対象ノード ID |

**戻り値：** `int`

---

## 3. 無順序木（unordered）

`tpl.unordered.関数名` でアクセスするか、`tpl.関数名` で直接呼べます。

### `u_enumerate(G=None, num_edge=None, num_graph=0)` ★

**無順序木を列挙する。**

子ノードの順序を区別しない（同型な木を 1 つに統一する）列挙を行います。

| 引数 | 型 | 説明 |
|---|---|---|
| `G` | `nx.DiGraph \| None` | 起点グラフ。`None` のとき根から開始 |
| `num_edge` | `int \| None` | 追加する辺数の上限（`G=None` 時のみ有効） |
| `num_graph` | `int` | 生成するグラフ数（`G` 指定時のみ有効） |

**戻り値：** `list[nx.DiGraph]`

```python
trees = tpl.u_enumerate(num_edge=3)
# 辺数 0〜3 の全無順序木（8 個）
```

> **順序木との違い：** 辺数 3 では順序木 9 個に対し、無順序木は 8 個（同型な木が統合されるため少なくなる）

> **`G`（起点グラフ）の役割：** `G` を指定した場合、`G` の頂点数が列挙される木の**最小頂点数**になります。

---

### `matching(pattern, G, variable=True)` ★

**パターン `pattern` が木 `G` にマッチするか判定する。**

二部マッチング（Hopcroft-Karp アルゴリズム）を使った無順序木パターンマッチングです。

| 引数 | 型 | 説明 |
|---|---|---|
| `pattern` | `nx.DiGraph` | マッチングパターン木。変数辺の子端点は `name='X'` |
| `G` | `nx.DiGraph` | マッチング対象の木 |
| `variable` | `bool` | `True` のとき `name='X'` の辺を変数として扱う（デフォルト）。`False` のとき変数なし（完全一致マッチング） |

**戻り値：** `bool`（マッチすれば `True`）

> **`variable` 引数の仕組み：** 内部では `variable=True` のとき変数名を `'X'`、`False` のとき `'XX'`（存在しないラベル）に設定します。変数名に一致する辺だけが「任意の部分木にマッチできるルール」として登録されるため、`False` にすると変数ルールが発動せず、すべての辺ラベルが完全一致で比較されます。

```python
import networkx as nx

# パターン: # -[a]-> -[X]->  （X は変数辺 = 任意の部分木にマッチ）
P = nx.DiGraph()
P.add_node(0, name='#'); P.add_node(1, name='a'); P.add_node(2, name='X')
P.add_edge(0, 1); P.add_edge(1, 2)

# 対象木: # -[a]-> -[b]-> -[c]->
G = nx.DiGraph()
G.add_node(0, name='#'); G.add_node(1, name='a')
G.add_node(2, name='b'); G.add_node(3, name='c')
G.add_edge(0, 1); G.add_edge(1, 2); G.add_edge(2, 3)

tpl.matching(P, G)              # True  （X が b->c の部分木にマッチ）
tpl.matching(P, G, variable=False)  # False （'X' ラベルの辺が G に存在しない）
```

---


### `binding(pattern, variable_edge, tree, leaf)` ★

**パターンの変数辺に木を束縛する（超辺置換）。**

変数辺 `(p, x)` に対して以下の同一視を行います：

- **`p`**（変数辺の親端点）と `tree` の**根**を同一視
- **`x`**（変数辺の子端点）と `tree` の指定葉 **`leaf`** を同一視

`x` が内部ノードの場合、`x` の子サブツリーは `leaf` の子として接続されます。
現在のパターンクラスでは `x` は常に葉なので、`leaf` の選択は結果に影響しません。

| 引数 | 型 | 説明 |
|---|---|---|
| `pattern` | `nx.DiGraph` | 変数辺を含むパターン木 |
| `variable_edge` | `tuple` | 束縛する変数辺 `(p, x)`。`x` は `name='X'` のノード |
| `tree` | `nx.DiGraph` | 変数辺に代入する根付き木 |
| `leaf` | `int` | `tree` の中で `x` と同一視する葉ノードの ID |

**戻り値：** `nx.DiGraph`（束縛後の木、ノードラベルは整数に正規化済み）

```python
# 変数辺を探して束縛
var_edge = next((p, x) for p, x in P.edges() if P.nodes[x]['name'] == 'X')
leaf = next(v for v in T.nodes() if T.out_degree(v) == 0)
result = tpl.binding(P, var_edge, T, leaf)
```

> **substitute との関係：** `binding` は変数辺1つへの束縛操作、`substitute` はすべての変数辺に対して `binding` を順に呼び出すラッパーです。

> **将来の拡張：** 変数が内部ノードを持つパターンクラスでは、`leaf` の指定により束縛結果が変わります。現在は `substitute` が `leaves=None` で自動選択します。

---

### `substitute(pattern, trees, leaves=None)` ★

**パターンのすべての変数辺に木を代入して返す。**

各変数辺に対して `binding` を順に呼び出します。`leaves` を省略した場合は各 `tree` の最初の葉を自動選択します（現在のパターンクラスと互換）。

| 引数 | 型 | 説明 |
|---|---|---|
| `pattern` | `nx.DiGraph` | 変数 `'X'` を含むパターン木 |
| `trees` | `list[nx.DiGraph]` | 各変数辺に代入する木のリスト（変数辺の数と同じ長さ） |
| `leaves` | `list[int] \| None` | 各 `tree` で子端点と同一視する葉のリスト。`None` のとき自動選択 |

**戻り値：** `nx.DiGraph`（代入後の木）

```python
# 変数が1つ（leaves は自動選択）
result = tpl.substitute(P, [some_tree])

# 変数が2つ（leaves を明示指定）
result = tpl.substitute(P, [tree1, tree2], leaves=[leaf1, leaf2])
```

---

### `make_positive(num_pos, graph_list, pattern)` ★

**パターンにマッチする正例木を生成する。**

パターン内の変数 `'X'` に `graph_list` の木を代入して正例を構成します。
生成された木は `left_depth_priferred_tree` で標準形に変換したうえで DFUDS 文字列により同型チェックを行い、**同型な木は出力されないことが保証されます**。

| 引数 | 型 | 説明 |
|---|---|---|
| `num_pos` | `int` | 生成する正例数の上限 |
| `graph_list` | `list[nx.DiGraph]` | 変数に代入する木のリスト。**1頂点（根のみ）の木は含めないこと**（`u_randomtree` の結果をそのまま渡さず 2頂点以上でフィルタすること） |
| `pattern` | `nx.DiGraph` | 変数 `'X'` を含むパターン木 |

**戻り値：** `list[nx.DiGraph]`（標準形に変換済み、同型重複なし）

> **頂点数フィルタ：** `pattern` の頂点数未満の木は出力されません。生成される正例は必ずパターン以上の大きさになります。

```python
substitute_trees = [G for G in tpl.u_randomtree(1000, EDGE_FACTOR)
                    if len(G.nodes()) >= 2]  # 根のみの木（1頂点）を除外
pos_trees = tpl.unordered.make_positive(100, substitute_trees, pattern)
```

---

### `make_negative(num_neg, string_list, pattern, G=None)` ★

**パターンにマッチしない負例木を生成する。**

生成された木は `left_depth_priferred_tree` で標準形に変換したうえで DFUDS 文字列により同型チェックを行い、**同型な木は出力されないことが保証されます**。

> ⚠️ **注意：この関数は内部で木を1本ずつ成長させながら全列挙する方式のため、パターンが大きい（頂点数が多い・変数が少ない）場合には終了しないことがあります。** その場合は代わりに `make_random_tree` でランダム生成した木を `matching` で確認する方式を使ってください（後述のノートブック用ユーティリティを参照）。

> **頂点数フィルタ：** `pattern` の頂点数未満の木は出力されません。生成される負例は必ずパターン以上の大きさになります。

| 引数 | 型 | 説明 |
|---|---|---|
| `num_neg` | `int` | 生成する負例数 |
| `string_list` | `list[str]` | 子頂点ラベルの候補文字リスト |
| `pattern` | `nx.DiGraph` | マッチング判定に使うパターン木 |
| `G` | `nx.DiGraph \| None` | 起点グラフ。`None` のとき根から開始 |

**戻り値：** `list[nx.DiGraph]`（標準形に変換済み、同型重複なし）

```python
neg_trees = tpl.make_negative(100, ['a', 'b', 'c'], pattern)
```

---

### `randomtree(num_graph, string_list, G=None)`

**ランダムにラベル付けされた無順序木を生成する。**
（`tpl.u_randomtree` としてもアクセス可能）

各木は `left_depth_priferred_tree` で標準形に変換したうえで DFUDS 文字列により同型チェックを行い、**同型な木は出力されないことが保証されます**。
ただし先頭要素は根のみの木（辺なし）なので、`make_positive` に渡す際は `pop(0)` で除いてから使うこと。

| 引数 | 型 | 説明 |
|---|---|---|
| `num_graph` | `int` | 生成する木の数 |
| `string_list` | `list[str]` | 子頂点ラベルの候補 |
| `G` | `nx.DiGraph \| None` | 起点グラフ |

**戻り値：** `list[nx.DiGraph]`（標準形に変換済み、同型重複なし）

---

### `change(G)`

**順序木を無順序木に変換する（子の順序をランダムにシャッフル）。**

| 引数 | 型 | 説明 |
|---|---|---|
| `G` | `nx.DiGraph` | 順序木として扱うグラフ |

**戻り値：** `nx.DiGraph`

---

### `left_depth_priferred_tree(beginning_tree)`

**深さ優先左優先標準形（canonical form）に変換する。**

子のいるノードについて部分木を「深さ列降順・ラベル昇順」で並び替えることで、同型な木を同一の標準形に統一します。正例生成での重複排除に使われます。

> **パターン生成時に必須：** `make_random_tree` など任意の方法で生成した木を `matching` や `make_positive` に渡す前に、必ずこの関数で標準形に変換してください。変換しないと `matching` が正しく動作しません。

| 引数 | 型 | 説明 |
|---|---|---|
| `beginning_tree` | `nx.DiGraph` | 正規化対象の木 |

**戻り値：** `nx.DiGraph`（標準形）

---

### `right_depth_preferred_tree(beginning_tree)`

**深さ優先右優先標準形に変換する。**
`left_depth_priferred_tree` の逆順版です。

**戻り値：** `nx.DiGraph`

---

### `depth_sequence(G_sub, G_pare=None)`

**部分木の各ノードの深さ列を返す。**

| 引数 | 型 | 説明 |
|---|---|---|
| `G_sub` | `nx.DiGraph` | 深さを計算する部分木 |
| `G_pare` | `nx.DiGraph \| None` | 深さの基準となる親木。`None` のとき `G_sub` 自身 |

**戻り値：** `list[int]`

---

### `active(left_ds, right_ds)`

**2 つの深さ列が先頭から一致するか判定する（アクティブ判定）。**

無順序木の最右路計算で内部的に使用されます。

**戻り値：** `bool`

---

### `right_most_path(G)`

**無順序木の最右路を返す（無順序版）。**

左右部分木の同型判定に基づき有効なノード列を返します。

**戻り値：** `list[int]`

---

### `node_divide(G)`

**ノードを葉と非葉に分類して返す。**

| 戻り値 | 型 | 説明 |
|---|---|---|
| `leaves` | `list[(int, str)]` | 葉ノードの `(node_id, label)` リスト |
| `not_leaves` | `list[(int, str)]` | 非葉ノードの `(node_id, label)` リスト |

---

### `make_rule(G, variable_name)`

**パターンからマッチングルール（頭部・本体）を生成する。**

`matching()` の内部処理で使用されます。

**戻り値：** `(heads, bodies)`

---

### `is_leaf(G, v)`

**ノード `v` が葉かどうか返す。**

**戻り値：** `bool`

---

### `split_list(l, n)`

**リストを `n` 要素ずつのチャンクに分割するジェネレータ。**

`make_positive()` の内部処理で使用されます。

---

## 4. 描画・シリアライズ（draw）

`tpl.関数名` で直接アクセスできます。

### `tree_draw(T, file_name=None, show=True)` ★

**NetworkX の木を描画する高レベル関数。**

| 引数 | 型 | 説明 |
|---|---|---|
| `T` | `nx.DiGraph` | 描画する木 |
| `file_name` | `str \| None` | 保存先ファイル名（拡張子なし）。`None` のとき保存しない |
| `show` | `bool` | `True` のとき `plt.show()` を呼ぶ |

```python
tpl.tree_draw(T, file_name='output', show=True)
# output.png に保存 + 画面表示
```

---

### `drawing(drawing_data, node_label=True, edge_label=True)`

**`Drawing` オブジェクトをもとに木を描画する低レベル関数。**

`tree_draw()` の内部で使用されます。直接 `plt.show()` / `plt.savefig()` と組み合わせて使うことも可能です。

| 引数 | 型 | 説明 |
|---|---|---|
| `drawing_data` | `Drawing` | 描画データ |
| `node_label` | `bool` | ノードラベルを表示するか |
| `edge_label` | `bool` | 辺ラベルを表示するか |

---

### `coloring_node(nodes, node_id_list, node_ids, colors, label=True)`

**特定ノードを指定した色で上書き描画する。**

`drawing()` で描画した後に呼び出して、ノードを強調表示します。

| 引数 | 型 | 説明 |
|---|---|---|
| `nodes` | `list[Node]` | グラフの全ノードリスト |
| `node_id_list` | `list[int]` | 描画順のノード ID リスト |
| `node_ids` | `list[int]` | 色を変えるノード ID |
| `colors` | `list[str]` | 対応する色（matplotlib カラー指定） |

```python
tpl.drawing(drawing_data)
tpl.coloring_node(nodes, id_list, [2, 3], ['red', 'blue'])
plt.show()
```

---

### `dfuds(G)` ★

**木を DFUDS 形式の文字列に変換する（シリアライズ）。**

DFUDS（Depth-First Unary Degree Sequence）は木の構造とラベルを 1 行の文字列で表現する形式です。

| 引数 | 型 | 説明 |
|---|---|---|
| `G` | `nx.DiGraph` | 対象の木（各ノードに `name` 属性が必要） |

**戻り値：** `str`

```python
s = tpl.dfuds(T)    # 例: "0,0,a,0,b,c"
T2 = tpl.return_to_graph(s)  # 復元
```

---

### `return_to_graph(dfuds_str)` ★

**DFUDS 文字列から木（DiGraph）を復元する。**

| 引数 | 型 | 説明 |
|---|---|---|
| `dfuds_str` | `str` | `dfuds()` で生成した文字列 |

**戻り値：** `nx.DiGraph`

---

### `tree_save(G, class_, file_name)`

**木を DFUDS 形式でテキストファイルに追記保存する。**

| 引数 | 型 | 説明 |
|---|---|---|
| `G` | `nx.DiGraph` | 保存する木 |
| `class_` | `any` | クラスラベル（例: `1`（正例）, `0`（負例）） |
| `file_name` | `str` | 保存先ファイル名（拡張子なし） |

```python
tpl.tree_save(tree, class_=1, file_name='dataset')
# dataset.txt に "1: 0,0,a,b" のような行が追記される
```

---

### `tree_from_networkx(T)`

**NetworkX DiGraph を `Graph` クラスに変換する。**

| 引数 | 型 | 説明 |
|---|---|---|
| `T` | `nx.DiGraph` | 変換元グラフ |

**戻り値：** `Graph`

---

### `clear(G)`

**ノード・辺の ID を DFS 順に振り直して正規化する。**

| 引数 | 型 | 説明 |
|---|---|---|
| `G` | `nx.DiGraph` | 正規化対象 |

**戻り値：** `nx.DiGraph`

---

## 5. グラフ生成・バインディング（tree_graph_creation_module）

`tpl.関数名` で直接アクセスできます。

### `drawing_graph_data_creation(graph, top_node_id=None)`

**`Graph` オブジェクトから `Drawing` オブジェクトを生成する。**

レイアウト計算（ノード座標の決定）をまとめて行います。

| 引数 | 型 | 説明 |
|---|---|---|
| `graph` | `Graph` | 描画対象グラフ |
| `top_node_id` | `int \| None` | ルートノードの ID。`None` のとき `node[0].node_id` を使用 |

**戻り値：** `Drawing`

```python
# GML ファイルからグラフを読み込んで描画
G = tpl.graph_data_creation('my_graph.gml')
drawing_data = tpl.drawing_graph_data_creation(G)
tpl.drawing(drawing_data)
plt.show()
```

---

### `binding_add_graph(drawing_data, binding_data)`

**既存の描画データにバインディング（変数代入）を追加する。**

変数ノードを持つグラフに対して、変数に対応する部分木を関連付けます。

| 引数 | 型 | 説明 |
|---|---|---|
| `drawing_data` | `Drawing` | 元の描画データ |
| `binding_data` | `Binding` | バインディング情報 |

**戻り値：** `Drawing`（バインディングを統合した新しい描画データ）

---

### `make_variable(drawing_data, frame_node_list, new_node_id, new_edge_id, new_label, gml_file_name)`

**指定したノード群を変数ノードに変換する。**

変換結果を GML ファイルに保存します。

| 引数 | 型 | 説明 |
|---|---|---|
| `drawing_data` | `Drawing` | 対象の描画データ |
| `frame_node_list` | `list[int]` | 変数化するノード ID のリスト |
| `new_node_id` | `int` | 変数ノードに割り当てる新しい ID |
| `new_edge_id` | `int` | 変数辺に割り当てる新しい ID |
| `new_label` | `str` | 変数ノードのラベル |
| `gml_file_name` | `str` | 保存先 GML ファイル名 |

**戻り値：** `Drawing`

---

### `make_gml(graph, data_name)`

**`Graph` オブジェクトを GML ファイルに書き出す。**

| 引数 | 型 | 説明 |
|---|---|---|
| `graph` | `Graph` | 書き出すグラフ |
| `data_name` | `str` | 保存先 GML ファイル名 |

---

## 6. GML 入出力

### `graph_data_creation(gml_file_name)`

**GML ファイルを読み込んで `Graph` オブジェクトを生成する。**

| 引数 | 型 | 説明 |
|---|---|---|
| `gml_file_name` | `str` | 読み込む GML ファイルのパス |

**戻り値：** `Graph`

```python
G = tpl.graph_data_creation('pattern.gml')
```

---

### `binding_data_creation(gml_file_name, target_label, style)`

**GML ファイルを読み込んで `Binding` オブジェクトを生成する。**

| 引数 | 型 | 説明 |
|---|---|---|
| `gml_file_name` | `str` | 読み込む GML ファイルのパス |
| `target_label` | `str` | バインディング対象ノードのラベル |
| `style` | `list[int]` | 描画スタイル情報 |

**戻り値：** `Binding`

---

### `gml_data_creation(gml_file_name, graph)`

**`Graph` オブジェクトを GML ファイルに書き出す（内部関数）。**

通常は `make_gml()` 経由で使用します。

| 引数 | 型 | 説明 |
|---|---|---|
| `gml_file_name` | `str` | 書き出し先ファイル名 |
| `graph` | `Graph` | 書き出すグラフ |

---

## 7. レイアウト計算（drawing_data_creation_module）

描画座標の計算に特化した内部モジュールです。
通常は `drawing_graph_data_creation()` 経由で間接的に使用されます。

| 関数 | 説明 |
|---|---|
| `graph_data_check(graph_data)` | `Drawing` または `Graph` のどちらでも受け取れるよう正規化する |
| `node_id_list_creation(node)` | ノードリストから ID リストを生成する |
| `adjacent_list_creation(edge, node_id_list)` | 辺リストから隣接行列を生成する |
| `connecting_list_creation(node, node_id_list, adj_list)` | 各ノードの接続ノードリストを生成する |
| `node_floor_data_creation(...)` | 各ノードの親・子情報と描画順序を計算する |
| `floor_infomation_creation(...)` | ノードの深さ・階層情報を計算する |
| `hyper_edge_node_decision(...)` | 変数ノードかどうかのフラグリストを生成する |
| `graph_node_position_creation(...)` | 各ノードの 2D 描画座標を計算する |
| `binding_node_position_creation(...)` | バインディングノードの座標を計算する |
| `binding_drawing_data_creation(...)` | グラフとバインディングを統合した描画データを生成する |
| `order_list_maker(...)` | 描画順リストを生成する |
| `variable_conversion_maker(...)` | ノード群を変数ノードに変換する |

---

## よくある使い方パターン

### パターン 1：木を列挙してマッチング判定

```python
import treepatlib as tpl
import networkx as nx

# 辺数 4 以下の無順序木を列挙
trees = tpl.u_enumerate(num_edge=4)

# パターン定義（根 → a を持つすべての木）
P = nx.DiGraph()
P.add_node(0, name='#')
P.add_node(1, name='a')
P.add_node(2, name='X')  # 変数: 任意の部分木
P.add_edge(0, 1)
P.add_edge(1, 2)

# マッチする木をフィルタ
matched = [T for T in trees if tpl.matching(P, T)]
print(f"{len(matched)} 個がパターンにマッチ")
```

---

### パターン 2：正例・負例データセットを生成してファイル保存

```python
import treepatlib as tpl
import random

EDGE_FACTOR = ['a', 'b', 'c']

# 正例生成: パターンの変数にランダムな木を代入
substitute_trees = [G for G in tpl.u_randomtree(1000, EDGE_FACTOR) if len(G.nodes()) >= 2]
pos = tpl.unordered.make_positive(200, substitute_trees, pattern)

# 負例生成: ランダム生成した木でマッチしないものを選ぶ（make_negative は大きいパターンで終わらない場合あり）
def make_random_tree(num_nodes, edge_factor):
    import networkx as nx
    G = nx.DiGraph()
    G.add_node(0, name='#')
    for i in range(1, num_nodes):
        parent = random.randint(0, i - 1)
        G.add_node(i, name=random.choice(edge_factor))
        G.add_edge(parent, i)
    return G

neg = []
while len(neg) < 200:
    tree = tpl.left_depth_priferred_tree(make_random_tree(len(pattern.nodes()), EDGE_FACTOR))
    if not tpl.unordered.matching(pattern, tree, variable=True):
        neg.append(tree)

# ファイルに保存
for tree in pos:
    tpl.tree_save(tree, class_=1, file_name='dataset')
for tree in neg:
    tpl.tree_save(tree, class_=0, file_name='dataset')
```

---

### パターン 3：GML ファイルから読み込んで描画

```python
import treepatlib as tpl
import matplotlib.pyplot as plt

G = tpl.graph_data_creation('my_pattern.gml')
drawing_data = tpl.drawing_graph_data_creation(G)
tpl.drawing(drawing_data)
plt.savefig('output.png')
plt.show()
```

---

### パターン 4：DFUDS でのシリアライズ・復元

```python
import treepatlib as tpl

# 木 → 文字列
s = tpl.dfuds(tree)
print(s)  # 例: "0,0,a,0,b,c"

# 文字列 → 木
restored = tpl.return_to_graph(s)
```

---

## 変数ノードについて

パターン中に `name='X'` のノードを置くと**変数**として扱われます。
変数は任意の部分木にマッチします。

- **描画**: 黄色の四角形で表示
- **`matching()`**: `variable=True`（デフォルト）のとき有効
- **`make_positive()`**: 変数に `graph_list` の木を代入して正例を生成

複数の変数を含むパターンも使えます。その場合、各変数に独立した木が代入されます。

---

## GML ファイル形式

treepatlib で使う GML は以下の形式です。

```
graph
[
    node
    [
        id 0
        label "#"
    ]
    node
    [
        id 1
        label "a"
    ]
    edge
    [
        id 0
        label "a"
        source 0
        target 1
    ]
    hyper_edge        ← 変数ノードの場合
    [
        node_id 2
        edge_id [1]
        label "X"
        target [1]
    ]
]
```

---

## 8. ノートブック用ユーティリティ（Untitled.ipynb）

`Untitled.ipynb` に定義されているヘルパー関数です。ライブラリ本体には含まれません。

---

### `make_random_tree(num_nodes, edge_factor)`

**指定した頂点数の無順序ラベル付き木を1本ランダム生成する。**

根（ノード0）から始めて、既存のノードにランダムに辺を追加することで、ちょうど `num_nodes` 頂点の木を構成します。

| 引数 | 型 | 説明 |
|---|---|---|
| `num_nodes` | `int` | 生成する木の頂点数 |
| `edge_factor` | `list[str]` | 子頂点ラベルの候補リスト |

**戻り値：** `nx.DiGraph`（根の `name='#'`、他ノードの `name` はランダムに選ばれたラベル）

> **注意：** `matching` や `make_positive` に渡す前に `tpl.left_depth_priferred_tree()` で標準形に変換してください。

---

### `make_pattern(num_pattern)`

**ランダムなパターン木を `num_pattern` 個生成する。**

`PATTERN_MIN_NODES`〜`PATTERN_MAX_NODES` の範囲でランダムに頂点数を決め、`make_random_tree` で木を生成して葉を変数化します。変数化後に `tpl.left_depth_priferred_tree()` で標準形に変換してから返します。

| 定数 | 説明 |
|---|---|
| `PATTERN_MIN_NODES` | パターンの最小頂点数（Cell 1 で設定） |
| `PATTERN_MAX_NODES` | パターンの最大頂点数（Cell 1 で設定） |

**変数化のルール：** 葉ノード（`out_degree==0` かつ根でないノード）のうち、1個以上・最大（葉数−1）個をランダムに選んで `name='X'` に変更します（葉が1個のときは必ず1個変数化）。

**戻り値：** `list[nx.DiGraph]`（標準形に変換済み）

---

### 負例生成のパターン（Cell 3）

`make_negative` は全列挙方式のため大きいパターンでは終わらないことがあります。Cell 3 では代わりに以下の方式を使っています：

```python
Negative = []
while len(Negative) < NUMBER_OF_NEGATIVE:
    tree = make_random_tree(len(P.nodes()), EDGE_FACTOR)
    tree = tpl.left_depth_priferred_tree(tree)
    if not tpl.unordered.matching(P, tree, variable=True):
        Negative.append(tree)
```

パターンと同程度の頂点数の木をランダム生成し、マッチしないものだけを保存します。


---

## 9. 帰納学習（infer）

`treepatlib.infer` は、正例の木集合から無順序木パターンを帰納的に学習するモジュールです。
精密化演算子（HE / VE / ER）を順に試みながら、全正例にマッチする範囲でパターンを詳細化します。

```python
import treepatlib as tpl

t_init   = tpl.infer.initial_pattern()
t_result = tpl.infer.refine_pattern(t_init, positive_set, edge_factor=['a','b','c'])
```

---

### 精密化演算子の生成

#### `make_HE() -> nx.DiGraph`

HE 演算子を返します。変数辺 1 本を「根を親とする変数辺 2 本」に置き換えます（子数を 1 増やす）。

#### `make_VE(label: str) -> nx.DiGraph`

VE[label] 演算子を返します。変数辺 1 本を「根 → label → X」に置き換えます。

| 引数 | 型 | 説明 |
|---|---|---|
| `label` | `str` | 確定する辺ラベル |

#### `make_ER(label: str) -> nx.DiGraph`

ER[label] 演算子を返します。変数辺 1 本を「根 → label」に置き換えます（変数辺なし）。

| 引数 | 型 | 説明 |
|---|---|---|
| `label` | `str` | 確定する辺ラベル |

#### `make_refinement_operators(edge_factor: list[str]) -> dict`

全精密化演算子をまとめた辞書を返します。

| 引数 | 型 | 説明 |
|---|---|---|
| `edge_factor` | `list[str]` | 辺ラベルの候補リスト |

返り値のキー: `'HE'`, `'VE_a'`, `'VE_b'`, ..., `'ER_a'`, `'ER_b'`, ...

---

### 精密化の基本操作

#### `initial_pattern() -> nx.DiGraph`

最も一般的な初期パターン（根 → X）を返します。

```python
t = tpl.infer.initial_pattern()
# ノード: [(0, '#'), (1, 'X')]
# 辺:     [(0, 1)]
```

#### `refine(pattern, variable_edge, operator) -> nx.DiGraph`

パターンの変数辺を精密化演算子で 1 ステップ置き換えます。内部的には `tpl.unordered.binding` を呼びます。

| 引数 | 型 | 説明 |
|---|---|---|
| `pattern` | `nx.DiGraph` | 変数辺を含むパターン木 |
| `variable_edge` | `(int, int)` | 精密化する変数辺 `(p, x)` |
| `operator` | `nx.DiGraph` | 精密化演算子（`make_*` で生成） |

---

### 帰納学習メインループ

#### `refine_pattern(pattern, positive_set, edge_factor, verbose=False) -> nx.DiGraph`

全正例にマッチする範囲でパターンを反復的に精密化し、収束したパターンを返します。

| 引数 | 型 | 説明 |
|---|---|---|
| `pattern` | `nx.DiGraph` | 初期パターン（通常 `initial_pattern()` を使用） |
| `positive_set` | `list[nx.DiGraph]` | 正例の木リスト |
| `edge_factor` | `list[str]` | 辺ラベルの候補リスト |
| `verbose` | `bool` | 各ステップの適用内容を出力（デフォルト `False`） |

**アルゴリズム:**

1. 変数辺を幅優先順に列挙
2. 各変数辺に対して `HE → VE_* → ER_*` の順に演算子を試みる
3. 全正例にマッチすれば採用し、変数辺リストを更新して再開
4. すべての変数辺ですべての演算子が失敗したら終了

```python
t_init   = tpl.infer.initial_pattern()
t_result = tpl.infer.refine_pattern(
    t_init,
    positive_set,
    edge_factor=['a', 'b', 'c', 'd', 'e'],
    verbose=True,
)
```
